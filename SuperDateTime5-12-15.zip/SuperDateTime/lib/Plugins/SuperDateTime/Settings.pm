package Plugins::SuperDateTime::Settings;

# SlimServer Copyright (C) 2001-2006 Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Log;
use Slim::Utils::Prefs;

my $prefs = preferences('plugin.superdatetime');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.superdatetime',
	'defaultLevel' => 'WARN',
#	'defaultLevel' => 'DEBUG',
	'description'  => 'SuperDateTime',
});

my %mlbTeams = (
			'Angels'	=> 'Los Angeles Angels',
			'D-backs'	=> 'Arizona Diamondbacks',
			'Braves'	=> 'Atlanta Braves',
			'Orioles'	=> 'Baltimore Orioles',
			'Red Sox'	=> 'Boston Red Sox',
			'Cubs'		=> 'Chicago Cubs',
			'White Sox'	=> 'Chicago White Sox',
			'Reds'		=> 'Cincinnati Reds',
			'Guardians'	=> 'Cleveland Guardians',
			'Rockies'	=> 'Colorado Rockies',
			'Tigers'	=> 'Detroit Tigers',
			'Astros'	=> 'Houston Astros',
			'Royals'	=> 'Kansas City Royals',
			'Dodgers'	=> 'Los Angeles Dodgers',
			'Marlins'	=> 'Miami Marlins',
			'Brewers'	=> 'Milwaukee Brewers',
			'Twins'		=> 'Minnesota Twins',
			'Mets'		=> 'New York Mets',
			'Yankees'	=> 'New York Yankees',
			'Athletics'	=> 'Athletics',
			'Phillies'	=> 'Philadelphia Phillies',
			'Pirates'	=> 'Pittsburgh Pirates',
			'Padres'	=> 'San Diego Padres',
			'Giants'	=> 'San Francisco Giants',
			'Mariners'	=> 'Seattle Mariners',
			'Cardinals'	=> 'Saint Louis Cardinals',
			'Rays'		=> 'Tampa Bay Rays',
			'Rangers'	=> 'Texas Rangers',
			'Blue Jays'	=> 'Toronto Blue Jays',
			'Nationals'	=> 'Washington Nationals',
			'0'			=> 'None',
			'1'			=> 'All'
);

my %nbaTeams = (
			'PHI'	=> '76ers',
			'MIL'	=> 'Bucks',
			'CHI'	=> 'Bulls',
			'CLE'	=> 'Cavaliers',
			'BOS'	=> 'Celtics',
			'LAC'	=> 'Clippers',
			'MEM'	=> 'Grizzlies',
			'ATL'	=> 'Hawks',
			'MIA'	=> 'Heat',
			'CHA'	=> 'Hornets',
			'UTA'	=> 'Jazz',
			'SAC'	=> 'Kings',
			'NYK'	=> 'Knicks',
			'LAL'	=> 'Lakers',
			'ORL'	=> 'Magic',
			'DAL'	=> 'Mavericks',
			'BKN'	=> 'Nets',
			'DEN'	=> 'Nuggets',
			'IND'	=> 'Pacers',
			'NOP'	=> 'Pelicans',
			'DET'	=> 'Pistons',
			'TOR'	=> 'Raptors',
			'HOU'	=> 'Rockets',
			'SAS'	=> 'Spurs',
			'PHX'	=> 'Suns',
			'OKC'	=> 'Thunder',
			'MIN'	=> 'Timberwolves',
			'POR'	=> 'Trail Blazers',
			'GSW'	=> 'Warriors',
			'WAS'	=> 'Wizards',
			'0'		=> 'None',
			'1'		=> 'All'
);

my %wnbaTeams = (
			'ATL'	=> 'Atlanta Dream',
			'CHI'	=> 'Chicago Sky',
			'CON'	=> 'Connecticut Sun',
			'DAL'	=> 'Dallas Wings',
			'GSV'	=> 'Golden State Valkyries',
			'IND'	=> 'Indianapolis Fever',
			'LVA'	=> 'Las Vegas Aces',
			'LAS'	=> 'Los Angeles Sparks',
			'MIN'	=> 'Minnesota Lynx',
			'NYL'	=> 'New York Liberty',
			'PDX'	=> 'Portland Fire',
			'PHX'	=> 'Phoenix Mercury',
			'SEA'	=> 'Seattle Storm',
			'TOR'	=> 'Toronto Tempo',
			'WAS'	=> 'Washington Mystics',
			'0'		=> 'None',
			'1'		=> 'All'
);

my %nflTeams = (
			'SF'  	=> 'San Francisco 49ers',
			'CHI' 	=> 'Chicago Bears',
			'CIN' 	=> 'Cincinnati Bengals',
			'BUF' 	=> 'Buffalo Bills',
			'DEN' 	=> 'Denver Broncos',
			'CLE' 	=> 'Cleveland Browns',
			'TB'  	=> 'Tampa Bay Buccaneers',
			'ARI' 	=> 'Arizona Cardinals',
			'LAC'  	=> 'Los Angeles Chargers',
			'KC'  	=> 'Kansas City Chiefs',
			'IND' 	=> 'Indianapolis Colts',
			'DAL' 	=> 'Dallas Cowboys',
			'MIA' 	=> 'Miami Dolphins',
			'PHI' 	=> 'Philadelphia Eagles',
			'ATL' 	=> 'Atlanta Falcons',
			'NYG' 	=> 'New York Giants',
			'JAC' 	=> 'Jacksonville Jaguars',
			'NYJ' 	=> 'New York Jets',
			'DET' 	=> 'Detroit Lions',
			'GB'  	=> 'Green Bay Packers',
			'CAR' 	=> 'Carolina Panthers',
			'NE'  	=> 'New England Patriots',
			'LV' 	=> 'Las Vegas Raiders',
			'LAR' 	=> 'Los Angeles Rams',
			'BAL' 	=> 'Baltimore Ravens',
			'WAS' 	=> 'Washington Commanders',
			'NO'  	=> 'New Orleans Saints',
			'SEA' 	=> 'Seattle Seahawks',
			'PIT' 	=> 'Pittsburgh Steelers',
			'HOU' 	=> 'Houston Texans',
			'TEN' 	=> 'Tennessee Titans',
			'MIN' 	=> 'Minnesota Vikings',
			'0'   	=> 'None',
			'1'   	=> 'All'
);

my %nhlTeams = (
			'Ducks'				=> 'Ducks',
			'Kraken'			=> 'Kraken',
			'Bruins'			=> 'Bruins',
			'Sabres'			=> 'Sabres',
			'Flames'			=> 'Flames',
			'Hurricanes'		=> 'Hurricanes',
			'Blackhawks'   		=> 'Blackhawks',
			'Avalanche'    		=> 'Avalanche',
			'Blue Jackets' 		=> 'Blue Jackets',
			'Stars'				=> 'Stars',
			'Red Wings'			=> 'Red Wings',
			'Oilers'			=> 'Oilers',
			'Panthers'			=> 'Panthers',
			'Golden Knights'	=> 'Golden Knights',
			'Kings'				=> 'Kings',
			'Wild'				=> 'Wild',
			'Canadiens'			=> 'Canadiens',
			'Predators'			=> 'Predators',
			'Devils'			=> 'Devils',
			'Islanders'			=> 'Islanders',
			'Rangers'			=> 'Rangers',
			'Senators'			=> 'Senators',
			'Flyers'			=> 'Flyers',
			'Penguins'			=> 'Penguins',
			'Sharks'			=> 'Sharks',
			'Blues'				=> 'Blues',
			'Lightning'			=> 'Lightning',
			'Maple Leafs'		=> 'Maple Leafs',
			'Canucks'			=> 'Canucks',
			'Capitals'			=> 'Capitals',
			'Jets'				=> 'Jets',
			'Utah Hockey Club'	=> 'Utah Hockey Club',
			'0' => 'None',
			'1' => 'All'
);

my %soccerLeague = (
			'soccer.l.fbde' 		=> 'Bundesliga',
			'soccer.l.fbchampions' 	=> 'Champions League',
			'soccer.l.fbxxgc' 		=> 'CONCACAF Gold Cup',
			'soccer.l.fbxxcc'		=> 'CONCACAF Champions Cup',
			'soccer.l.fbsudca' 		=> 'Copa America',
			'soccer.l.fbeuef' 		=> 'European Championship Finals',
			'soccer.l.fbeuropa' 	=> 'Europa League',
			'soccer.l.fbfacup' 		=> 'FA Cup',
			'soccer.l.fbwcup' 		=> 'FIFA World Cup',
			'soccer.l.fbigcl' 		=> 'FIFA Club World Cup',
			'soccer.l.fbes' 		=> 'LALIGA',
			'soccer.l.fbmxma' 		=> 'Mexican Primera (Apertura)',
			'soccer.l.fbmxmc' 		=> 'Mexican Primera (Clausura)',
			'soccer.l.fbfr' 		=> 'Ligue 1',
			'soccer.l.mls' 			=> 'Major League Soccer',
			'soccer.l.fbusnwsl' 	=> 'National Womens Soccer League',
			'soccer.l.fbgb' 		=> 'Premier League',
			'soccer.l.fbit' 		=> 'Serie A',
			'soccer.l.fbwowc' 		=> 'Womens World Cup',
			'0' => 'None'
);

# my %cfballconf = (
			# '0' => 'None',
			# '80' => 'All Div I-A',
			# '1' => 'ACC',
			# '4' => 'Big 12',
			# '10' => 'Big East',			
			# '5' => 'Big Ten',			
			# '12' => 'C-USA',
			# '46' => 'A-Sun',
			# '18' => 'IA Indep.',
			# '15' => 'MAC',
			# '17' => 'MWC',
			# '9' => 'Pac-10',
			# '37' => 'S. Belt',
			# '8' => 'SEC',
			# '16' => 'WAC',
			# '81' => 'All Div I-AA',
			# '19' => 'A 10',
			# '20' => 'Big Sky',
			# '40' => 'Big South',
			# '21' => 'Gateway',
			# '43' => 'Great West',
			# '32' => 'IAA Indep.',
			# '22' => 'Ivy',
			# '23' => 'MAAC',
			# '24' => 'MEAC',
			# '25' => 'NEC',
			# '26' => 'OVC',
			# '27' => 'Patriot',
			# '28' => 'Pioneer',
			# '29' => 'Southern',
			# '30' => 'Southland',
			# '31' => 'SWAC',
			# '1000' => 'Top-25'
# );

# my %cbballconf = (
			# '0' => 'None',
			# '50' => 'All',
			# '1' => 'Am. East',
			# '2' => 'ACC',
			# '62' => 'American',
			# '3' => 'A Ten',			
			# '4' => 'Big East',			
			# '7' => 'Big Ten',
			# '46' => 'A-Sun',
			# '8' => 'Big 12',
			# '5' => 'Big Sky',
			# '6' => 'B. South',
			# '9' => 'B. West',
			# '10' => 'CAA',
			# '11' => 'C-USA',
			# '43' => 'Indep.',
			# '45' => 'HOR',
			# '12' => 'Ivy',
			# '13' => 'MAAC',
			# '15' => 'Mid-Con',
			# '14' => 'MAC',
			# '16' => 'MEAC',
			# '18' => 'MVC',
			# '44' => 'MWC',
			# '19' => 'NEC',
			# '20' => 'OVC',
			# '21' => 'Pac-10',
			# '22' => 'Patriot',
			# '23' => 'SEC',
			# '24' => 'Southern',
			# '25' => 'Southland',
			# '26' => 'SWAC',
			# '27' => 'S. Belt',
			# '29' => 'WCC',
			# '30' => 'WAC',
			# '1000' => 'Top-25'			
# );

sub name {
		return 'PLUGIN_SCREENSAVER_SUPERDATETIME';
}

sub page {
		return 'plugins/SuperDateTime/settings/basic.html';
}

sub handler {
   my ($class, $client, $params) = @_;

	my @prefs2 = qw(
		city
		wunder
		temperature
		windunit
		pressure
		offset
		stocks
		stock1format
		stock2format
		teamlogos
		mlb
		shortMLB
		nba
		shortNBA
		wnba
		shortWNBA
		nhl
		shortNHL
		nfl
		shortNFL
		soccer
		soccerLeague
		shortSoccer
		cbb
		shortCBB
		cfb
		shortCFB
		refresh
		arefresh
		lang
		time
		atime
		score
		ascore
		lweather
		drawEachDelay
		duetCkDelay
	);
	
	my $cityChanged = 0;
	
	for my $pref (@prefs2) {
		if ($params->{'saveSettings'}) {
			if ($pref eq 'cfb') {
				# Remove empties.
				my @teams = grep { $_ ne '' } @{$params->{'cfb'}};
				$prefs->set('cfb', \@teams);
			}
			elsif ($pref eq 'cbb') {
				# Remove empties.
				my @teams = grep { $_ ne '' } @{$params->{'cbb'}};
				$prefs->set('cbb', \@teams);
			}
			elsif ($pref eq 'mlb') {
				# Remove empties.
				my @teams = grep { $_ ne '0' } @{$params->{'mlb'}};
				$prefs->set('mlb', \@teams);
			}
			elsif ($pref eq 'nfl') {
				# Remove empties.
				my @teams = grep { $_ ne '0' } @{$params->{'nfl'}};
				$prefs->set('nfl', \@teams);
			}			
			elsif ($pref eq 'nba') {
				# Remove empties.
				my @teams = grep { $_ ne '0' } @{$params->{'nba'}};
				$prefs->set('nba', \@teams);
			}
			elsif ($pref eq 'wnba') {
				# Remove empties.
				my @teams = grep { $_ ne '0' } @{$params->{'wnba'}};
				$prefs->set('wnba', \@teams);
			}
			elsif ($pref eq 'nhl') {
				# Remove empties.
				my @teams = grep { $_ ne '0' } @{$params->{'nhl'}};
				$prefs->set('nhl', \@teams);
			}
			elsif ($pref eq 'soccer') {
				# Remove empties.
				my @teams = grep { $_ ne '' } @{$params->{'soccer'}};
				$prefs->set('soccer', \@teams);
			}
			elsif ($pref eq 'v1period') {
				#Remove hidden one that forces array saving- is there a better way to do this?
				my @items = grep { $_ ne 'deleteme' } @{$params->{'v1period'}};
				$prefs->set('v1period', \@items);
			}
			elsif ($pref eq 'city') {
				if ($prefs->get($pref) ne $params->{$pref}) {
					$prefs->set($pref, $params->{$pref});
					$cityChanged = 1;
				}
			}						
			else {
				$prefs->set($pref, $params->{$pref});
			}			
		}
		$params->{'prefs'}->{$pref} = $prefs->get($pref);
	}

	if ($params->{'saveSettings'}) {
		Plugins::SuperDateTime::Plugin::refreshSoon($client);
	}

	$params->{'mlbTeams'} = \%mlbTeams;
	$params->{'nflTeams'} = \%nflTeams;
	$params->{'nbaTeams'} = \%nbaTeams;
	$params->{'wnbaTeams'} = \%wnbaTeams;
	$params->{'nhlTeams'} = \%nhlTeams;
	$params->{'soccerLeague'} = \%soccerLeague;
	
	return $class->SUPER::handler($client, $params);
}

1;

__END__
