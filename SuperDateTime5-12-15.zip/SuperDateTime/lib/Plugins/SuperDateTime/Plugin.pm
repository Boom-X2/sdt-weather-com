# SuperDateTime plugin.pm by Greg Brown Feb 2005-2014, Don Grossman 2014-2026
#   Copyright (c) 2026
#   All rights reserved.
#
# DESCRIPTION
# SlimServer plugin screensaver datetime replacement. Graphically displays current weather conditions and forecasts.  
# Will also optionally display stock quotes and upcoming/current game information for MLB, NBA, NHL, NFL, and college 
# football and basketball teams at user-configurable intervals.
#
# REMOTE CONTROL
# Pressing up or down cycles the information shown on line one during time display.  It will also immediately
# display the time if it is not currently being shown.
# Pressing right or left cycles through the available games and long weather forecasts that normally cycle automatically.
# Pressing FWD or REW cycles through the long weather forecasts.
# Pressing '+' will force an immediate data refresh.
#
# This screen saver is based on the standard SlimServer DateTime screensaver written written by kdf.
# The graphical weather icons and the code to support them are based on the WeatherTime screensaver written by Martin Rehfeld.
#
# VERSION HISTORY
# 5.12.15 08/15/26	Fixed NFL scores for 2026 season.
#
# 5.12.14 06/30/26	Added penalty shootout to soccer scores.
#
# 5.12.13 06/17/26	Tweaked weather API calls.
#
# 5.12.12 06/10/26	Added FIFA World Cup to soccer league pull down selection.
#
# 5.12.11 05/30/26	Added expansion teams Portland Fire and Toronto Tempo to WNBA.
#
# 5.12.10 05/16/26	Updated NBA and WNBA data URLs.
#
# 5.12.9  03/27/26	Fixed bug in detection of Active NHL games.
#					Bug introduced with 5.12.8 release.
#
# 5.12.8  03/21/26	Add forecasted Relative Humidity. Macro variable = %!h
#					Cleanup College Basketball (CBB) and Soccer code.
#
# 5.12.7  02/13/26	API changes for CBB and Soccer sports scores.
#
# 5.12.6  01/17/26	Fix stale soccer score data when league setting changed to "None" and/or teams cleared.
#					Fix typos in MLB and WNBA team names in settings pull down lists.  Thanks @urknall
#
# 5.12.5  01/04/26	Fixed display of short soccer team names on legacy devices. (Boom, SB3, Transporter)
#
# 5.12.4  01/01/26	Fixed college football scores.  
#
# 5.12.3  12/22/25	Implemented short soccer team names.  
#
# 5.12.2  11/06/25	Fixed College Basketball (CBB) scores.
#
# 5.12.1  10/06/25	Fixed upcoming MLB game times.
#
# 5.12.0  09/29/25	Add Professional Soccer Scores.
#
# 5.11.58 09/20/25	Fixed CFB team selection and team name display on legacy players. (Boom, SB3, Transporter)
#
# 5.11.57 09/18/25	Fixed display of game time for Active College Football (CFB) games.
#
# 5.11.56 09/14/25	Fixed College Football Scores
#
# 5.11.55 09/08/25	Implemented @urknall's fix for weathermaps.  Thanks @urknall
#
# 5.11.54 08/31/25	Added Icons for Pollen Forecasts and Air Quality Observations. Thanks @PetGeer
#					Fixed bug in sub C24to12.  Thanks @tcutting
#
# 5.11.53 08/16/25	Added Air Quality Observations.
#
# 5.11.52 07/31/25	Added Pollen forecasts.
#					Added macro variables for pollen index and category to LMS Settings->Player->SDT tab 
#					Consolidated macro variables section of SDT player settings for German and Dutch languages.
#
# 5.11.51 07/20/25	Fixed Moon Icon and Weather Map display in SDT Extras.
#
# 5.11.50 07/13/25	Fixed WNBA team selection for Custom Clock screens.
#					Implemented WNBA Shortened Team Names.
#
# 5.11.49 07/12/25	Code cleanup after weather API updates.
#					Keep redundant long weather forecasts from being stored.
#					Fixed missing weather pressure data when units='m'. 
#					
# 5.11.48 07/06/25	Address all changes to weather data API.
#					
# 5.11.47 07/05/25	2nd preliminary release to address changes to weather data API.
#						Added near term forecasts. Current observations available.  Release with with 15-day forecasts still to come.
#					
# 5.11.46 07/02/25	Preliminary release to address changes to weather data API.
#						Only current observations available.  Release with forecasted data will follow.
#					Add WNBA Sports Scores.
#					
# 5.11.45 04/09/25	Add intermission indicator to NHL Game Clock.
#					
# 5.11.44 01/04/25	Add Seattle Kraken and remove Arizona Coyotes from NHL Hockey Teams.  Thanks @tedfroop.
#					Improve error handling for stocks.
#					
# 5.11.43 12/15/24	Added Danish translations.  Thanks @cfuttrup.
#					
# 5.11.42 11/29/24	Improve parsing of NBA game clock for active games.
#					Reestablished Stock Quotes. 
#					
# 5.11.41 11/16/24	Add Utah Hockey Club to NHL Teams list in SDT settings.  
#					
# 5.11.40 09/23/24	Store sports team logos locally.  
#					
# 5.11.39 05/15/24	Fix weather data retrieval. 
#					
# 5.11.38 04/22/24	Initial fix for weather RADAR maps.  LMS running on Linux and Jivelite players only. 
#					Added Czech translations for months.  Thanks @mipa87
#					Allow SDT to load on Lyrion Music Server.  Updated max LMS version to 9.*
#					
# 5.11.37 01/22/24	Added ability to display shortened college team names for NCAA Football and Basketball.
#					Improved detection of halftime for NCAA Basketball.
#					
# 5.11.36 11/15/23	Custom Clock Helper infotype "getLongWeather" was replaced with "LongWeather" in 5.11.35.
#					For backwards compatibility, CCH infotype "getLongWeather" is added back.  Thanks @bluetdi
#					
# 5.11.35 11/11/23	Improved retrieval of Long Weather forecasts. 
#					Added 15-Days of Long Weather forecasts.
#					Fixed retrieval of NHL score data.
#					When Forecast High is NULL replace with Max Observed Temperature. 
#					
# 5.11.34 10/29/23	Fixed missing Moonrise, Moonset, and Moon Phase information.
#					Added 15-day Moon ICONs 
#					Added Macro Variable for WU Station.
#					
# 5.11.33 10/22/23	Fixed 15-Day Sunrise and Sunset times.
#					Added 15-Day Moonrise, Moonset, and Moon Phase information.
#                   Updated to not try stocks until crumb is set.
#					
# 5.11.32 10/05/23	Updated to not set finance cookie or crumb unless Stock(s) are selected.  
#					
# 5.11.31 09/23/23	Fixed retrieval of Stock data.  Thanks @Paul Webster and @expectingtofly  
#					
# 5.11.30 03/18/23	Updated Macro Variables listing. See LMS->Settings->Player->SDT.  
#					Updated SDT Extras menu to show Moonrise and Moonset in 12 Hour format when Fahrenheit selected.
#					Removed leading zeros from weather.com forecast period dates.
#
# 5.11.29 02/18/23	Added Day and 52 week price ranges to stocks. New macro code: %R
#					Added 12 Hour time format for Sunrise, Sunset, Moonrise, and Moonset times.  
#					New macro codes: %!s & %!S and %!n & %!N 
#					
# 5.11.28 11/26/22	Restored TV Broadcaster info for NBA games. 
#					  Priority of TV Broadcaster Displayed = 1-National, 2-Away Team, 3-Home Team
#					Improved detection of End of Quarter for NBA games.
#					Removed unused perl libraries from distribution to
#					eliminate conflicts with other LMS plugins.  Thanks to @philippe_44
#
# 5.11.27 11/04/22	Adjusted College Basketball start of season for 2022
#					
# 5.11.26 10/25/22	Fixed weather and wunderground data retrieval issues.
#					Fixed NBA scores for 2022 season.
#					Added more error checking for weather.com indentifier entries.
#					Automatically add suffixes to US postal codes and weather.codes Station entries.
#					Improved display of weather station names.
#
# 5.11.25 			Skipped version.
#
# 5.11.24 08/21/22	Refined NFL json data retrieval.
#					Added setting for data refresh interval during active games. 
#
# 5.11.23 04/09/22	Added error handling for locations that do not have weather average data.
#
# 5.11.22 03/23/22	Updated to correctly handle new MLB team name for Cleveland.
#
# 5.11.21 02/23/22	Fixed bug preventing Stocks from displaying in the Extras->SDT menu.
#
# 5.11.20 02/13/22	Replaced deprecated URL for obtaining geolocation information.  
#					Added macro variables for wunderground observation time (%0) and refresh time (%!0)
#					Added setting for Player Check Delay following boot or LMS restart.  Reset default delay from 5 seconds to 90.
#					Updated Stock data source to current URL
#				
# 5.11.19 02/03/22	Fixed team icons for NCAA sports.
#					Added macro variable (%!1) to show status of last data refresh in Custom Clock screens.
#					Added French translations.  Thanks @steveJC
#					Fixed average and record temperatures.
#				
# 5.11.18 01/10/22	Fixed data retrieval issues from weather.com 
#					Added wind Gust for both wunderground and weather.com stations.
#				
# 5.11.17 11/10/21	Fixed SDT icon display in Extras menu on Jive/Jivelite platforms.  Thanks @MichaelPr 
#					Added Swedish translations. Thanks @robho 
#				
# 5.11.16 04/11/21	Added space between Wind Direction and Wind Speed.
#					wunderground compass directions are now adjusted for language selection.
#					Month names in 10-day forecast are now adjusted for language selection.
#					Month Day order in 10-day forecast is now adjusted based on temperature units selection. (F or C)
#					Added new macro variables for Wind Speed only.  (without Wind Direction)
#					Precipitation units adjusted in Extras->SDT menu based on selected temperature units. (F or C)
#					Improved formatting of WU temp and wind speed in Extras->SDT menu.					
#					Precipitation units in Extras->SDT are now adjusted based on F or C preference setting.
#
# 5.11.15 03/23/21	Added to option to disable visualizer when SDT is active.
#					
# 5.11.14 03/14/21	Fixed forecasted wind speed periods C, 1, 2, & 3. 
#					Added forecasted wind speeds for "10-day" periods.
#					Updated macro variables listing on the Settings->Player->SDT page.
#					mi/hr = %!w, km/hr = %!W, kt = %!q, m/s = %!Q
#
# 5.11.13 03/04/21	Added forecasted wind speed information. Access using these macro variables:
#					mi/hr = %!w, km/hr = %!W, kt/hr = %!q, m/s = %!Q
#					Fixed game detection for MLB sports scores
#
# 5.11.12 02/07/21	Added setting to shorten display names for professional sports teams.
#					Fixed setting for NBA team selection.
#
# 5.11.11 01/14/21	Fixed upcoming game times for NHL games.
#
# 5.11.10 01/12/21	Improvements to German language translation.  Thanks @bluetdi 
#
# 5.11.9  01/09/21	Added setting to select Air Pressure units displayed in Extras menu. 
#					Improved language localization.
#
# 5.11.8  01/06/21	Adapted wunderground to pull precision JSON data and limited rounding in 
#					temperature conversions to 1 decimal.
#
# 5.11.7  12/31/20	Added Feels-like temperature for wunderground weather stations. - Thanks @peterw
#
# 5.11.6  12/21/20	Corrected copy and paste error affecting chance of precip in 15-day forecasts.
#					Corrected logic causing rounded chance of precipitation to be blanked when chance equals 0.				
#
# 5.11.5  12/05/20	Added rounding to nearest 5% of precipitation chance values to 
#					account for change in weather source data to 1% resolution.
#					Added macro variables for 1% resolution values.
#
# 5.11.4  11/08/20	Fixed detection of active NFL games.
#					Corrected short NFL team identifiers for Raiders and Chargers.
#
# 5.11.3  10/04/20	Fixed NFL scores for 2020 season
#					Improved inning display count for MLB games that finish early.
#
# 5.11.2  08/23/20	Documented variable %G for Moon Phase description on Settings-->Player-->SDT page.
#					Added DE ES and NL translations for weather period "Currently".
#
# 5.11.1  05/05/20	Weather radar maps are now available through Custom Clock Helper itemtype: sdtweathermapicon 
#					Added max observed temperature to Extras->SDT menu
#					Corrected typos in the German translation on the settings page.  Thanks @carsten_h
#					Added rounding to barometric pressure hPa units.  Thanks @bluetdi
#
# 5.11.0  05/03/20	Corrected wind speed calculations when JSON file with metric data is used. - Thanks @robho
#					Corrected barometric pressure calculations when JSON file with metric data is used.
#
#					Bumped from 5.9.58 to 5.11.0 when Wunderground removed free access to API.
#					Started weather.com JSON rewrite with Greg Brown's 5.9.14 version.             
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#   02111-1307 USA
#
# This code is derived from code with the following copyright message:
#
# SliMP3 Server Copyright (C) 2001 Sean Adams, Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

package Plugins::SuperDateTime::Plugin;

use strict;

use POSIX qw(strftime);
use base qw(Slim::Plugin::Base);
use Slim::Utils::Misc;
use Slim::Utils::Strings qw (string);
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Control::Request;
use Plugins::SuperDateTime::Settings;
use Plugins::SuperDateTime::PlayerSettings;
use Time::Local; 
use JSON::XS::VersionOneAndTwo;
use LWP::Simple;
use Cwd 'abs_path';
use Math::Round qw(nearest);

my $prefs = preferences('plugin.superdatetime');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.superdatetime',
	'defaultLevel' => 'WARN',
	'description'  => getDisplayName(),
});

use vars qw($VERSION);
$VERSION = substr(q$Revision: 5.12.15$,10);

$Plugins::SuperDateTime::Plugin::apiVersion = 2.0;

sub getDisplayName {
	return 'PLUGIN_SCREENSAVER_SUPERDATETIME';
}

sub enabled {
	return ($::VERSION ge '7.0');
}

my %killTicker; #Flag used to exit out of ticker mode
my $status = '';  #Used for the status indicator
my %overlay; #Used to show alarm indicator
my $errorCount = 0; #Used to keep track of network errors
my $stopGetAvg = 0; #Used to stop retrieving getAverages data if location doesn't have them.
my $activeClients = 0; #Number of players currently displaying SuperDateTime
my $forecastNum; #Used to keep track of if today's forecast includes just today or today and tonight.  

#These preferences are used often so they're locally cached. Preset to default values.
my $showtime = 7; #How long to show the time when no games are active
my $showgame = 3; #How long to show an upcoming/completed game
my $showactivetime = 5; #How long to show the time when games are active
my $showactivegame = 3; #How long to show an active game
my $activeGames = 0; #Flag set if any games are active
my $newActiveGames; #Flag set during a data refresh if any games are active
my %scrollType = (); #Type of display scrolling between games per player

my %displayInfo; #Contains all the info shown when hitting up/down
my %displayInfoBuild; #Used while building display info in pieces

my %nowshowing; #What's now showing, 0 for time, Negative for long forecasts, etc
my %weathershowing; #Used for when the user chooses to just view the long weather forecasts via remote
my %topNowShowing; #Which item is being shown on top line during time display
my %displayLine1; #What is currently being shown on the display line 1 while cycling
my %displayLine2; #What is currently being shown on the display line 2 while cycling
my %tickline1; #Used to store previous value of display line 1 during ticker display

my %macroHash; #Used for custom macros that interfacing plugins may register

my $imagePath; #Used to store path to location for image storage.
my $wuKey = 'e1f10a1e78da46f5b10a1e78da96f525';
my $wcKey = '71f92ea9dd2f4790b92ea9dd2f779061';
my $lat = ''; # Used to store latitude of weather.com station location
my $long = ''; # Used to store longitude of weather.com station location
my $RndLat = ''; # Used to store rounded latitude for weather map URLs.
my $Rndlong = ''; # Used to store rounded longitude for weather map URLs.
my $placeId = ''; # Used to store placeId of weather.com station. 
my $country = ''; # Used to store country of weather.com station location.
my $countryCode = ''; # Store country code of weather.com station.  Used in sub getAirQuality.

my $dayCount = ''; # Used to store number of days in the extended forecast
my $units = ''; # Used to store units of measure preference (metric or US)  
                # based on temperature preference (celsius or fahrenheit)
my $funcptr = undef; # Used for external macros passed in for display

my %wetData = ();   #Stores weather-related data

my %wetMapFiles = ();	#Stores available weather map images locally
my %wetMapURLs = ();#Stores available weather image URLs
my $wetMapURL = '';	#Stores URL pointing to weather.com radar image
my $LocalURL = '';	#Stores URL pointing to weather.com Local radar image
my $MediumURL = '';	#Stores URL pointing to weather.com Medium range radar image
my $WideURL = '';	#Stores URL pointing to weather.com Wide range radar image

my %miscData = ();  #Stores misc data for use from jive interface (stocks)
my %sportsData = (); #Stores sport info for use from jive interface

#Track the average high/low for today/tomorrow
my %averages = ('last' => ''); #Used to store raw averages data and when they were last refreshed

#Used to store pointers to the data providers
my %providers= ('1'  => \&getWeatherToday,
				'2'  => \&getPollen,
				'3'  => \&getAirQuality,
				'4'  => \&getWunderground,
				'5'  => \&getAverages,
				'6'  => \&getMLB,
				'7'  => \&getNFL,
				'8'  => \&getNBA,
				'9'  => \&getWNBA,
				'10' => \&getNHL,
				'11' => \&getSoccer,
				'12' => \&getCBB,
				'13' => \&getCFB,
				'14' => \&getStocks);

my @WETdisplayItems1 = (); # Period for Long Forecasts
my @WETdisplayItems2 = (); # Long forecast text
my @WETdisplayItems3 = (); # Date for Long Forecasts

my @WETdisplayItems1temp = ();
my @WETdisplayItems2temp = ();

my $drawEachPending = 0;
my $drawEachPendingDelay;

my @refreshTracker = (); #Used to keep track of which fields to continue to refresh
my $lastRefresh = ''; #Date that pertains to @refreshTracker data

#Arrays to contain the user selected teams to monitor for each sport and icon mappings
my @MLBteams = ();
#Graphical icon mapping
my %MLBmap = ('Cubs'  => 10, 'White Sox'  => 11, 'Braves' => 12, 'Giants' => 13, 'Angels' => 14, 'Tigers' => 15, 'Astros' => 16, 'Reds' => 17, 'D-backs' => 18, 
			'Twins' => 19, 'Rays' => 20, 'Red Sox' => 21, 'Guardians' => 22, 'Rangers' => 24, 'Yankees' => 25, 'Orioles' => 26, 'Blue Jays' => 27, 'Royals' => 28, 
			'Athletics' => 29, 'Mariners' => 30, 'Pirates' => 31, 'Mets' => 32, 'Phillies' => 33, 'Marlins' => 34, 'Nationals' => 35, 'Brewers' => 36, 'Cardinals' => 37, 
			'Dodgers' => 38, 'Padres' => 39, 'Rockies' => 40 ); 
#icon mapping for Touch, Controller etc.
my %MLBICONmap = ('Cubs'  => 'chc', 'White Sox'  => 'chw', 'Braves' => 'atl', 'Giants' => 'sf', 'Angels' => 'laa', 'Tigers' => 'det', 'Astros' => 'hou', 'Reds' => 'cin', 
				'D-backs' => 'ari', 'Twins' => 'min', 'Rays' => 'tb', 'Red Sox' => 'bos', 'Guardians' => 'cle', 'Rangers' => 'tex', 'Yankees' => 'nyy', 'Orioles' => 'bal', 
				'Blue Jays' => 'tor', 'Royals' => 'kc', 'Athletics' => 'oak', 'Mariners' => 'sea', 'Pirates' => 'pit', 'Mets' => 'nym', 'Phillies' => 'phi', 'Marlins' => 'mia', 
				'Nationals' => 'wsh', 'Brewers' => 'mil', 'Cardinals' => 'stl', 'Dodgers' => 'lad', 'Padres' => 'sd', 'Rockies' => 'col' ); 
my @NBAteams = ();
my %NBAteamMap = ('PHI'   => '76ers', 'MIL'   => 'Bucks', 'CHI'   => 'Bulls', 'CLE'   => 'Cavaliers', 'BOS'   => 'Celtics', 'LAC'   => 'Clippers', 'MEM'   => 'Grizzlies',
				'ATL'   => 'Hawks', 'MIA'   => 'Heat', 'CHA'   => 'Hornets', 'UTA'   => 'Jazz', 'SAC'   => 'Kings', 'NYK'   => 'Knicks', 'LAL'   => 'Lakers',
				'ORL'   => 'Magic', 'DAL'   => 'Mavericks', 'BKN'   => 'Nets', 'DEN'   => 'Nuggets', 'IND'   => 'Pacers', 'NOP'   => 'Pelicans', 'DET'   => 'Pistons',
				'TOR'   => 'Raptors', 'HOU'   => 'Rockets', 'SAS'   => 'Spurs', 'PHX'   => 'Suns', 'OKC'   => 'Thunder', 'MIN'   => 'Timberwolves', 'POR'   => 'Trail Blazers',
				'GSW'   => 'Warriors', 'WAS'   => 'Wizards');
my @WNBAteams = ();
my @NHLteams = ();
my %NHLICONmap = ('vgk' => 'vgs', 'tbl' => 'tb', 'lak' => 'la', 'sjs' => 'sj','njd'=>'nj','uta'=>'utah');
my @NFLteams = ();
my %NFLmap = ('Bears'  => 10, 'Lions'  => 11, 'Packers' => 12); #Graphical icon mapping
my @NFL_Game_IDs = (); #Store gameIDs
my $NFL_GameCount = 0;
my $NFL_GameNum;
#### Global variables for soccer ####
my @soccerTeams = ();
my @soccer_Game_IDs = (); #Store gameIDs
my $soccer_GameCount;
my $soccer_GameNum;
#### Global variables for CBB ####
my @CBBteams = ();
my @CBB_Game_IDs = (); 
my $CBB_GameCount = 0;
my $CBB_GameNum;
#### Global variables for CFB ####
my @CFBteams = ();
my @CFB_Game_IDs = (); #Store gameIDs
my $CFB_GameCount;
my $CFB_GameNum;

#Graphical display stuff
my %xmax = ();
my %ymax = ();

my %hashDisp;

my $Gclient;

#
# Map ASCII characters to custom @Charset elements
#
my %Codepage = ( ' ' =>  0, '1' =>  1, '2' =>  2, '3' =>  3, '4' =>  4,
				 '5' =>  5, '6' =>  6, '7' =>  7, '8' =>  8, '9' =>  9,
				 '0' => 10, '-' => 11, '�' => 12, '.' => 13, '%' => 14,
				 'A' => 15, 'B' => 16, 'C' => 17, 'D' => 18, 'E' => 19,
				 'F' => 20, 'G' => 21, 'H' => 22, 'I' => 23, 'J' => 24,
				 'K' => 25, 'L' => 26, 'M' => 27, 'N' => 28, 'O' => 29,
				 'P' => 30, 'Q' => 31, 'R' => 32, 'S' => 33, 'T' => 34,
				 'U' => 35, 'V' => 36, 'W' => 37, 'X' => 38, 'Y' => 39,
				 'Z' => 40, '/' => 41, ':' => 42 );

#
# Custom 7x5 mono charset for 3-line forecast display on Squeezebox2
#
my @Charset = ('







','
  *
 **
* *
  *
  *
  *
*****
','
 ***
*   *
    *
   *
  *
 *
*****
','
 ***
*   *
    *
  **
    *
*   *
 ***
','
   *
  **
 * *
*****
   *
   *
   *
','
*****
*
*
****
    *
*   *
 ***
','
 ***
*
*
****
*   *
*   *
 ***
','
*****
    *
    *
   *
  *
 *
*
','
 ***
*   *
*   *
 ***
*   *
*   *
 ***
','
 ***
*   *
*   *
 ****
    *
    *
 ***
','
 ***
*   *
*   *
*   *
*   *
*   *
 ***
','



*****



','
 **
*  *
*  *
 **



','





  **
  **
','
**   
**  *
   *
  *
 *
*  **
   **
','
 ***
*   *
*   *
*****
*   *
*   *
*   *
','
****
*   *
*   *
****
*   *
*   *
****
','
 ***
*   *
*
*
*
*   *
 ***
','
****
*   *
*   *
*   *
*   *
*   *
****
','
*****
*
*
****
*
*
*****
','
*****
*
*
****
*
*
*
','
 ***
*   *
*
* ***
*   *
*   *
 ***
','
*   *
*   *
*   *
*****
*   *
*   *
*   *
','
 ***
  *
  *
  *
  *
  *
 ***
','
    *
    *
    *
    *
    *
*   *
 ***
','
*   *
*  *
* *
**
* *
*  *
*   *
','
*
*
*
*
*
*
*****
','
*   *
** **
* * *
*   *
*   *
*   *
*   *
','
*   *
*   *
**  *
* * *
*  **
*   *
*   *
','
 ***
*   *
*   *
*   *
*   *
*   *
 ***
','
****
*   *
*   *
****
*
*
*
','
 ***
*   *
*   *
*   *
*   *
* * *
*  **
 ** *
','
****
*   *
*   *
****
* *
*  *
*   *
','
 ****
*
*
 ***
    *
    *
****
','
*****
  *
  *
  *
  *
  *
  *
','
*   *
*   *
*   *
*   *
*   *
*   *
 *** 
','
*   *
*   *
*   *
*   *
*   *
 * *
  *
','
*   *
*   *
*   *
*   *
* * *
** **
*   *
','
*   *
*   * 
 * * 
  *  
 * * 
*   * 
*   *
','
*   *
*   *
 * *
  *
  *
  *
  *
','
*****
    *
   *
  *
 *
*
*****
','

    *
   *
  *
 *
*

','

 **
 **

 **
 **

');

#
# map standard weather.com icons to custom icons
#
my %Iconmap = ( '1'  => 2, '2'  => 2, '3'  => 2, '4'  => 2, '5'  => 23, 
                '6'  => 27,'7'  => 24,'8'  => 3, '9'  => 1, '10' => 3, 
                '11' => 25,'12' => 1, '13' => 18,'14' => 3, '15' => 19, 
                '16' => 20,'17' => 2, '18' => 26,'19' => 32,'20' => 33, 
                '21' => 10,'22' => 9, '23' => 11,'24' => 11,'25' => 30, 
                '26' => 0, '27' => 14,'28' => 6, '29' => 13,'30' => 5, 
                '31' => 12,'32' => 4, '33' => 13,'34' => 5, '35' => 2, 
                '36' => 31,'37' => 8, '38' => 8, '39' => 7, '40' => 28, 
                '41' => 21,'42' => 22,'43' => 22,'44' => 9, '45' => 15, 
                '46' => 16,'47' => 17,'48' => 29, '0' => 2, 'na' => 9,
                'NA' => 9, 'N/A' => 9 );

#
# Custom weather condition icons (40x32 pixel)
#
#234567890123456789012345678901234567890 - icon 0
my @Icons = ('





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
',
#234567890123456789012345678901234567890 - icon 1
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

     *         *        *
     *         *   *    *
    *    *    *    *   *
    *    *    *   *    *    *
   *    *    *    *    *    *
   *         *        *    *
  *         *         *    *
',
#234567890123456789012345678901234567890 - icon 2
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **     **         ** ***
     *      **          *** **
  ****     **            *   **
 **        **                 *
**        **                  **
*         **                   ***
*        ** **                   **
*        ******                   *
**       *** **                  **
 ***        **                  **
   ******************************
           **
          **
     *    **   *        *
     * * **    *   *    *
    *  ****   *    *   *
    *  *****  *   *    *    *
   *    **   *    *    *    *
   *    *    *        *    *
  *         *         *    *
',
#234567890123456789012345678901234567890 - icon 3
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

                           * *
      * *                *  *  *
    *  *  *               * * *
     * * *      * *      * *** *
    * *** *   *  *  *     * * *
     * * *     * * *     *  *  *
    *  *  *   * *** *      * *
      * *      * * *
              *  *  *
                * *
',
#234567890123456789012345678901234567890 - icon 4
'
                     *
        *            *
         *          *
          *         *
          *         *
           *       *          *
            *      *         *
                           **
                          *
 *            *****      *
  **        *********
    **     ***********
      *   *************
          *************
         ***************
         ***************
         ***************  *******
         ***************
         ***************
    ***   *************
****      *************
           ***********
            *********
              *****      *
                          *
           *               **
          *       *          *
         *        *           *
         *        *
        *          *
       *           *
                   *
',
#234567890123456789012345678901234567890 - icon 5
'
                     *
        *            *
         *          *
          *         *
          *         *
           *       *          *
            *      *         *
                           **
                          *
 *            *****      *
  **        *********
    **     *********** ****
      *   **********  **   *
          *********         **
         *********           * **
         *******              *  *
         ******                  **
         *****                    **
         *****                     *
    ***   *****                    *
****      *************************
           ***********
            *********
              *****      *
                          *
           *               **
          *       *          *
         *        *           *
         *        *
        *          *
       *           *
                   *
',
#234567890123456789012345678901234567890 - icon 6
'
                  *       *        *
                   *      *       *
                   *      *       *
                    *     *      *
                                *
              ****     *******
           ****  **** *********
        ****        ************     **
       **            ************  **
      **              ***********
     **                **********
     *                  *** *****
  ****                   *   ****
 **                           *** *
**                            ***  **
*                              ***   **
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
',
#234567890123456789012345678901234567890 - icon 7
'
                  *       *        *
                   *      *       *
                   *      *       *
                    *     *      *
                                *
              ****     *******
           ****  **** *********
        ****        ************     **
       **            ************  **
      **              ***********
     **                **********
     *                  *** *****
  ****                   *   ****
 **                           *** *
**                            ***  **
*                              ***   **
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

     *         *        *
     *         *   *    *
    *    *    *    *   *
    *    *    *   *    *    *
   *    *    *    *    *    *
   *         *        *    *
  *         *         *    *
',
#234567890123456789012345678901234567890 - icon 8
'
                  *       *        *
                   *      *       *
                   *      *       *
                    *     *      *
                                *
              ****     *******
           ****  **** *********
        ****        ************     **
       **            ************  **
      **              ***********
     **     **         **********
     *      **          *** *****
  ****     **            *   ****
 **        **                 *** *
**        **                  ***  **
*         **                   ***   **
*        ** **                   **
*        ******                   *
**       *** **                  **
 ***        **                  **
   ******************************
           **
          **
     *    **   *        *
     * * **    *   *    *
    *  ****   *    *   *
    *  *****  *   *    *    *
   *    **   *    *    *    *
   *    *    *        *    *
  *         *         *    *
',
#234567890123456789012345678901234567890 - icon 9
'






                *****
              *********
             ***    ***
             *       ***
                     ***
                     ***
                    ****
                   ****
                  ****
                 ****
                 ***
                ***
                ***
                ***
                ***


                ***
                ***
                ***
',
#234567890123456789012345678901234567890 - icon 10
'




    
 
                               
**   **    *     ****** **   **
**   **   ***        ** **   **
**   **   * *       **   ** **
*******  **  *     **     ***
**   **  *****    **       *
**   **  *   *   **        *
**   ** *     * **         *
**   ** *     * ********   *
  
  *     *     *    *     *                
    *      *     *    *      *  
 *     *  *       *       * 
     *       *         *    *      
      *            *        
    *       *           *

  *       *       *        *              
                
      *       *        *          
                 
           *       *         
',
#234567890123456789012345678901234567890 - icon 11 - Windy - Thanks Yannzola
'
                       *
        *****          **
       **   **         **
      **     *         ******
      *      ****      ******
      *         **     ******
   ****          *     ******
  **           ******* **********
 **                    **********
 *                     **********
 *          ********** **********
 **                    **************
  ***                  **************
    ****************** **************
                       **************
                       ****************
         *******       *****************
        **     **     **
        *       **   **
       **    *   *  **
       *    **     **
       *    *     **
   *****    **   **
  **         ** **   ************
 **           ***
 *
 *
 *             ************************
 *
 **
  ***
    *****************************
',
#234567890123456789012345678901234567890 - icon 12
'
                     
        
         
          
          
           
          
                     
                          
              *****      
            **     **
           *     *   *
          *     * **  *
          *           *
         *          *  *
         *    *        *
         *   **   *    *  
         **   *  ***   *
         ***     *    *
          **    **    *
          ** ***      *
           ****   *  *
            **  ** **
              *****      
                          
          
         
      
        
        
       
                   
',
#234567890123456789012345678901234567890 - icon 13
'
                     
        
         
          
          
           
          
                     
                          
              *****      
            **     **
           *        ** ****
          *        *  **   *
          *       *         **
         *      **           * **
         *     *              *  *
         *    *                  **
         *   *                    **
         *   *                     *
          *   *                    *
          *   *********************
           *         *
            **     **
              *****      
                          
          
         
      
        
        
       
                   
',
#234567890123456789012345678901234567890 - icon 14
'
                  
                   
                   
                               
                         *****       
              ****     **     **
           ****  **** *         *
        ****        **           *     
       **            **          *  
      **              **         *
     **                ** ***    *
     *                  *** **   *
  ****                   *   *  *
 **                           ** 
**                            **   
*                              ***   
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
',
#234567890123456789012345678901234567890 - icon 15
'
                  
                   
                   
                               
                         *****       
              ****     **     **
           ****  **** *         *
        ****        **           *     
       **            **          *  
      **              **         *
     **                ** ***    *
     *                  *** **   *
  ****                   *   *  *
 **                           ** 
**                            **   
*                              ***   
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

     *         *        *
     *         *   *    *
    *    *    *    *   *
    *    *    *   *    *    *
   *    *    *    *    *    *
   *         *        *    *
  *         *         *    *
',
#234567890123456789012345678901234567890 - icon 16
'
                  
                   
                   
                               
                         *****       
              ****     **     **
           ****  **** *         *
        ****        **           *     
       **            **          *  
      **              **         *
     **                ** ***    *
     *                  *** **   *
  ****                   *   *  *
 **                           ** 
**                            **   
*                              ***   
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

                           * *
      * *                *  *  *
    *  *  *               * * *
     * * *      * *      * *** *
    * *** *   *  *  *     * * *
     * * *     * * *     *  *  *
    *  *  *   * *** *      * *
      * *      * * *
              *  *  *
                * *
',
#234567890123456789012345678901234567890 - icon 17
'
                  
                   
                   
                               
                         *****       
              ****     **     **
           ****  **** *         *
        ****        **           *     
       **            **          *  
      **              **         *
     **     **         ** ***    *
     *      **          *** **   *
  ****     **            *   *  *
 **        **                 ** 
**        **                  **   
*         **                   ***   
*        ** **                   **
*        ******                   *
**       *** **                  **
 ***        **                  **
   ******************************
           **
          **
     *    **   *        *
     * * **    *   *    *
    *  ****   *    *   *
    *  *****  *   *    *    *
   *    **   *    *    *    *
   *    *    *        *    *
  *         *         *    *
',
#234567890123456789012345678901234567890 - icon 18
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

                         * *
                       *  *  *
                        * * *
                       * *** *
                        * * *
                       *  *  *
                         * *
                    
                     
                   
',
#234567890123456789012345678901234567890 - icon 19
'












                    * *
                  *  *  *
                   * * *
                  * *** *
                   * * *
                  *  *  * 
                    * *    * *
      * *                *  *  *
    *  *  *               * * *
     * * *      * *      * *** *
    * *** *   *  *  *     * * *
     * * *     * * *     *  *  *
    *  *  *   * *** *      * *
      * *      * * *
              *  *  *
                * *




',
#234567890123456789012345678901234567890 - icon 20
'




              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
        *  *  *     * * *
         * * *     *  *  *
        * *** *      * *    * *
   * *   * * *            *  *  *
 *  *  **  *  *            * * *
  * * *   * *   * *       * *** *
 * *** *      *  *  *      * * *
  * * *        * * *      *  *  *
 *  *  *      * *** *       * *
   * *         * * *
              *  *  *
                * *
',
#234567890123456789012345678901234567890 - icon 21
'
                  *       *        *
                   *      *       *
                   *      *       *
                    *     *      *
                                *
              ****     *******
           ****  **** *********
        ****        ************     **
       **            ************  **
      **              ***********
     **                **********
     *                  *** *****
  ****                   *   ****
 **                           *** *
**                            ***  **
*                              ***   **
*                                **
*                                 *
**                               **
 ***                            **
   ******************************

                           * *
      * *                *  *  *
    *  *  *               * * *
     * * *      * *      * *** *
    * *** *   *  *  *     * * *
     * * *     * * *     *  *  *
    *  *  *   * *** *      * *
      * *      * * *
              *  *  *
                * *   
',
#234567890123456789012345678901234567890 - icon 22
'

              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
  * *** *         *  *  *   * * *
   * * *           * * *   *  *  *
  *  *  *         * *** *    * *
    * *  *  *  *   * * *
          * * *   *  *  *
         * *** *    * *     * *
   * *    * * *           *  *  *
 *  *  * *  *  *           * * *
  * * *    * *  * *       * *** *
 * *** *      *  *  *      * * *
  * * *        * * *      *  *  *
 *  *  *      * *** *       * *
   * *         * * *
              *  *  *
                * *
',
#234567890123456789012345678901234567890 - icon 23
'

              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
   * *** *    *    *  *  *       
    * * *     *     * * *     *        
   *  *  *   *     * *** *   *         
     * *     *      * * *    *      
  *         *      *  *  *  *    
 *          *        * *    *
    * *                   
  *  *  *    *             
   * * *    *    * *       
  * *** *   *  *  *  *   *
   * * *   *    * * *    *
  *  *  *  *   * *** *  *    
 *  * *   *     * * *   *     
*         *    *  *  * *      
*                * *   *     
',
#234567890123456789012345678901234567890 - icon 24
'

              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
      *                 *  *         
      *  *  *  *  *          *          
  *  *   *   * * *     *  * *  *
 *   *  *   * *** *         *  *    
 *      *    * * *   *  *  *  *
*      *    *  *  *        *    
*  *   *      * *   *  *  *  
   *  *                      *
  *       * *      *  *     *
  *   * *  *  *         *   * 
 *    *  * * *   *  *  *   *  
 *   *  * *** *        *   *  
*    *   * * *  *  *  *   *
    *   *  *  *       *     
    *     * *  *  *  *       
',
#234567890123456789012345678901234567890 - icon 25
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
       *    *    *    *    *         
                             
       *    *    *    *    * 
                           
     *    *    *    *    *  
                           
     *    *    *    *    *  
                           
    *         *        *   
                                             
                      
',
#234567890123456789012345678901234567890 - icon 26
'




              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
     *     *     *     *     *         
        *     *     *     *      
     *     *     *     *     * 
        *     *     *     *    
     *     *     *     *     *  
        *     *     *     *   
     *     *     *     *     *  
        *     *     *     *   
     *     *     *     *     *   
        *     *     *     *    
                       
                      
',
#234567890123456789012345678901234567890 - icon 27
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
         *   *  *   *     *   *
     *     *   * *    * *
     * *     * *   *    *  * *
    *    * *  * *  *   *
    * *  *    *   * *  *  * *
   *    *  * *  * *    *    *
   *         *        *    *
  *  *   *  *   *  *  *  * *                    
',
#234567890123456789012345678901234567890 - icon 28
'





              ****
           ****  ****
        ****        **
       **            **
      **              **
     **                ** ***
     *                  *** **
  ****                   *   **
 **                           *
**                            **
*                              ***
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
       *    *    *    *     *
    *  *    *    *    * *   *
    * *    *  * * *  *  *  *
   *  * *  * *  * *  * *   *
   * *  * *  * * *  *  *  *  *
  *  * *  * *  * *  *  *  *  *
  * *  *    *   *  *  *  *  *
 *    *    *    *     *     *
',
#234567890123456789012345678901234567890 - icon 29
'
                  *       *        *
                   *      *       *
                   *      *       *
                    *     *      *
                                *
              ****     *******
           ****  **** *********
        ****        ************     **
       **            ************  **
      **              ***********
     **                **********
     *                  *** *****
  ****                   *   ****
 **                           *** *
**                            ***  **
*                              ***   **
*                                **
*                                 *
**                               **
 ***                            **
   ******************************
       *    *    *    *     *
    *  *    *    *    * *   *
    * *    *  * * *  *  *  *
   *  * *  * *  * *  * *   *
   * *  * *  * * *  *  *  *  *
  *  * *  * *  * *  *  *  *  *
  * *  *    *   *  *  *  *  *
 *    *    *    *     *     *
',
#234567890123456789012345678901234567890 - icon 30 Frigid - Thanks Yannzola
'


    *****                 *
   **   **                *
   *     *            *   *   *
   * *** *            *** * ***
   * *   *         *    *****    *
   * **  *         *     ***     *
   * *   *         *      *      *
   * *** *    ***  *      *      *  ***
   * *   *      ****      *      ****
   * **  *        ***     *      **
   * *   *      *** ***   *   *** ***
   * *** *    ***     *** * ***     ***
   * *   *              *****
   * **  *               ***
   * *   *              *****
   * *** *    ***     *** * ***     ***
   * *   *      *** ***   *   *** ***
   * **  *        ***     *     ***
   * *   *      ****      *      ****
   * *** *    ***  *      *      *  ***
  ** *** **        *      *      *
  * ***** *        *     ***     *
  * ***** *        *    *****    *
  * ***** *           *** * ***
  ** *** **           *   *   *
   **   **                *
    *****                 *
',
#234567890123456789012345678901234567890 - icon 31 HOT - Thanks Yannzola
'

                         *
    *****                *
   **   **               *
   *     *    *          *          *
   * *** *     *         *         *
   * *   *      *        *        *
   * *** *       *               *
   * *** *        *    *****    *
   * *** *           *********
   * *** *          ***********
   * *** *         *************
   * *** *         *************
   * *** *        ***************
   * *** *        ***************
   * *** * ****** *************** ******
   * *** *        ***************
   * *** *        ***************
   * *** *         *************
   * *** *         *************
   * *** *          ***********
   * *** *           *********
  ** *** **       *    *****    *
  * ***** *      *               *
  * ***** *     *        *        *
  * ***** *    *         *         *
  ** *** **   *          *          *
   **   **               *
    *****                *
                         *
',
#234567890123456789012345678901234567890 - icon 32 Dust - Thanks Yannzola
'

                 *******
                **     **
               **  *    *
               *        **
          ****** *  *    *
         **            * *
        **         *     *****
        *    *   *   *       **
        *  *             *    **
    *****                   *  *
   **        *   ******  *     *
  **   *  *     **    **       *
  *            **      **      *
  *       *  * *   *    *  *****
  *  *  *      *        ****   **
  *         ****    *           **
  **   *   **     *    *  *   *  *
   ***    **  *             *    *
     ******           *   *      ****
          *     * *           *     **
          **            *            **
           ***      *     *       *   *
             ******          *        *
                  *    *        *    **
                  *  *     ****    ***
                  **   *  **  ******
                   **    **
                    ******
',
#234567890123456789012345678901234567890 - icon 33 Fog - Thanks Yannzola
'
   ***********************************



   ***********************************



   ***********************************
                *********
               ***********

   ***********************************
             ***************
             ***************

   ***********************************
             ***************
   ***********************************

   ***********************************
                *********
   ***********************************

   ***********************************

   ***********************************

   ***********************************

   ***********************************
');

my $TWClogo = '
       ************************
       ************************
       ************************
       ************************
       ************************
       ************************
       *    *******************
       ** *  *** **************
       ** * * *   *************
       ** * * * ***************
       ** * * **  *************
       ************************
       * * * ****** ** ********
       * * * * *  *  *  ** *  *
       * * *    **  ** *     **
       ** * * **    ** *  ** **
       ** * **       * * *   **
       ************************
       **   **************** **
       * **  *  *   *   * ** **
       * ** * **  * * *    * **
       * ** *     * * *  *** **
       **   *     * * * *  ** *
       ************************



            * *
* * * * ** *****   *  **   **  * ** *
* * ****  * * * * *** *   *   * ** * *
** ***  *** * * * *   *   *   * ** * *
 * *  ***** *** *  ** * ** **  * * * *
';

our %mapping = ('arrow_up' => 'up',
					'arrow_right' => 'right',
					'arrow_left' => 'left',
					'knob_right' => 'up',
					'knob_left' => 'down',
					'knob_right.repeat' => 'up',
					'knob_left.repeat' => 'down',
					'add.single' => 'refresh',
					'arrow_down' => 'down',
					'arrow_down.hold' => 'down.hold',
					'fwd' => 'wnext',
					'rew' => 'wprev',
					'knob' => 'done',
					'size.hold'  => 'size.hold');

##################################################
### Super Functions ###
##################################################
sub initPlugin {
	my $class = shift;
	$class->SUPER::initPlugin();
	
	$log->info("Initializing SDT v".$VERSION);

	Plugins::SuperDateTime::Settings->new;
	Plugins::SuperDateTime::PlayerSettings->new;

	Slim::Buttons::Common::addSaver('SCREENSAVER.superdatetime', 
									 getScreensaverSuperDatetime(), 
									 \&setScreensaverSuperDateTimeMode,
									 \&leaveScreensaverSuperDateTimeMode,
									 getDisplayName()
								   );

	Slim::Hardware::IR::addModeDefaultMapping('SCREENSAVER.superdatetime',\%mapping);
	Slim::Hardware::IR::addModeDefaultMapping('OFF.superdatetime',\%mapping);

# Get previous settings or set default
	if ($prefs->get('SDTversion') eq '' || $prefs->get('SDTversion') lt '5.11.20') {	# Protect preferences set by users in versions 5.11.20 and later.
		$prefs->set('duetCkDelay', 90);				# Correct default value for duetCkDelay from version 5.11.19
	}
	$prefs->set('SDTversion', $VERSION);
	
	if (length($prefs->get('city')) eq 10 || length($prefs->get('city')) eq 13 and $prefs->get('city') =~ /.+\:\d\:\D\D/) { # Check for proper weather.com citycode format
		$log->debug("Valid weather.com station entry. " . $prefs->get('city'));
	}
	elsif (length($prefs->get('city')) eq 5 and $prefs->get('city') =~ /\d{5}/) { # Check for US postal code.
		$log->error("US Postal Code entered without suffix. " . $prefs->get('city'));
		my $zip = $prefs->get('city');
		$zip = $zip.":4:US";
		$prefs->set('city',$zip);
		$log->error("Suffix added.  Weather station set to " . $prefs->get('city'));
	}
	elsif (length($prefs->get('city')) eq 8 and $prefs->get('city') =~ /\D{4}\d{4}/) { #Check for weather.code weather station 
		$log->error("Weather.code station entered without suffix. " . $prefs->get('city'));
		my $station = $prefs->get('city');
		my $cc = substr($station,0,2);
		$station = $station.":1:".$cc; # Add suffix to weather station ID.
		$prefs->set('city',$station);
		$log->error("Suffix added.  Weather station set to " . $prefs->get('city'));
	}
	else # Entry for weather.com identifier is invalid.  Set to default of Chicago.
	{
		$log->error("Invalid Weather.com Identifier entered. " . $prefs->get('city'));
		$log->error("Check your Weather.com Station Identifier and try again");
		$prefs->set('city','60614:4:US'); #Default to Chicago... cuz Chicago is where it's at! 
		$log->error("Defaulting identifier to Chicago: " . $prefs->get('city'));
	}
	
	setImagePath();
	getLatLong(); # Retrieve Latitude and Longitude for weather.com location

	if ($prefs->get('stock1format') eq '') {
		$prefs->set('stock1format','%n');
	}

	if ($prefs->get('stock2format') eq '') {
		$prefs->set('stock2format','%l %c %z %v');
	}

	if ($prefs->get('lang') eq '') {
		$prefs->set('lang', 'en-US');
	}

	if ($prefs->get('refresh') eq '') {
		$prefs->set('refresh','5');
	}

	if ($prefs->get('arefresh') eq '') {
		$prefs->set('arefresh','5');
	}

	if ($prefs->get('time') eq '') {
		$prefs->set('time', $showtime);
	}

	if ($prefs->get('score') eq '') {
		$prefs->set('score', $showgame);
	}

	if ($prefs->get('atime') eq '') {
		$prefs->set('atime', $showactivetime);
	}

	if ($prefs->get('ascore') eq '') {
		$prefs->set('ascore', $showactivegame);
	}

	if ($prefs->get('offset') eq '') {
		$prefs->set('offset', '00');
	}

	if ($prefs->get('temperature') eq '') {
		$prefs->set('temperature', 0);
	}

	if ($prefs->get('windunit') eq '') {
		$prefs->set('windunit', 0);
	}

	if ($prefs->get('pressure') eq '') {
		$prefs->set('pressure', 0);
	}

	if ($prefs->get('teamlogos') eq '') {
		$prefs->set('teamlogos', 2);
	}

	if ($prefs->get('lweather') eq '') {
		$prefs->set('lweather', 1);
	}

	if ($prefs->get('soccerLeague') eq '') {
		$prefs->set('soccerLeague', 0);
	}

	if ($prefs->get('drawEachDelay') eq '') {
		$prefs->set('drawEachDelay', .5);
	}
	
	if ($prefs->get('errorCountMax') eq '') {   
		$prefs->set('errorCountMax', 10);
	}

	if ($prefs->get('duetCkDelay') eq '') {   
		$prefs->set('duetCkDelay', 90);
	}

	$showtime = $prefs->get('time');
	$showactivetime = $prefs->get('atime');

	$showgame = $prefs->get('score');
	$showactivegame = $prefs->get('ascore');
	
	@MLBteams = @{$prefs->get('mlb') || [] };
	if (scalar(@MLBteams) == 0) {
		$prefs->set('mlb', \@MLBteams);
	}
	if ($prefs->get('shortMLB') eq '') {  
		$prefs->set('shortMLB', undef);
	}

	@NBAteams = @{$prefs->get('nba') || [] };
	if (scalar(@NBAteams) == 0) {
		$prefs->set('nba', \@NBAteams);
	}
	if ($prefs->get('shortNBA') eq '') {  
		$prefs->set('shortNBA', undef);
	}

	@WNBAteams = @{$prefs->get('wnba') || [] };
	if (scalar(@WNBAteams) == 0) {
		$prefs->set('wnba', \@WNBAteams);
	}
	if ($prefs->get('shortWNBA') eq '') {  
		$prefs->set('shortWNBA', undef);
	}

	@NHLteams = @{$prefs->get('nhl') || [] };
	if (scalar(@NHLteams) == 0) {
		$prefs->set('nhl', \@NHLteams);
	}
	if ($prefs->get('shortNHL') eq '') {  
		$prefs->set('shortNHL', undef);
	}

	@NFLteams = @{$prefs->get('nfl') || [] };
	if (scalar(@NFLteams) == 0) {
		$prefs->set('nfl', \@NFLteams);
	}
	if ($prefs->get('shortNFL') eq '') {  
		$prefs->set('shortNFL', undef);
	}

	@CBBteams = @{$prefs->get('cbb') || [] };
	if (scalar(@CBBteams) == 0) {
		$prefs->set('cbb', \@CBBteams);
	}
	if ($prefs->get('shortCBB') eq '') {  
		$prefs->set('shortCBB', undef);
	}

	@CFBteams = @{$prefs->get('cfb') || []};
	if (scalar(@CFBteams) == 0) {
		$prefs->set('cfb', \@CFBteams);
	}
	if ($prefs->get('shortCFB') eq '') {  
		$prefs->set('shortCFB', undef);
	}

	@soccerTeams = @{$prefs->get('soccer') || []};
	if (scalar(@soccerTeams) == 0) {
		$prefs->set('soccer', \@soccerTeams);
	}
	
	#        |requires Client
	#        |  |is a Query
	#        |  |  |has Tags
	#        |  |  |  |Function to call
	#        C  Q  T  F
	Slim::Control::Request::addDispatch(['SuperDateTime', '_mode'],
			  [1, 1, 1, \&cliQuery]);

	$funcptr = Slim::Control::Request::addDispatch(['sdtMacroString'],
			  [1, 1, 1, \&macroString]);

	Slim::Control::Request::addDispatch(['sdtVersion'],
			  [1, 1, 1, \&sdtVersion]);
	
	#Experimental
	Slim::Control::Request::addDispatch(['SuperDateTimeState', 'dataRefreshState'],[0, 1, 0, undef]);
	
	Slim::Control::Request::addDispatch(['sdtTop'],[1, 1, 0, \&sdtTop]);
	Slim::Control::Request::addDispatch(['sdtCurrentWEA'],[1, 1, 0, \&sdtCurrentWEA]);
	Slim::Control::Request::addDispatch(['sdtCurrentWU'],[1, 1, 0, \&sdtCurrentWU]);
	Slim::Control::Request::addDispatch(['sdtForecast'],[1, 1, 0, \&sdtForecast]);
	Slim::Control::Request::addDispatch(['sdtForecastDetail','_forecastNum'],[1, 1, 0, \&sdtForecastDetail]);
	Slim::Control::Request::addDispatch(['sdt15day'],[1, 1, 0, \&sdt15day]);
	Slim::Control::Request::addDispatch(['sdtScores'],[1, 1, 0, \&sdtScores]);
	Slim::Control::Request::addDispatch(['sdtStocks'],[1, 1, 0, \&sdtStocks]);
	Slim::Control::Request::addDispatch(['sdtStockDetail','_ticker'],[1, 1, 0, \&sdtStockDetail]);
	Slim::Control::Request::addDispatch(['sdtGameList','_sport'],[1, 1, 0, \&sdtGameList]);
	
	my @menu = ({
		text   => 'SuperDateTime',
		'icon-id' => 'plugins/SuperDateTime/html/images/icon.png',
		id     => 'pluginSuperDateTime',
		weight => 15,
		actions => {
				go => {
					player => 0,
					cmd  => [ 'sdtTop' ],
					params => {
						menu => 'nowhere',
					},
				},
		},
	});

	Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + $prefs->get('duetCkDelay'), \&duetCheck);
	
	Slim::Control::Jive::registerPluginMenu(\@menu, 'extras');

}

sub sdtTop {
	my $request = shift;
	my $client = $request->client();
	my @menu = ();

	duetCheck(); #If we're in here there must be a duet-like device connected...

	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/weather.png',
			text => "$wetData{'WthStatName'}\nLatitude: $lat; Longitude: $long",
			window => { menuStyle => 'album' },
			actions  => {
			  go  => {
				  player => 0,
				  cmd    => [ 'sdtCurrentWEA' ],
				  params => {
					menu => 'nowhere',
				  },
			  },
			},
	};
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/weather.png',
		text => $client->string('PLUGIN_SCREENSAVER_SDT_FORECAST'),
		window => { menuStyle => 'album' },
		actions  => {
		  go  => {
			  player => 0,
			  cmd    => [ 'sdtForecast' ],
			  params => {
				menu => 'nowhere',
			  },
		  },
		},
	};
	
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/weather.png',
		text => $client->string('PLUGIN_SCREENSAVER_SDT_15DAYF'),
		window => { menuStyle => 'album' },
		actions  => {
		  go  => {
			  player => 0,
			  cmd    => [ 'sdt15day' ],
			  params => {
				menu => 'nowhere',
			  },
		  },
		},
	};  

	if ($wetData{'wu_check'}) {
		push @menu, {
			'icon-id' => 'plugins/SuperDateTime/html/images/wuLogo.png',
				text => "$wetData{'wu_nhood'} ($wetData{'wu_station'})\nLatitude: $wetData{'wu_latitude'}; Longitude: $wetData{'wu_longitude'}",
				window => { menuStyle => 'album' },
				actions  => {
				  go  => {
					  player => 0,
					  cmd    => [ 'sdtCurrentWU' ],
					  params => {
						menu => 'nowhere',
					  },
				  },
				},
		};
	}
   
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/sports.png',
		text => $client->string('PLUGIN_SCREENSAVER_SDT_SPORT'),
		window => { menuStyle => 'album' },
		actions  => {
		  go  => {
			  player => 0,
			  cmd    => [ 'sdtScores' ],
			  params => {
				menu => 'nowhere',
			  },
		  },
		},
	};
	
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/stocks.png',
		text => $client->string('PLUGIN_SCREENSAVER_SDT_STOCKS'),
		window => { menuStyle => 'album' },
		actions  => {
		  go  => {
			  player => 0,
			  cmd    => [ 'sdtStocks' ],
			  params => {
				menu => 'nowhere',
			  },
		  },
		},
	};
	
	my $numitems = scalar(@menu);
	
	$request->addResult("base", {window => { titleStyle => 'album' }}); 
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub duetCheck {
	#Look for any players that don't have a screen.  This implies they probably have a Duet that they want to utilize the plugin with
	#Duets are always active, so update plugin accordingly
	my @players = Slim::Player::Client::clients();
	$log->debug("Player count: ". scalar(@players));
	if (scalar(@players) eq 0) {
		Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 60, \&duetCheck);	# If no players are found wait 60 seconds and check again.
		$log->error("No players found.  Checking again in 60 seconds.");
	}
	$log->debug("Count of players with SDT active: ". $activeClients);
	if ($activeClients == 0) {
		$log->debug("No active SDT clients so checking for Touch, Radio, Duet only configuration.");
		for my $player (@players) {
			$log->debug("Player name = ".$player->name);
			$log->debug("Player type = ".$player->model);
			$log->debug("Player display = ".$player->display);
			if ($player->display->isa('Slim::Display::NoDisplay')) {
					$activeClients++;
					Slim::Utils::Timers::killTimers(undef, \&refreshData); #Paranoia check
					Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 5, \&refreshData, $player, -1);
					$log->debug("Touch, Radio, or Non-display player found. Configuring SDT to always refresh data.");
			}
			$log->debug(" ");
		}
	}
}

sub sdt15day {
	my $request = shift;
	my $client = $request->client();
	
	my @menu = ();
	my $i=1;
	$log->debug('sdt15day Count: ' . $dayCount);
	my $ForC;
	if ($prefs->get('temperature') == 1) {  #Cel
		$ForC = 'C';
	}
	else {
		$ForC = 'F';
	}
	
	while ($i < $dayCount) { 
		push @menu, {
			'icon-id' => 'plugins/SuperDateTime/html/images/'.$wetData{'d'.$i}{'forecastIcon'}.'.png',
			text => $wetData{'d'.$i}{'day'}.' '.$wetData{'d'.$i}{'date'}.
				$wetData{'d'.$i}{'condition'}.' '.$wetData{'d'.$i}{'high'.$ForC} . '�/' .$wetData{'d'.$i}{'low'.$ForC} . '� '.$client->string('PLUGIN_SCREENSAVER_SDT_PRECIP'). $wetData{'d'.$i}{'precipR'}.'%',
		};
		$i++;
	}
	
	my $numitems = scalar(@menu);
	
	$request->addResult("base", {window => { titleStyle => 'album' }}); 
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub sdtStocks {
	my $request = shift;
	my $client = $request->client();
	
	my @menu = ();

	my $tickers = $prefs->get('stocks');
	$tickers =~ tr/ /,/s; # Convert space delimited to comma delimited.
	$tickers =~ tr/,//s;
	my @stocks = split (',', $tickers);
	my $stockCount = scalar(@stocks);

	my $loopctr = 0;
	
	while ($loopctr < $stockCount) {
		push @menu, {
			text => $miscData{'stocks'}{$stocks[$loopctr]}{'ticker'}. ' - '.
						$miscData{'stocks'}{$stocks[$loopctr]}{'lasttrade'}. ' ('.$miscData{'stocks'}{$stocks[$loopctr]}{'change'}. ')',
		 actions  => {
		   go  => {
			   player => 0,
			   cmd    => [ 'sdtStockDetail', $stocks[$loopctr] ],
			   params => {
				menu => 'nowhere',
			   },
		   },
		 },
		};
		$loopctr ++;
	}
	
	my $numitems = scalar(@menu);
	
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub sdtStockDetail {
	my $request = shift;
	my $client = $request->client();
	my $ticker = $request->getParam('_ticker');

	my @menu = ();
	
	push @menu, {
		text => $miscData{'stocks'}{$ticker}{'name'}
		,
	};

	push @menu, {
		text =>     'Prev Close: '.$miscData{'stocks'}{$ticker}{'prevclose'}
		,
	};

	push @menu, {
		text =>     'Open: '.$miscData{'stocks'}{$ticker}{'open'}
		,
	};

	push @menu, {
		text =>     'Last: '.$miscData{'stocks'}{$ticker}{'lasttrade'} . 
					' ('.$miscData{'stocks'}{$ticker}{'change'}.')' . ' ('.$miscData{'stocks'}{$ticker}{'pchange'}.')'
		,
	};

	push @menu, {
		text => 'Day Range: '.$miscData{'stocks'}{$ticker}{'RangeDay'}
		,
	};

	push @menu, {
		text => '52 Week Range: '.$miscData{'stocks'}{$ticker}{'R52Week'}
		,
	};

	push @menu, {
		text =>     'Volume: '.$miscData{'stocks'}{$ticker}{'volume'}
		,
	};

	push @menu, {
		text =>     $miscData{'stocks'}{$ticker}{'lasttime'}.' '.$miscData{'stocks'}{$ticker}{'lastdate'}
		,
	};

	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();
}

sub sdtForecast {
	my $request = shift;
	my $client = $request->client();
	
	my @menu = ();
	my $i = 0;
	my $mxPer = 0;
	
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);

		$mxPer = 4;

	$log->debug("Max periods = " . $mxPer . " at hour # " . $hour);
	
	my $ForC;
	if ($prefs->get('temperature') == 1) {  #Cel
		$ForC = 'C';
	}
	else {
		$ForC = 'F';
	}
		
	while ($i < $mxPer) {   
		push @menu, {
			'icon-id' => 'plugins/SuperDateTime/html/images/'.$wetData{$i}{'forecastIcon'}.'.png',
			text => $wetData{$i}{'forecastTOD'}.": ".$wetData{$i}{'skyCondition'}."\n".
				$wetData{$i}{'forecastType'} .' '. $wetData{$i}{'forecastTemp'.$ForC} . '� '.$client->string('PLUGIN_SCREENSAVER_SDT_PRECIP'). $wetData{$i}{'forecastPrecR'}.'%',
				actions  => {
					  go  => {
						  player => 0,
						  cmd    => [ 'sdtForecastDetail', $i ],
						  params => {
						  menu => 'nowhere',
						  },
				},
			},
		};
				
		$i++;
	}
		
	my $numitems = scalar(@menu);
	
	$request->addResult("base", {window => { titleStyle => 'album' }}); 
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub sdtForecastDetail {
	my $request = shift;
	my $client = $request->client();
	my $forecastNum = $request->getParam('_forecastNum');
	my @menu = ();

	push @menu, {
		text => $WETdisplayItems2[$forecastNum],
	};

	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();
}

sub sdtCurrentWEA {
	my $request = shift;
	my $client = $request->client();
	
	my @menu = ();

	my $ForC = '';
	my $inORmm = '';
	my $inORcm = '';
	my $Hmr = '';
	my $Hms = '';
	if ($prefs->get('temperature') == 1) {  #Cel
		$ForC = 'C';
		$inORmm = ' mm';
		$inORcm = ' cm';
		$Hmr = $wetData{-1}{'moonrise'};
		$Hms = $wetData{-1}{'moonset'};
	}
	else {
		$ForC = 'F';
		$inORmm = '"';
		$inORcm = '"';
		$Hmr = $wetData{-1}{'moonrise12'};
		$Hms = $wetData{-1}{'moonset12'};
	}
	
	my $INorMB = '';
	if ($prefs->get('pressure') == 1) {  #mb
		$INorMB = 'MB';
	}
	else {
		$INorMB = 'IN';
	}
	
	my $WindUnit = '';
	if ($prefs->get('windunit') == 0) {  #mi/hr
		$WindUnit = 'mh';
	}
	elsif ($prefs->get('windunit') == 1) {  #km/hr
		$WindUnit = 'kh';
	}
	elsif ($prefs->get('windunit') == 2) {  #kt
		$WindUnit = 'kth';
	}
	else {  #m/s
		$WindUnit = 'ms';
	}

	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/'.$wetData{-1}{'forecastIcon'}.'.png',
			  text => $wetData{-1}{'skyCondition'}.' '.$wetData{'temperature'.$ForC}.'� ('.$wetData{'feelslike'.$ForC}.'�) '. $wetData{'windspeed_'.$WindUnit}."\n".
					  $wetData{-1}{'forecastType'}.' '. $wetData{-1}{'forecastTemp'.$ForC}.'� '.$client->string('PLUGIN_SCREENSAVER_SDT_PRECIP').$wetData{-1}{'forecastPrecR'}.'%  '.$client->string('PLUGIN_SCREENSAVER_SDT_MOT').$wetData{'MaxTemp'.$ForC}.'�',
		 actions  => {
		   go  => {
			   player => 0,
			   cmd    => [ 'sdtForecastDetail', 0 ],
			   params => {
			   menu => 'nowhere',
			   },
		   },
		 },
	};
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/blank.png',
			  text => $client->string('PLUGIN_SCREENSAVER_SDT_PRESSURE').$wetData{'pressure'.$INorMB}.' '.$wetData{'pressureT'}."\n".
					  $client->string('PLUGIN_SCREENSAVER_SDT_HUMIDITY').$wetData{'humidity'}.'% '.$client->string('PLUGIN_SCREENSAVER_SDT_DEW').$wetData{'dewpoint'.$ForC}.'�',
	};
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/blank.png',
			  text => $client->string('PLUGIN_SCREENSAVER_SDT_24HP')."\n".
						$client->string('PLUGIN_SCREENSAVER_SDT_RAIN').$wetData{'rain'}.$inORmm."   ".
						$client->string('PLUGIN_SCREENSAVER_SDT_SNOW').$wetData{'snow'}.$inORcm."\n",
	};
	push @menu, {
		'icon-id' => $wetMapURL,
		type => ($client && $client->controllerUA || '') =~ /squeezeplay/i ? 'link' : 'slideshow',
		text => $client->string('PLUGIN_SCREENSAVER_SDT_MAP'),
		image => $wetMapURL,
		name => $client->string('PLUGIN_SCREENSAVER_SDT_MAP'),
		jive  => {
			showBigArtwork => 1,
			actions => {
				do => {
					cmd => [ 'artwork', $wetMapURL ]
				},
			},
		},
	};
	push @menu, {
		'icon-id' => $wetData{'moonphaseURL'},
			text => $wetData{-1}{'moonPhrase'}."\n".$client->string('PLUGIN_SCREENSAVER_SDT_RISE').$Hmr." ".$client->string('PLUGIN_SCREENSAVER_SDT_SET').$Hms
	};

	my $numitems = scalar(@menu);
	
	$request->addResult("base", {window => { titleStyle => 'album' }}); 
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub sdtCurrentWU {
	my $request = shift;
	my $client = $request->client();
	
	my @menu = ();

	my $ForC = '';
	if ($prefs->get('temperature') == 1) {  #Cel
		$ForC = 'C';
	}
	else {
		$ForC = 'F';
	}
	
	my $INorMB = '';
	if ($prefs->get('pressure') == 1) {  #mb
		$INorMB = 'MB';
	}
	else {
		$INorMB = 'IN';
	}
	
	my $WindUnit = '';
	if ($prefs->get('windunit') == 0) {  #mi/hr
		$WindUnit = 'mh';
	}
	elsif ($prefs->get('windunit') == 1) {  #km/hr
		$WindUnit = 'kh';
	}
	elsif ($prefs->get('windunit') == 2) {  #kt
		$WindUnit = 'kth';
	}
	else {  #m/s
		$WindUnit = 'ms';
	}

	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/blank.png',
			  text => $client->string('PLUGIN_SCREENSAVER_SUPERDATETIME_CURRENTLY').": ".$wetData{'wu_temperature'.$ForC}.'� '.$ForC."\n".
					  $wetData{'wu_windspeed_'.$WindUnit}." ".$WindUnit,
		 actions  => {
		   go  => {
			   player => 0,
			   cmd    => [ 'sdtForecastDetail', 0 ],
			   params => {
				menu => 'nowhere',
			   },
		   },
		 },
	};
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/blank.png',
			  text => $client->string('PLUGIN_SCREENSAVER_SDT_PRESSURE').$wetData{'wu_pressure'.$INorMB}."\n".
					  $client->string('PLUGIN_SCREENSAVER_SDT_HUMIDITY').$wetData{'wu_humidity'}.'% '.$client->string('PLUGIN_SCREENSAVER_SDT_DEW').$wetData{'wu_dewpoint'.$ForC}.'�',
	};
	push @menu, {
		'icon-id' => 'plugins/SuperDateTime/html/images/blank.png',
			  text => $client->string('PLUGIN_SCREENSAVER_SDT_PRECIPTOT').$wetData{'wu_precipTotIN'}."\n",
	};
	push @menu, {
		'icon-id' => $wetData{'moonphaseURL'},
			text => $wetData{-1}{'moonPhrase'}."\n".$client->string('PLUGIN_SCREENSAVER_SDT_RISE').$wetData{-1}{'moonrise'}." ".$client->string('PLUGIN_SCREENSAVER_SDT_SET').$wetData{-1}{'moonset'}
	};
	
	my $numitems = scalar(@menu);
	
	$request->addResult("base", {window => { titleStyle => 'album' }}); 
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub sdtScores {
	my $request = shift;
	my $client = $request->client();
	
	my @menu = ();
	for my $key ( sort keys %sportsData ) {
		my $icon;
			
		$icon = $sportsData{$key}{'logoURL'};
		if (not defined $icon) {
			$icon = 'plugins/SuperDateTime/html/images/blank.png';
		}
		
		push @menu, {
				'icon-id' => $icon,
				text => $key,
				window => { menuStyle => 'album' },
				actions  => {
						   go  => {
	#7.3 menustyle=multiline to remove icons entirely
								player => 0,
								cmd => [ 'sdtGameList', $key ],
								params => {
								menu => 'nowhere',
							   },
						   },
		 },
		}
		
	}   
	
	my $numitems = scalar(@menu);
	
	$request->addResult("base", {window => { titleStyle => 'album' }}); 
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);

	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
}

sub sdtGameList {
	my $request = shift;
	my $client = $request->client();
	my $sport = $request->getParam('_sport');

	my @menu = ();
	my $hashRef = \%sportsData;
	
	for my $key (sort keys %{$hashRef->{$sport}} ) {
		if ($key ne 'logoURL') {
			my $logo = 'plugins/SuperDateTime/html/images/blank.png';
			if (defined $sportsData{$sport}{$key}{'gameLogoURL'}) {
				$logo = $sportsData{$sport}{$key}{'gameLogoURL'};
			}
			$log->debug("Game Logo: " . $logo);
		
			push @menu, {
				'icon-id' => $logo,
#               text => "$sportsData{$sport}{$key}{'awayTeam'} $sportsData{$sport}{$key}{'awayScore'} \n $sportsData{$sport}{$key}{'homeTeam'} $sportsData{$sport}{$key}{'homeScore'} \n $sportsData{$sport}{$key}{'gameTime'}",
				text => $sportsData{$sport}{$key}{'awayTeam'}.' '.$sportsData{$sport}{$key}{'awayScore'}."\n".$sportsData{$sport}{$key}{'homeTeam'}.' '.$sportsData{$sport}{$key}{'homeScore'}.' ('.$sportsData{$sport}{$key}{'gameTime'}.')',
			};
		}
	}   

	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();
}

sub FtoC {
	my $temp = shift;

	$temp = nearest(.1,($temp-32)*5/9);
	
	return $temp;
}

sub CtoF {
	my $temp = shift;

	$temp = nearest(.1,($temp*9/5)+32);
	
	return $temp;
}

sub C24to12 {
	my $time = shift;
	$log->debug("Time in: " . $time);
	my $Hr = '';
	my $Min = '';
	my $AmPm = 'AM';
	if ($time =~ /(\d+)\:(\d+)/) {	# Extract hours and minutes
		$Min = $2;
		$Hr = $1;
		$Hr =~ s/^0+(?=[0-9])//;
		if ($Hr == 0) {				# Midnight hour 12:xx AM
			$Hr = $Hr + 12;
		}
		elsif ($Hr == 12) {			# Noon hour 12:xx PM
			$AmPm = 'PM';
		}
		elsif ($Hr > 12) {			# Afternoon convert to 12 Hr format
			$Hr = $Hr - 12;
			$AmPm = 'PM';
		}
		$time = $Hr . ":" . $Min . ' ' . $AmPm;
	}
	$log->debug("Time out: " . $time);
	return $time;
}

sub setImagePath {
	# Establish location on LMS server to store images.
	# This varies depending on platform and install location of SDT plugin.
	
	my $cwd = abs_path(__FILE__);
	$log->debug("Path to SDT plugin.pm: " . $cwd);
	
	my $SDTlibPos = index($cwd, 'lib/Plugins/SuperDateTime');
	$log->debug("# of characters to retain from SDT plugin path: " . $SDTlibPos);
	
	$imagePath = substr($cwd, 0, $SDTlibPos);
	$imagePath = $imagePath . 'HTML/EN/plugins/SuperDateTime/html/images/';
	$log->debug("Image path: " . $imagePath);
}

sub getLatLong {  #Set up Async HTTP request to retrieve Latitude and Longitude
    my $timerObj = shift; #Should be undef
    my $client = shift;
    my $refreshItem = shift;

	my $url = 'https://api.weather.com/v3/location/point?format=json&language='.$prefs->get('lang').'&locid='.$prefs->get('city').'&apiKey='.$wcKey;
    my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotLatLong,
                              \&gotErrorViaHTTP,
                              {caller => 'getLatLong', callerProc => \&getLatLong,});

	$log->debug("async request: $url");
    
    $http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0',
    'Accept-Language' => 'en-us,en;q=0.5',
    'Accept' => 'text/plain',
    'Accept-Charset' => 'UTF-8');
}

sub gotLatLong {
    my $http = shift;
    
    my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
    $log->info("got " . $logURL);

    my $LatLong_json = $http->content();
    my $perldata = eval{decode_json($LatLong_json)};
	if ($@) {
		$log->error("Error detected in Weather.com location JSON file. Error: ".$@);
		$log->error("Check the WEATHER.COM IDENTIFIER entry on the Advanced->SuperDateTime settings page.");
		return;
	}

    $lat = $perldata->{'location'}->{'latitude'};
    $long = $perldata->{'location'}->{'longitude'};
    $placeId = $perldata->{'location'}->{'placeId'};
	$country = $perldata->{'location'}->{'country'};
	$countryCode = $perldata->{'location'}->{'countryCode'};
	$wetData{'WthStatName'} = $perldata->{'location'}->{'displayName'}.', '.$perldata->{'location'}->{'adminDistrict'}.' ('.$perldata->{'location'}->{'postalCode'}.'), '.$perldata->{'location'}->{'country'};
    $log->info("Weather Station: " . $prefs->get('city'));
    $log->info("Weather Station Name: " . $wetData{'WthStatName'});
    $log->info("Weather Station Lat: " . $lat);
    $log->info("Weather Station Long: " . $long);
    $log->info("Weather Place ID: " . $placeId);
    $log->info("Weather Station Location: " . $wetData{'WthStatName'});

	# Setup URL for weather radar image for this location.  Lat & Long resolution restricted to .0 or .5 increments
	# Round Latitude and Longitude for weather map URLs
	my $RndLat = sprintf("%.0f",$lat * 2);
	$RndLat = sprintf("%.1f",$RndLat/2);
	my $RndLong = sprintf("%.0f",$long * 2);
	$RndLong = sprintf("%.1f",$RndLong/2);
	my $lang = substr($prefs->get('lang'),0,2);
	
	# URLs to internet location of map images.
	$LocalURL = 'https://api.weather.com/v2/maps/dynamic?geocode='.$RndLat.','.$RndLong.'&h=600&w=800&lod=7&product=radarFcst&map=light&format=jpg&language='.$lang.'&apiKey='.$wcKey;
	$MediumURL = 'https://api.weather.com/v2/maps/dynamic?geocode='.$RndLat.','.$RndLong.'&h=600&w=800&lod=6&product=radarFcst&map=light&format=jpg&language='.$lang.'&apiKey='.$wcKey;
	$WideURL = 'https://api.weather.com/v2/maps/dynamic?geocode='.$RndLat.','.$RndLong.'&h=600&w=800&lod=5&product=radarFcst&map=light&format=jpg&language='.$lang.'&apiKey='.$wcKey;
	
	# File locations to store weather map images locally
	my $fileL = $imagePath.'MAPS/mapLocal.jpg';
	my $fileM = $imagePath.'MAPS/mapMedium.jpg';
	my $fileW = $imagePath.'MAPS/mapWide.jpg';

	# Retrieve and store map images locally on SDT start or weather station location change
	my $response = getstore($LocalURL, $fileL);
	if (is_success($response)) { # Error check
	    $log->debug("Weather Map Local successfully stored! Response: " . $response);
	}
	else {
	    $log->warn("Storing Weather Map Local FAILED! Response: " . $response);
	}
	my $response = getstore($MediumURL, $fileM);
	if (is_success($response)) {
	    $log->debug("Weather Map Medium successfully stored! Response: " . $response);
	}
	else {
	    $log->warn("Storing Weather Map Medium FAILED! Response: " . $response);
	}
	my $response = getstore($WideURL, $fileW);
	if (is_success($response)) {
	    $log->debug("Weather Map Wide successfully stored! Response: " . $response);
	}
	else {
	    $log->warn("Storing Weather Map Wide FAILED! Response: " . $response);
	}
	
	# Pointers to locally stored images for Custom Clock
	$wetMapFiles{'Local'}{'URL'} = $imagePath.'MAPS/mapLocal.jpg';
	$wetMapFiles{'Medium'}{'URL'} = $imagePath.'MAPS/mapMedium.jpg';
	$wetMapFiles{'Wide'}{'URL'} = $imagePath.'MAPS/mapWide.jpg';	
	
	# Used in SDT Extras menu
	$wetMapURL = '/plugins/SuperDateTime/html/images/MAPS/mapLocal.jpg';
	
	my $data = {
		'state' => 'MapRefreshSuccess'
	};

	$log->debug("Completed weather map image refresh.");
	Slim::Control::Request::notifyFromArray(undef,['SuperDateTimeState','dataRefreshState',$data]);
	$stopGetAvg = 0; #Location may have changed so check for averages again.
}

sub getAverages {  #Set up Async HTTP request for averages
    my ($days_advance, $client, $refreshItem) = @_;

#   Extract month and day for JSON URL 
    my ($mday,$mon) = (localtime)[3,4];
    $mon = sprintf("%02d",$mon+1);
    $mday = sprintf("%02d",$mday);

	if ($stopGetAvg eq 0) { # First check for averages OR historical data available for location.
		if (($wetData{0}{'forecastTOD'} ne $averages{'last'})) { #Only refresh averages twice a day. i.e - day/night transition.   
			my $url = 'https://api.weather.com/v3/wx/almanac/daily/5day?geocode='.$lat.','.$long.'&units=e&startDay='.$mday.'&startMonth='.$mon.'&format=json&apiKey='.$wuKey;

			my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotAverages,
									\&gotErrorViaHTTP,
									{caller => 'getAverages',
									 dayNum => $days_advance,
									 client => $client,
									 refreshItem => $refreshItem});

			$log->debug("async request: $url");
			$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0',
				'Accept-Language' => 'en-us,en;q=0.5',
				'Accept' => 'text/plain',
				'Accept-Charset' => 'UTF-8');
		}
		else {
			$log->info("Skipping averages until next day/night transition.");
			refreshData(undef, $client, $refreshItem);
		}
	}
	else {
		$log->info("Average data not available for location ".$prefs->get('city'). ".  Skipping until next SDT settings change.");
		refreshData(undef, $client, $refreshItem);
	}
	
}

sub gotAverages {  #Average data was received
    my $http = shift;
    
    my $params = $http->params();
    my $client = $params->{'client'};
    my $refreshItem = $params->{'refreshItem'};
  
    my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
    $log->info("got " . $logURL);

    my $json = $http->content();

    # Convert JSON into a Perl data array
    my $perldata = eval{decode_json($json)}; 
	if ($@) {
		$log->error("Error detected in Weather Averages JSON. Error: ".$@);
		$log->error("Skipping Averages");
		refreshData(undef, $client, $refreshItem);
		return;
	}

    $averages{0}{'average_high_F'} = $perldata->{'temperatureAverageMax'}[0];
    $averages{0}{'record_high_F'} = $perldata->{'temperatureRecordMax'}[0];
    $averages{0}{'record_high_year'} = $perldata->{'almanacRecordYearMax'}[0];
    $averages{0}{'average_low_F'} = $perldata->{'temperatureAverageMin'}[0];
    $averages{0}{'record_low_F'} = $perldata->{'temperatureRecordMin'}[0];
    $averages{0}{'record_low_year'} = $perldata->{'almanacRecordYearMin'}[0];
	
	$log->debug('Average High: '.$averages{0}{'average_high_F'});
	$log->debug('Record High: '.$averages{0}{'record_high_F'});
	$log->debug('Record High Year: '.$averages{0}{'record_high_year'});
	$log->debug('Average Low: '.$averages{0}{'average_low_F'});
	$log->debug('Record Low: '.$averages{0}{'record_low_F'});
	$log->debug('Record Low Year: '.$averages{0}{'record_low_year'});

    # Set CURRENTLY as high values
    $wetData{-1}{'average_F'} = $averages{0}{'average_high_F'};
    $wetData{-1}{'average_C'} = FtoC($averages{0}{'average_high_F'});
    
    $wetData{-1}{'record_F'} = $averages{0}{'record_high_F'};
    $wetData{-1}{'record_C'} = FtoC($averages{0}{'record_high_F'});
    
    $wetData{-1}{'record_year'} = $averages{0}{'record_high_year'};

    $averages{'last'} = $wetData{0}{'forecastTOD'}; #update last average update indicator
    refreshData(undef, $client, $refreshItem);
}

sub drawEach {
    $log->debug("Start");
    my ($timerObj, $client, $period, $formatLoc) = @_;
        #^Should be undef
    
    my $destLoc = 0;
    
    if (defined $displayInfoBuild{$client}{'TOPdisplayItems1'}) {
        $destLoc = scalar @{$displayInfoBuild{$client}{'TOPdisplayItems1'}};
    }
    
    $log->debug("Drawing scrn $destLoc $client $period");
    
    my @show1icon  = @{ $prefs->client($client)->get('show1icon') || [] };
    my @show13line = @{ $prefs->client($client)->get('show13line') || [] };
    my @d3line1t   = @{ $prefs->client($client)->get('v3line1t') || [] };
    my @d3line1m   = @{ $prefs->client($client)->get('v3line1m') || [] };
    my @d3line1b   = @{ $prefs->client($client)->get('v3line1b') || [] };
    my @d1period   = @{ $prefs->client($client)->get('v1period') || [] };
    my @weatherformat1t = @{ $prefs->client($client)->get('weatherformat1t') || [] };
    my @weatherformat1b = @{ $prefs->client($client)->get('weatherformat1b') || [] };
    my @weatherformat2t = @{ $prefs->client($client)->get('weatherformat2t') || [] };
    my @weatherformat2b = @{ $prefs->client($client)->get('weatherformat2b') || [] };
    
    clearCanvas($client);
    
    #Draw icons
    if ($show1icon[$formatLoc] == 1) {
        drawIcon($client,0,$ymax{$client}-1, $Icons[$Iconmap{$wetData{$period}{'forecastIcon'}}]);      
        $displayInfoBuild{$client}{'hasIcon'}[$destLoc] = 1;
    }
    
    #Draw 3line stuff
    if ($show13line[$formatLoc] == 1) {
        my $line1 = uc(replaceMacrosPer($d3line1t[$formatLoc], $period, $client));
        my $line2 = uc(replaceMacrosPer($d3line1m[$formatLoc], $period, $client));
        my $line3 = uc(replaceMacrosPer($d3line1b[$formatLoc], $period, $client));      
    
        #Shorten HI/HIGH/LOW/Lo to gain screen real estate on Booms
        if($client->display->isa('Slim::Display::Boom')) {
            $line1 =~ s/^ LOW/LO/;
            $line1 =~ s/^HIGH/HI/;
            $line1 =~ s/^RAIN/RN/;
            $line1 =~ s/^PREC/PR/;
            $line2 =~ s/^ LOW/LO/;
            $line2 =~ s/^HIGH/HI/;
            $line2 =~ s/^RAIN/RN/;
            $line2 =~ s/^PREC/PR/;
            $line3 =~ s/^ LOW/LO/;
            $line3 =~ s/^RAIN/RN/;
            $line3 =~ s/^PREC/PR/;
            $line3 =~ s/^HIGH/HI/;
        }
    
        if ($show1icon[$formatLoc] == 1) {
            drawText($client,42,$ymax{$client}-25, $line3);
            drawText($client,42,$ymax{$client}-13, $line2);
            drawText($client,42,$ymax{$client}-1,  $line1);
        }
        else {
            drawText($client,0,$ymax{$client}-25, $line3);
            drawText($client,0,$ymax{$client}-13, $line2);
            drawText($client,0,$ymax{$client}-1,  $line1);
        }

        #Save the character lengths of each line
        $displayInfoBuild{$client}{'CharLen1'}[$destLoc] = length($line1);
        $displayInfoBuild{$client}{'CharLen2'}[$destLoc] = length($line2);
        $displayInfoBuild{$client}{'CharLen3'}[$destLoc] = length($line3);      
    }
    
    #If necessary can make the width calculation based on max length of 3line text
    $displayInfoBuild{$client}{'forecastG'}[$destLoc] = getFramebuf($client,$xmax{$client});
    
    push(@{$displayInfoBuild{$client}{'TOPdisplayItems1'}},  replaceMacrosPer($weatherformat1t[$formatLoc], $period, $client)); 
    push(@{$displayInfoBuild{$client}{'BOTdisplayItems1'}},  replaceMacrosPer($weatherformat1b[$formatLoc], $period, $client));
    push(@{$displayInfoBuild{$client}{'TOPdisplayItems2'}}, replaceMacrosPer($weatherformat2t[$formatLoc], $period, $client));  
    push(@{$displayInfoBuild{$client}{'BOTdisplayItems2'}}, replaceMacrosPer($weatherformat2b[$formatLoc], $period, $client));
    #$log->debug("Pending draw each timers: " . Slim::Utils::Timers::pendingTimers(undef, \&drawEach));
        
    $drawEachPending--;
    
    if ($drawEachPending == 0) {
        doneDrawing($client);
    }
    
    $log->debug("Finish");
}

sub replaceMacros {
    my $string = shift;
    my $client = shift;

    for ($string) {
        #Replace custom macros from other plugins. Do custom before default in case overriding
        for my $key ( keys %macroHash ) {
            $string =~ s/$key/$macroHash{$key}/;
            }       
        
        s/%!0/$wetData{'RefreshTime'}/;
		s/%!1/$status/;
        my $date = $client->longDateF();
        my $sdate = $client->shortDateF();
        s/%2/$date/;
        s/%!2/$sdate/;
        
        s/%t/$wetData{'temperatureF'}�/;
        s/%T/$wetData{'temperatureC'}�/;
        s/%!t/$wetData{'MaxTempF'}�/;
        s/%!T/$wetData{'MaxTempC'}�/;
        s/%h/$wetData{'humidity'}/;
        s/%p/$wetData{'pressureIN'}$wetData{'pressureT'}/;
        s/%P/$wetData{'pressureMB'}$wetData{'pressureT'}/;
        s/%d/$wetData{'dewpointF'}�/;
        s/%D/$wetData{'dewpointC'}�/;
        s/%f/$wetData{'feelslikeF'}�/;
        s/%F/$wetData{'feelslikeC'}�/;
        s/%w/$wetData{'windspeed_mh'}/;
        s/%W/$wetData{'windspeed_kh'}/;
        s/%q/$wetData{'windspeed_kth'}/;
        s/%Q/$wetData{'windspeed_ms'}/;     
        s/%-w/$wetData{'windspeed_mh-NC'}/;
        s/%-W/$wetData{'windspeed_kh-NC'}/;
        s/%-q/$wetData{'windspeed_kth-NC'}/;
        s/%-Q/$wetData{'windspeed_ms-NC'}/;     
        s/%_w/$wetData{'gust_mh'}/;
        s/%_W/$wetData{'gust_kh'}/;
        s/%_q/$wetData{'gust_kth'}/;
        s/%_Q/$wetData{'gust_ms'}/;     
        s/%u/$wetData{'UVindexNum'}/;
        s/%U/$wetData{'UVindexTxt'}/;
        s/%b/$wetData{'rain'}/;
        s/%B/$wetData{'snow'}/;

        #Wunderground
        s/%-0/$wetData{'wu_station'}/;
        s/%0/$wetData{'wu_obsTimeLocal'}/;
        s/%e/$wetData{'wu_temperatureF'}�/;
        s/%r/$wetData{'wu_temperatureFr'}�/;
        s/%i/$wetData{'wu_feelsLikeFr'}�/;
        s/%E/$wetData{'wu_temperatureC'}�/;
        s/%R/$wetData{'wu_temperatureCr'}�/;
        s/%I/$wetData{'wu_feelsLikeCr'}�/;
        s/%H/$wetData{'wu_humidity'}/;
        s/%l/$wetData{'wu_pressureIN'}/;
        s/%L/$wetData{'wu_pressureMB'}/;
        s/%m/$wetData{'wu_dewpointF'}�/;
        s/%M/$wetData{'wu_dewpointC'}�/;
        s/%j/$wetData{'wu_windspeed_mh'}/;
        s/%J/$wetData{'wu_windspeed_kh'}/;
        s/%k/$wetData{'wu_windspeed_kth'}/;
        s/%K/$wetData{'wu_windspeed_ms'}/;      
        s/%-j/$wetData{'wu_windspeed_mh-NC'}/;
        s/%-J/$wetData{'wu_windspeed_kh-NC'}/;
        s/%-k/$wetData{'wu_windspeed_kth-NC'}/;
        s/%-K/$wetData{'wu_windspeed_ms-NC'}/;      
        s/%_j/$wetData{'wu_windGust_mh'}/;
        s/%_J/$wetData{'wu_windGust_kh'}/;
        s/%_k/$wetData{'wu_windGust_kth'}/;
        s/%_K/$wetData{'wu_windGust_ms'}/;      
        s/%!b/$wetData{'wu_precipTotIN'}/;      
        s/%!B/$wetData{'wu_precipTotMM'}/;      
 
		# Air Quality
		s/%_aqI/$wetData{'gAQI'}/;
		s/%_aqC/$wetData{'gAQC'}/;
		s/%_aqCI/$wetData{'gAQCI'}/;
		s/%_aqP/$wetData{'gPP'}/;
		s/%_aqMg/$wetData{'gMG'}/;
		s/%_aqMs/$wetData{'gMS'}/;
		#Carbon Monoxide
		s/%_COn/$wetData{'aqCOn'}/;
		s/%_COp/$wetData{'aqCOp'}/;
		s/%_COm/$wetData{'aqCOm'}/;
		s/%_COc/$wetData{'aqCOc'}/;
		s/%_COi/$wetData{'aqCOci'}/;
		#Nitrogen Dioxide
		s/%_NOn/$wetData{'aqNO2n'}/;
		s/%_NOp/$wetData{'aqNO2p'}/;
		s/%_NOm/$wetData{'aqNO2m'}/;
		s/%_NOc/$wetData{'aqNO2c'}/;
		s/%_NOi/$wetData{'aqNO2ci'}/;
		#Ozone
		s/%_O3n/$wetData{'aqO3n'}/;
		s/%_O3p/$wetData{'aqO3p'}/;
		s/%_O3m/$wetData{'aqO3m'}/;
		s/%_O3c/$wetData{'aqO3c'}/;
		s/%_O3i/$wetData{'aqO3ci'}/;
		#Particulate matter <10µm
		s/%_P1n/$wetData{'aqPM10n'}/;
		s/%_P1p/$wetData{'aqPM10p'}/;
		s/%_P1m/$wetData{'aqPM10m'}/;
		s/%_P1c/$wetData{'aqPM10c'}/;
		s/%_P1i/$wetData{'aqPM10ci'}/; 
		#Particulate matter <2.5µm
		s/%_P2n/$wetData{'aqPM2.5n'}/; 
		s/%_P2p/$wetData{'aqPM2.5p'}/; 
		s/%_P2m/$wetData{'aqPM2.5m'}/; 
		s/%_P2c/$wetData{'aqPM2.5c'}/; 
		s/%_P2i/$wetData{'aqPM2.5ci'}/;
		#Sulfur Dioxide
		s/%_SOn/$wetData{'aqSO2n'}/;
		s/%_SOp/$wetData{'aqSO2p'}/;
		s/%_SOm/$wetData{'aqSO2m'}/;
		s/%_SOc/$wetData{'aqSO2c'}/;
		s/%_SOi/$wetData{'aqSO2ci'}/;
		}
	return $string;
}

sub replaceMacrosPer {
    my $string  = shift;
    my $location = shift;
    my $client = shift;

    $string = replaceMacros($string, $client);

    for ($string) {
        s/%a/$wetData{$location}{'average_F'}�/;
        s/%A/$wetData{$location}{'average_C'}�/;
        s/%c/$wetData{$location}{'record_F'}�/;
        s/%C/$wetData{$location}{'record_C'}�/;
        s/%g/$wetData{$location}{'record_year'}/;
        s/%s/$wetData{$location}{'sunrise'}/;
        s/%S/$wetData{$location}{'sunset'}/;
        s/%!s/$wetData{$location}{'sunrise12'}/;
        s/%!S/$wetData{$location}{'sunset12'}/;
        s/%G/$wetData{$location}{'moonPhrase'}/;
        s/%n/$wetData{$location}{'moonrise'}/;
        s/%N/$wetData{$location}{'moonset'}/;
        s/%!n/$wetData{$location}{'moonrise12'}/;
        s/%!N/$wetData{$location}{'moonset12'}/;
        s/%z/$wetData{$location}{'forecastType'} $wetData{$location}{'forecastTempF'}�/;
        s/%Z/$wetData{$location}{'forecastType'} $wetData{$location}{'forecastTempC'}�/;
        s/%!z/$wetData{$location}{'forecastTempF'}/;
        s/%!Z/$wetData{$location}{'forecastTempC'}/;
        s/Low/ Low/;

        s/%x/$wetData{$location}{'forecastPrecR'}/;
        s/%!x/$wetData{$location}{'forecastPrec'}/;
        s/%!h/$wetData{$location}{'forecastRH'}/;
        
        s/%y/$wetData{$location}{'forecastTOD'}/;
        s/%v/$wetData{$location}{'skyCondition'}/;
        
        s/%!w/$wetData{$location}{'forecastWindSpd_mh'}/;
        s/%!W/$wetData{$location}{'forecastWindSpd_kh'}/;
        s/%!q/$wetData{$location}{'forecastWindSpd_kth'}/;
        s/%!Q/$wetData{$location}{'forecastWindSpd_ms'}/;     
        s/%!-w/$wetData{$location}{'forecastWindSpd_mh-NC'}/;
        s/%!-W/$wetData{$location}{'forecastWindSpd_kh-NC'}/;
        s/%!-q/$wetData{$location}{'forecastWindSpd_kth-NC'}/;
        s/%!-Q/$wetData{$location}{'forecastWindSpd_ms-NC'}/;     

        s/%_3/$wetData{$location}{'day'}/;
        s/%!_3/$wetData{$location}{'shortday'}/;
        s/%_4/$wetData{$location}{'date'}/;
        s/%_5/$wetData{$location}{'highF'}�/;
        s/%_6/$wetData{$location}{'highC'}�/;
        s/%_7/$wetData{$location}{'lowF'}�/;
        s/%_8/$wetData{$location}{'lowC'}�/;
        s/%_9/$wetData{$location}{'precipR'}/;
        s/%!_9/$wetData{$location}{'precip'}/;
        s/%_0/$wetData{$location}{'condition'}/;
		
		s/%!Pg/$wetData{$location}{'grassIDX'}/;
		s/%_Pg/$wetData{$location}{'grassCat'}/;
		s/%!Pt/$wetData{$location}{'treeIDX'}/;
		s/%_Pt/$wetData{$location}{'treeCat'}/;
		s/%!Pr/$wetData{$location}{'ragweedIDX'}/;
		s/%_Pr/$wetData{$location}{'ragweedCat'}/;
		
    }       
    return $string;
}

sub getWeatherToday {  #Set up Async HTTP request for Weather
    my $timerObj = shift; #Should be undef
    my $client = shift;
    my $refreshItem = shift;

	my $url = 'https://api.weather.com/v3/wx/forecast/daily/15day?geocode='.$lat.','.$long.'&format=json&units='.$units.'&language='.$prefs->get('lang').'&apiKey='.$wcKey;
	my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotWeatherToday,
                              \&gotErrorViaHTTP,
                              {caller => 'getWeatherToday',
                               callerProc => \&getWeatherToday,
                               client => $client,
                               refreshItem => $refreshItem});
    $log->debug("async request: $url");
    
    $http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0',
    'Accept-Language' => 'en-us,en;q=0.5',
    'Accept' => 'text/plain',
    'Accept-Charset' => 'UTF-8');
}

sub gotWeatherToday {  #Weather data for near term and 15-day forecasts received
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
	$log->info("got " . $logURL);
	
	my $json = $http->content();

	my $perldata = eval{decode_json($json)}; 
	if ($@) {
		$log->error("Error detected in WeatherToday JSON. Error: ".$@);
		$log->error("Skipping WeatherToday");
		refreshData(undef, $client, $refreshItem);
		return;
	}

	#Store arrays
	my $dayNight = $perldata->{'daypart'}[0]->{'dayOrNight'};
	my $dayParts = $perldata->{'daypart'}[0]->{'daypartName'};
	my $Precip = $perldata->{'daypart'}[0]->{'precipChance'};
	my @PrecipR = (); # declare array for rounded chances for precipitation.  Values stored in while loops.
	my $highsLows = $perldata->{'daypart'}[0]->{'temperature'};
	my $rHumidity = $perldata->{'daypart'}[0]->{'relativeHumidity'};
	my $Icons = $perldata->{'daypart'}[0]->{'iconCode'};
	my $Cond = $perldata->{'daypart'}[0]->{'wxPhraseLong'};
	my $WindDir = $perldata->{'daypart'}[0]->{'windDirectionCardinal'};
	my $WindSpd = $perldata->{'daypart'}[0]->{'windSpeed'};
	my $Narrative = $perldata->{'daypart'}[0]->{'narrative'};
	
	my $loopcnt = 0;
	my $loopPointer = '';
	my $dayNightCurr = @$dayNight[0];
	my $dayPart = @$dayParts[0];
	my @mons=split(' ',$client->string('PLUGIN_SDT_MONTH'));
	my $dayval = "";
	my $dv = "";
	
	$log->debug('1st array entry for dayOrNight = '.$dayNightCurr);

############### Near Term Forecasts ####################
#			Period definitions
#			------------------
#	Period	Day					Night
#	------	---------------		------------------
#	-1		Current				Current
#	 0		Today				Tonight
#	 1		Tonight				Tomorrow
#	 2		Tomorrow			Tomorrow Night
#	 3		Tomorrow Night		Day after tomorrow

	while ($loopcnt < 5) {	# Store near term forecast data
		if ($dayNightCurr eq 'D') {
			$log->debug('Current Period = Day');
			$loopPointer = $loopcnt;
		}
		else {
			$log->debug('Current Period = Night');
			$loopPointer = $loopcnt+1
		}

		if (@$Precip[$loopPointer] ge 0){
			push(@PrecipR, nearest(5, @$Precip[$loopPointer]));
		}
		else {
			push(@PrecipR, '');
		}
		
		$log->debug('Loop #: ' . $loopcnt);
		$log->debug('Loop Count - Pointer: '.$loopcnt.' - '.$loopPointer);
		$log->debug('Day or Night: ' . @$dayNight[$loopPointer]);
		$log->debug('Day part: ' . @$dayParts[$loopPointer]);
		$log->debug('precip %: ' . @$Precip[$loopPointer]);
		$log->debug('Rounded precip %: ' . @PrecipR[$loopcnt]);
		$log->debug('High/Low: ' . @$highsLows[$loopPointer]);
		$log->debug('Relative Humidity: ' . @$rHumidity[$loopPointer]);
		$log->debug('Icon: ' . @$Icons[$loopPointer]);
		$log->debug('Condition: ' . @$Cond[$loopPointer]);
		$log->debug('Wind Direction: ' . @$WindDir[$loopPointer]);
		$log->debug('Wind Speed: ' . @$WindSpd[$loopPointer]);
		$log->debug('Narrative: ' . @$Narrative[$loopPointer]);
		
		if ($loopcnt == 0) { 
			if (@$dayNight[$loopPointer] eq 'D') { # Day
				$log->debug('dayPart: ' . $dayPart);
				$wetData{-1}{'forecastType'} = $client->string('PLUGIN_SCREENSAVER_SDT_HIGH'); #hi/low
				$wetData{0}{'forecastType'} = $client->string('PLUGIN_SCREENSAVER_SDT_HIGH');	
			}
			else { # Night
				$log->debug('dayPart: ' . $dayPart);
				$wetData{-1}{'forecastType'} = $client->string('PLUGIN_SCREENSAVER_SDT_LOW'); #hi/low
				$wetData{0}{'forecastType'} = $client->string('PLUGIN_SCREENSAVER_SDT_LOW');

			}
			$wetData{-1}{'forecastPrec'} = @$Precip[$loopPointer];
			$wetData{0}{'forecastPrec'} = @$Precip[$loopPointer];
			$wetData{-1}{'forecastPrecR'} = $PrecipR[$loopcnt];
			$wetData{0}{'forecastPrecR'} = $PrecipR[$loopcnt];
			if ($units eq 'e') {
				$wetData{-1}{'forecastTempF'} = @$highsLows[$loopPointer];
				$wetData{0}{'forecastTempF'} = @$highsLows[$loopPointer];
				$wetData{-1}{'forecastTempC'} = FtoC(@$highsLows[$loopPointer]);
				$wetData{0}{'forecastTempC'} = FtoC(@$highsLows[$loopPointer]);
				$wetData{0}{'forecastWindSpd_mh'} = @$WindSpd[$loopPointer];
				$wetData{0}{'forecastWindSpd_kh'} = nearest(1, (@$WindSpd[$loopPointer]*1.609344));
				$wetData{0}{'forecastWindSpd_kth'} = nearest(1, (@$WindSpd[$loopPointer]/1.1515));
				$wetData{0}{'forecastWindSpd_ms'} = nearest(1, (@$WindSpd[$loopPointer]*16.09344/36));
			}
			elsif ($units eq 'm') {
				$wetData{-1}{'forecastTempF'} = CtoF(@$highsLows[$loopPointer]);
				$wetData{0}{'forecastTempF'} = CtoF(@$highsLows[$loopPointer]);
				$wetData{-1}{'forecastTempC'} = @$highsLows[$loopPointer];
				$wetData{0}{'forecastTempC'} = @$highsLows[$loopPointer];
				$wetData{0}{'forecastWindSpd_kh'} = @$WindSpd[$loopPointer];
				$wetData{0}{'forecastWindSpd_mh'} = nearest(1, (@$WindSpd[$loopPointer]*0.6213711922));
				$wetData{0}{'forecastWindSpd_kth'} = nearest(1, (@$WindSpd[$loopPointer]*0.54));
				$wetData{0}{'forecastWindSpd_ms'} = nearest(1, (@$WindSpd[$loopPointer]/3.6));
			}
			else {
				$log->debug('$units undefined');
			}
			$wetData{0}{'forecastRH'} = @$rHumidity[$loopPointer];
			$wetData{0}{'forecastIcon'} = @$Icons[$loopPointer];
			$wetData{0}{'skyCondition'} = @$Cond[$loopPointer];
			$wetData{0}{'forecastIconURLSmall'} = '/plugins/SuperDateTime/html/images/' . @$Icons[$loopPointer] . '.png';
			$wetData{0}{'forecastTOD'} = @$dayParts[$loopPointer];
			my $WindDir = @$WindDir[$loopPointer];
			$wetData{0}{'forecastWindSpd_mh-NC'} = $wetData{0}{'forecastWindSpd_mh'};
			$wetData{0}{'forecastWindSpd_kh-NC'} = $wetData{0}{'forecastWindSpd_kh'};
			$wetData{0}{'forecastWindSpd_kth-NC'} = $wetData{0}{'forecastWindSpd_kth'};
			$wetData{0}{'forecastWindSpd_ms-NC'} = $wetData{0}{'forecastWindSpd_ms'};
			$wetData{-1}{'forecastWindSpd_mh-NC'} = $wetData{0}{'forecastWindSpd_mh-NC'};
			$wetData{-1}{'forecastWindSpd_kh-NC'} = $wetData{0}{'forecastWindSpd_kh-NC'};
			$wetData{-1}{'forecastWindSpd_kth-NC'} = $wetData{0}{'forecastWindSpd_kth-NC'};
			$wetData{-1}{'forecastWindSpd_ms-NC'} = $wetData{0}{'forecastWindSpd_ms-NC'};
			$wetData{0}{'forecastWindSpd_mh'} = $WindDir.' '.$wetData{0}{'forecastWindSpd_mh'};
			$wetData{0}{'forecastWindSpd_kh'} = $WindDir.' '.$wetData{0}{'forecastWindSpd_kh'};
			$wetData{0}{'forecastWindSpd_kth'} = $WindDir.' '.$wetData{0}{'forecastWindSpd_kth'};
			$wetData{0}{'forecastWindSpd_ms'} = $WindDir.' '.$wetData{0}{'forecastWindSpd_ms'};
			$wetData{-1}{'forecastWindSpd_mh'} = $wetData{0}{'forecastWindSpd_mh'};
			$wetData{-1}{'forecastWindSpd_kh'} = $wetData{0}{'forecastWindSpd_kh'};
			$wetData{-1}{'forecastWindSpd_kth'} = $wetData{0}{'forecastWindSpd_kth'};
			$wetData{-1}{'forecastWindSpd_ms'} = $wetData{0}{'forecastWindSpd_ms'};
			push(@WETdisplayItems1temp, $wetData{0}{'forecastTOD'});
			push(@WETdisplayItems2temp, @$Narrative[$loopPointer]);
			push(@WETdisplayItems3, $dv);
        }
        elsif ($loopcnt > 0) {
            if (@$dayNight[$loopPointer] eq 'D') { # Day
                $wetData{$loopcnt}{'forecastType'} = $client->string('PLUGIN_SCREENSAVER_SDT_HIGH');
			}
			else { # Night
                $wetData{$loopcnt}{'forecastType'} = $client->string('PLUGIN_SCREENSAVER_SDT_LOW');
			}

			$wetData{$loopcnt}{'forecastPrec'} = @$Precip[$loopPointer];
			$wetData{$loopcnt}{'forecastPrecR'} = $PrecipR[$loopcnt];
			if ($units eq 'e') {
				$wetData{$loopcnt}{'forecastTempF'} = @$highsLows[$loopPointer];
				$wetData{$loopcnt}{'forecastTempC'} = FtoC(@$highsLows[$loopPointer]);
				$wetData{$loopcnt}{'forecastWindSpd_mh'} = @$WindSpd[$loopPointer];
				$wetData{$loopcnt}{'forecastWindSpd_kh'} = nearest(1, (@$WindSpd[$loopPointer]*1.609344));
				$wetData{$loopcnt}{'forecastWindSpd_kth'} = nearest(1, (@$WindSpd[$loopPointer]/1.1515));
				$wetData{$loopcnt}{'forecastWindSpd_ms'} = nearest(1, (@$WindSpd[$loopPointer]*16.09344/36));
			}
			else {
				$wetData{$loopcnt}{'forecastTempF'} = CtoF(@$highsLows[$loopPointer]);
				$wetData{$loopcnt}{'forecastTempC'} = @$highsLows[$loopPointer];
				$wetData{$loopcnt}{'forecastWindSpd_kh'} = @$WindSpd[$loopPointer];
				$wetData{$loopcnt}{'forecastWindSpd_mh'} = nearest(1, (@$WindSpd[$loopPointer]*0.6213711922));
				$wetData{$loopcnt}{'forecastWindSpd_kth'} = nearest(1, (@$WindSpd[$loopPointer]*0.54));
				$wetData{$loopcnt}{'forecastWindSpd_ms'} = nearest(1, (@$WindSpd[$loopPointer]/3.6));
			}
			$wetData{$loopcnt}{'forecastRH'} = @$rHumidity[$loopPointer];
			$wetData{$loopcnt}{'forecastIcon'} = @$Icons[$loopPointer];
			$wetData{$loopcnt}{'skyCondition'} = @$Cond[$loopPointer];
			$wetData{$loopcnt}{'forecastIconURLSmall'} = '/plugins/SuperDateTime/html/images/' . @$Icons[$loopPointer] . '.png';
			$wetData{$loopcnt}{'forecastTOD'} = @$dayParts[$loopPointer]; 
			my $WindDir = @$WindDir[$loopPointer];
			$wetData{$loopcnt}{'forecastWindSpd_mh-NC'} = $wetData{$loopcnt}{'forecastWindSpd_mh'};
			$wetData{$loopcnt}{'forecastWindSpd_kh-NC'} = $wetData{$loopcnt}{'forecastWindSpd_kh'};
			$wetData{$loopcnt}{'forecastWindSpd_kth-NC'} = $wetData{$loopcnt}{'forecastWindSpd_kth'};
			$wetData{$loopcnt}{'forecastWindSpd_ms-NC'} = $wetData{$loopcnt}{'forecastWindSpd_ms'};
			$wetData{$loopcnt}{'forecastWindSpd_mh'} = $WindDir.' '.$wetData{$loopcnt}{'forecastWindSpd_mh'};
			$wetData{$loopcnt}{'forecastWindSpd_kh'} = $WindDir.' '.$wetData{$loopcnt}{'forecastWindSpd_kh'};
			$wetData{$loopcnt}{'forecastWindSpd_kth'} = $WindDir.' '.$wetData{$loopcnt}{'forecastWindSpd_kth'};
			$wetData{$loopcnt}{'forecastWindSpd_ms'} = $WindDir.' '.$wetData{$loopcnt}{'forecastWindSpd_ms'};
			push(@WETdisplayItems1temp, $wetData{$loopcnt}{'forecastTOD'});
			push(@WETdisplayItems2temp, @$Narrative[$loopPointer]);
			push(@WETdisplayItems3, $dv);

		}
		$log->debug("WindSpeedMH for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_mh'});
		$log->debug("WindSpeedKH for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_kh'});
		$log->debug("WindSpeedKT for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_kth'});
		$log->debug("WindSpeedMS for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_ms'});
		$log->debug("WindSpeedMH for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_mh-NC'});
		$log->debug("WindSpeedKH for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_kh-NC'});
		$log->debug("WindSpeedKT for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_kth-NC'});
		$log->debug("WindSpeedMS for loop " . $loopcnt . " = " . $wetData{$loopcnt}{'forecastWindSpd_ms-NC'});
		$log->debug(" ");
		$loopcnt++;
	}
	
############## Today and Tomorrow Sun and Moon Data ################
	my $sunrises = $perldata->{'sunriseTimeLocal'};
	my $sunsets = $perldata->{'sunsetTimeLocal'};
	my $moonIcons = $perldata->{'moonPhaseDay'};
	my $moonPhrases = $perldata->{'moonPhase'};
	my $moonrises = $perldata->{'moonriseTimeLocal'};
	my $moonsets = $perldata->{'moonsetTimeLocal'};

	# Sunrise, Sunset, Moonrise, Moonset, Moon phrase, Moon ICON for Today.  
	# Store in current[-1] and today/tonight[0] periods. 
	my $sunrise = @$sunrises[0];
	my $timepos = index($sunrise, ":");
	$timepos = $timepos-2;
	my $sr = substr($sunrise, $timepos, 5);
	$wetData{-1}{'sunrise'} = $sr;
	$wetData{0}{'sunrise'} = $sr;
	$wetData{-1}{'sunrise12'} = C24to12($sr);
	$wetData{0}{'sunrise12'} = C24to12($sr);

	my $sunset = @$sunsets[0];
	my $ss = substr($sunset, $timepos, 5);
	$wetData{-1}{'sunset'} = $ss;
	$wetData{0}{'sunset'} = $ss;
	$wetData{-1}{'sunset12'} = C24to12($ss);
	$wetData{0}{'sunset12'} = C24to12($ss);

	my $moonrise = @$moonrises[0];
	my $mr = substr($moonrise, $timepos, 5);
	$wetData{-1}{'moonrise'} = $mr;
	$wetData{0}{'moonrise'} = $mr;
	$wetData{-1}{'moonrise12'} = C24to12($mr);
	$wetData{0}{'moonrise12'} = C24to12($mr);

	my $moonset = @$moonsets[0];
	my $ms = substr($moonset, $timepos, 5);
	$wetData{-1}{'moonset'} = $ms;
	$wetData{0}{'moonset'} = $ms;
	$wetData{-1}{'moonset12'} = C24to12($ms);
	$wetData{0}{'moonset12'} = C24to12($ms);

	my $moonphrase = @$moonPhrases[0];
	$wetData{-1}{'moonPhrase'} = $moonphrase;
	$wetData{0}{'moonPhrase'} = $moonphrase;
	
	my $moonIcon = @$moonIcons[0];
	$wetData{-1}{'moonIcon'} = $moonIcon;
	$wetData{0}{'moonIcon'} = $moonIcon;
	$wetData{-1}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
	$wetData{0}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
	$wetData{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';

	# Sunrise, Sunset, Moonrise, Moonset, Moon phrase for Tomorrow.  
	# Store in tomorrow and tomorrow night periods. 
	$sunrise = @$sunrises[1];
	$sr = substr($sunrise, $timepos, 5);
	$sunset = @$sunsets[1];
	$ss = substr($sunset, $timepos, 5);
	$moonrise = @$moonrises[1];
	$mr = substr($moonrise, $timepos, 5);
	$moonset = @$moonsets[1];
	$ms = substr($moonset, $timepos, 5);
	$moonphrase = @$moonPhrases[1];
	$moonIcon = @$moonIcons[1];

	if ($dayNightCurr eq 'D') { # Day
		$wetData{2}{'sunrise'} = $sr;
		$wetData{3}{'sunrise'} = $sr;
		$wetData{2}{'sunrise12'} = C24to12($sr);
		$wetData{3}{'sunrise12'} = C24to12($sr);
		$wetData{2}{'sunset'} = $ss;
		$wetData{3}{'sunset'} = $ss;
		$wetData{2}{'sunset12'} = C24to12($ss);
		$wetData{3}{'sunset12'} = C24to12($ss);
		$wetData{2}{'moonrise'} = $mr;
		$wetData{3}{'moonrise'} = $mr;
		$wetData{2}{'moonrise12'} = C24to12($mr);
		$wetData{3}{'moonrise12'} = C24to12($mr);
		$wetData{2}{'moonset'} = $ms;
		$wetData{3}{'moonset'} = $ms;
		$wetData{2}{'moonset12'} = C24to12($ms);
		$wetData{3}{'moonset12'} = C24to12($ms);
		$wetData{2}{'moonPhrase'} = $moonphrase;
		$wetData{3}{'moonPhrase'} = $moonphrase;
		$wetData{2}{'moonIcon'} = $moonIcon;
		$wetData{3}{'moonIcon'} = $moonIcon;
		$wetData{2}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
		$wetData{3}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
	}
	else { # Night
		$wetData{1}{'sunrise'} = $sr;
		$wetData{2}{'sunrise'} = $sr;
		$wetData{1}{'sunrise12'} = C24to12($sr);
		$wetData{2}{'sunrise12'} = C24to12($sr);
		$wetData{1}{'sunset'} = $ss;
		$wetData{2}{'sunset'} = $ss;
		$wetData{1}{'sunset12'} = C24to12($ss);
		$wetData{2}{'sunset12'} = C24to12($ss);
		$wetData{1}{'moonrise'} = $mr;
		$wetData{2}{'moonrise'} = $mr;
		$wetData{1}{'moonrise12'} = C24to12($mr);
		$wetData{2}{'moonrise12'} = C24to12($mr);
		$wetData{1}{'moonset'} = $ms;
		$wetData{2}{'moonset'} = $ms;
		$wetData{1}{'moonset12'} = C24to12($ms);
		$wetData{2}{'moonset12'} = C24to12($ms);
		$wetData{1}{'moonPhrase'} = $moonphrase;
		$wetData{2}{'moonPhrase'} = $moonphrase;
		$wetData{1}{'moonIcon'} = $moonIcon;
		$wetData{2}{'moonIcon'} = $moonIcon;
		$wetData{1}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
		$wetData{2}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
	}

	$log->debug("Sunrise for Today = " . $wetData{0}{'sunrise'}.'  '.$wetData{-1}{'sunrise12'});
	$log->debug("Sunset for Today = " . $wetData{-1}{'sunset'}.'  '.$wetData{0}{'sunset12'});
	$log->debug("Moonrise for Today = " . $wetData{0}{'moonrise'}.'  '.$wetData{-1}{'moonrise12'});
	$log->debug("Moonset for Today = " . $wetData{-1}{'moonset'}.'  '.$wetData{0}{'moonset12'});
	$log->debug("Moon Phase for Today = " . $wetData{-1}{'moonPhrase'});
	$log->debug("Moon Age Today = " . $wetData{0}{'moonIcon'});
	$log->debug(" ");
	$log->debug("Sunrise for Tomorrow = " . $wetData{2}{'sunrise'}.'  '.$wetData{2}{'sunrise12'});
	$log->debug("Sunset for Tomorrow = " . $wetData{2}{'sunset'}.'  '.$wetData{2}{'sunset12'});
	$log->debug("Moonrise for Tomorrow = " . $wetData{2}{'moonrise'}.'  '.$wetData{2}{'moonrise12'});
	$log->debug("Moonset for Tomorrow = " . $wetData{2}{'moonset'}.'  '.$wetData{2}{'moonset12'});
	$log->debug("Moon Phase for Tomorrow = " . $wetData{2}{'moonPhrase'});
	$log->debug("Moon Age Tomorrow = " . $wetData{2}{'moonIcon'});
	$log->debug(" ");

############ 15-day forecasts. ###############
	my $dates = $perldata->{'validTimeLocal'};
	my $days = $perldata->{'dayOfWeek'};
	my $dayval = '';
	my $highs = $perldata->{'temperatureMax'};
	my $lows = $perldata->{'temperatureMin'};
	my $dayNarratives = $perldata->{'narrative'};

	my $dayNum = 0;
	my $dayPointer = '';
	my @DayPrecipR = ();
	$dayCount = scalar(@$dates); 
	$log->debug('# of Dates: ' . scalar(@$dates));

	while ($dayNum < $dayCount) { 
		if ($dayNum eq 0) {
			$dayPointer = 0
		}
		else {
			$dayPointer = $dayNum*2;
		}
		$dayval = @$dates[$dayNum];
		if ($dayval=~/([0-9]{4})\-([0-9]{2})\-([0-9]{2}).*/) {
			my $mon_pntr = $2 - 1;
			my $day = $3;
			$day =~ s/^0//; # Remove leading zero
			if ($units eq 'e') {
				$dv = "$mons[$mon_pntr] $day\n";
			}
			elsif ($units eq 'm') {
				$dv = "$day. $mons[$mon_pntr]\n";
			}
			else {
				$log->debug('$units undefined');
			}
		}
		$wetData{'d'.$dayNum}{'day'} = @$days[$dayNum];
		$wetData{'d'.$dayNum}{'shortday'} = substr @$days[$dayNum], 0, 3;
		$wetData{'d'.$dayNum}{'date'} = $dv;        

		if (@$Precip[$dayPointer] ge 0){
			push(@DayPrecipR, nearest(5, @$Precip[$dayPointer]));
		}
		else {
			push(@DayPrecipR, '');
		}
		$wetData{'d'.$dayNum}{'forecastIcon'} = @$Icons[$dayPointer];
		$wetData{'d'.$dayNum}{'forecastIconURLSmall'} = '/plugins/SuperDateTime/html/images/' . @$Icons[$dayPointer] . '.png';
		$wetData{'d'.$dayNum}{'condition'} = @$Cond[$dayPointer];

		if (($dayNightCurr eq 'D') and ($dayNum > 1)) {
			push(@WETdisplayItems1temp, (@$dayParts[$dayPointer].' '.$dv));
			push(@WETdisplayItems2temp, @$dayNarratives[$dayNum]);
			push(@WETdisplayItems3, $dv);
		}
		elsif (($dayNightCurr ne 'D') and ($dayNum > 2)) {
			push(@WETdisplayItems1temp, (@$dayParts[$dayPointer].' '.$dv));
			push(@WETdisplayItems2temp, @$Narrative[$dayPointer]);
			push(@WETdisplayItems3, $dv);
		}
		else {
			$log->debug("No need to store redundant Long Forecasts for day ".$dayNum." during ".@$dayParts[$dayPointer]);
		}

		if ($units eq 'e') {
			$wetData{'d'.$dayNum}{'highF'} = @$highs[$dayNum];
			$wetData{'d'.$dayNum}{'highC'} = FtoC(@$highs[$dayNum]);
			$wetData{'d'.$dayNum}{'lowF'} = @$lows[$dayNum];
			$wetData{'d'.$dayNum}{'lowC'} = FtoC(@$lows[$dayNum]);
			$wetData{'d'.$dayNum}{'forecastWindSpd_mh'} = @$WindSpd[$dayPointer];
			$wetData{'d'.$dayNum}{'forecastWindSpd_kh'} = nearest(1, (@$WindSpd[$dayPointer]*1.609344));
			$wetData{'d'.$dayNum}{'forecastWindSpd_kth'} = nearest(1, (@$WindSpd[$dayPointer]/1.1515));
			$wetData{'d'.$dayNum}{'forecastWindSpd_ms'} = nearest(1, (@$WindSpd[$dayPointer]*16.09344/36));
		}
		else {
			$wetData{'d'.$dayNum}{'highF'} = CtoF(@$highs[$dayNum]);
			$wetData{'d'.$dayNum}{'highC'} = @$highs[$dayNum];
			$wetData{'d'.$dayNum}{'lowF'} = CtoF(@$lows[$dayNum]);
			$wetData{'d'.$dayNum}{'lowC'} = @$lows[$dayNum];
			$wetData{'d'.$dayNum}{'forecastWindSpd_kh'} = @$WindSpd[$dayPointer];
			$wetData{'d'.$dayNum}{'forecastWindSpd_mh'} = nearest(1, (@$WindSpd[$dayPointer]*0.6213711922));
			$wetData{'d'.$dayNum}{'forecastWindSpd_kth'} = nearest(1, (@$WindSpd[$dayPointer]*0.54));
			$wetData{'d'.$dayNum}{'forecastWindSpd_ms'} = nearest(1, (@$WindSpd[$dayPointer]/3.6));
		}

		$wetData{'d'.$dayNum}{'forecastRH'} = @$rHumidity[$dayPointer];
		$wetData{'d'.$dayNum}{'precip'} = @$Precip[$dayPointer];
		$wetData{'d'.$dayNum}{'precipR'} = @DayPrecipR[$dayNum];
		my $WindDir = @$WindDir[$dayPointer];
		$wetData{'d'.$dayNum}{'forecastWindSpd_mh-NC'} = $wetData{'d'.$dayNum}{'forecastWindSpd_mh'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_kh-NC'} = $wetData{'d'.$dayNum}{'forecastWindSpd_kh'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_kth-NC'} = $wetData{'d'.$dayNum}{'forecastWindSpd_kth'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_ms-NC'} = $wetData{'d'.$dayNum}{'forecastWindSpd_ms'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_mh'} = $WindDir.' '.$wetData{'d'.$dayNum}{'forecastWindSpd_mh'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_kh'} = $WindDir.' '.$wetData{'d'.$dayNum}{'forecastWindSpd_kh'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_kth'} = $WindDir.' '.$wetData{'d'.$dayNum}{'forecastWindSpd_kth'};
		$wetData{'d'.$dayNum}{'forecastWindSpd_ms'} = $WindDir.' '.$wetData{'d'.$dayNum}{'forecastWindSpd_ms'};

		$sunrise = @$sunrises[$dayNum];
		$sr = substr($sunrise, $timepos, 5);
		$wetData{'d'.$dayNum}{'sunrise'} = $sr;
		$wetData{'d'.$dayNum}{'sunrise12'} = C24to12($sr);

		$sunset = @$sunsets[$dayNum];
		$ss = substr($sunset, $timepos, 5);
		$wetData{'d'.$dayNum}{'sunset'} = $ss;
		$wetData{'d'.$dayNum}{'sunset12'} = C24to12($ss);
		
		$moonrise = @$moonrises[$dayNum];
		$mr = substr($moonrise, $timepos, 5);
		$wetData{'d'.$dayNum}{'moonrise'} = $mr;
		$wetData{'d'.$dayNum}{'moonrise12'} = C24to12($mr);

		$moonset = @$moonsets[$dayNum];
		$ms = substr($moonset, $timepos, 5);
		$wetData{'d'.$dayNum}{'moonset'} = $ms;
		$wetData{'d'.$dayNum}{'moonset12'} = C24to12($ms);

		$moonphrase = @$moonPhrases[$dayNum];
		$wetData{'d'.$dayNum}{'moonPhrase'} = $moonphrase;
		
		$moonIcon = @$moonIcons[$dayNum];
		$wetData{'d'.$dayNum}{'moonphaseURL'} ='/plugins/SuperDateTime/html/images/moon_'. $moonIcon . '.png';
	  
		$log->debug('Date: ' . @$dates[$dayNum]);
		$log->debug("Day/Period for day " . $dayNum . " = " . @$dayParts[$dayPointer]);
		$log->debug('Day: ' . @$days[$dayNum]);
		$log->debug("Date Val for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'date'});
		$log->debug("Icon # for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastIcon'});
		$log->debug("Condition for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'condition'});
		$log->debug("Long weather for day " . $dayNum . " = " . @$Narrative[$dayPointer]);
		$log->debug("High for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'highF'});
		$log->debug("Humidity for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastRH'});
		$log->debug("Prec Chance for day " . $dayNum . " = " . @$Precip[$dayPointer]);
		$log->debug("Rounded Prec Chance for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'precipR'});
		$log->debug("Low for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'lowF'});
		$log->debug("WindSpeedMH for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_mh'});
		$log->debug("WindSpeedKH for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_kh'});
		$log->debug("WindSpeedKT for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_kth'});
		$log->debug("WindSpeedMS for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_ms'});
		$log->debug("WindSpeedMH for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_mh-NC'});
		$log->debug("WindSpeedKH for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_kh-NC'});
		$log->debug("WindSpeedKT for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_kth-NC'});
		$log->debug("WindSpeedMS for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'forecastWindSpd_ms-NC'});
		$log->debug("Sunrise for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'sunrise'}.'  '.$wetData{'d'.$dayNum}{'sunrise12'});
		$log->debug("Sunset for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'sunset'}.'  '.$wetData{'d'.$dayNum}{'sunset12'});
		$log->debug("Moonrise for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'moonrise'}.'  '.$wetData{'d'.$dayNum}{'moonrise12'});
		$log->debug("Moonset for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'moonset'}.'  '.$wetData{'d'.$dayNum}{'moonset12'});
		$log->debug("Moon Phase for day " . $dayNum . " = " . $wetData{'d'.$dayNum}{'moonPhrase'});
		$log->debug("Moon age for day: " . $dayNum . " = " . $moonIcon);
		$log->debug("Moon iconURL for day: " . $dayNum . " = " . $wetData{'d'.$dayNum}{'moonphaseURL'});
		$log->debug(" ");
		$dayNum++;
	}
	$log->debug("Forecast High: ".$wetData{'d0'}{'highF'}." Max Observed: ".$wetData{'MaxTempF'});
	if ($wetData{'d0'}{'highF'} eq ''){
		$wetData{'d0'}{'highF'} = $wetData{'MaxTempF'};
		$wetData{'d0'}{'highC'} = $wetData{'MaxTempC'};
	}
	refreshData(undef, $client, $refreshItem);
}

sub getPollen {  #Set up Async HTTP request for Pollen forecast
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;

	my $url = 'https://api.weather.com/v2/indices/pollen/daypart/15day?geocode='.$lat.','.$long.'&language='.$prefs->get('lang').'&format=json&apiKey='.$wcKey;
	my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotPollen,
							  \&gotErrorViaHTTP,
							  {caller => 'getPollen',
							   callerProc => \&getPollen,
							   client => $client,
							   refreshItem => $refreshItem});
	$log->debug("async request: $url");
	
	$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0',
	'Accept-Language' => 'en-us,en;q=0.5',
	'Accept' => 'application/json',
	'Accept-Charset' => 'UTF-8');
}

sub gotPollen {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
	$log->info("got " . $logURL);
	
	my $json = $http->content();

	my $perldata = eval{decode_json($json)}; 
	if ($@) {
		$log->error("Error detected in WeatherToday JSON. Error: ".$@);
		$log->error("Skipping WeatherToday");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	#Store arrays
	my $dayNight = $perldata->{'pollenForecast12hour'}->{'dayInd'};
	my $dayParts = $perldata->{'pollenForecast12hour'}->{'daypartName'};
	my $grassIDX = $perldata->{'pollenForecast12hour'}->{'grassPollenIndex'};
	my $grassCat = $perldata->{'pollenForecast12hour'}->{'grassPollenCategory'};
	my $treeIDX = $perldata->{'pollenForecast12hour'}->{'treePollenIndex'};
	my $treeCat = $perldata->{'pollenForecast12hour'}->{'treePollenCategory'};
	my $ragweedIDX = $perldata->{'pollenForecast12hour'}->{'ragweedPollenIndex'};
	my $ragweedCat = $perldata->{'pollenForecast12hour'}->{'ragweedPollenCategory'};
	
	my $loopcnt = 0;
	my $loopPointer = '';
	my $dayNightCurr = @$dayNight[0];
	my $dayPart = @$dayParts[0];
	
	$log->debug('1st array entry for dayOrNight = '.$dayNightCurr);

############### Near Term Forecasts ####################
#   		Period definitions
#			------------------
#   Period  Day                 Night
#   ------  ---------------		------------------
#   -1      Current             Current
#    0      Today               Tonight
#    1      Tonight             Tomorrow
#    2      Tomorrow            Tomorrow Night
#    3      Tomorrow Night      Day after tomorrow

	while ($loopcnt < 5) { 	# Store near term forecast data
		if ($dayNightCurr eq 'D') {
			$log->debug('Current Period = Day');
			$loopPointer = $loopcnt;
		}
		else {
			$log->debug('Current Period = Night');
			$loopPointer = $loopcnt+1
		}

		$log->debug('Loop #: ' . $loopcnt);
		$log->debug('Loop Count - Pointer: '.$loopcnt.' - '.$loopPointer);
		$log->debug('Day or Night: ' . @$dayNight[$loopcnt]);
		$log->debug('Day part: ' . @$dayParts[$loopcnt]);
		$log->debug('Grass Index: ' . @$grassIDX[$loopcnt]);
		$log->debug('Grass Category: ' . @$grassCat[$loopcnt]);
		$log->debug('Tree Index: ' . @$treeIDX[$loopcnt]);
		$log->debug('Tree Category: ' . @$treeCat[$loopcnt]);
		$log->debug('Ragweed Index: ' . @$ragweedIDX[$loopcnt]);
		$log->debug('Ragweed Category: ' . @$ragweedCat[$loopcnt]);
		
		if ($loopcnt == 0) { 
			$wetData{-1}{'grassIDX'} 	= @$grassIDX[$loopcnt];
			$wetData{0} {'grassIDX'} 	= @$grassIDX[$loopcnt];
			$wetData{-1}{'grassCat'} 	= @$grassCat[$loopcnt];
			$wetData{0} {'grassCat'} 	= @$grassCat[$loopcnt];
			$wetData{-1}{'grassICON'} 	= '/plugins/SuperDateTime/html/images/Pol'. @$grassIDX[$loopcnt] .'.png';
			$wetData{0} {'grassICON'} 	= '/plugins/SuperDateTime/html/images/Pol'. @$grassIDX[$loopcnt] .'.png';
			$wetData{-1}{'treeIDX'} 	= @$treeIDX[$loopcnt];
			$wetData{0} {'treeIDX'} 	= @$treeIDX[$loopcnt];
			$wetData{-1}{'treeCat'} 	= @$treeCat[$loopcnt];
			$wetData{0} {'treeCat'} 	= @$treeCat[$loopcnt];
			$wetData{-1}{'treeICON'} 	= '/plugins/SuperDateTime/html/images/Pol'. @$treeIDX[$loopcnt] .'.png';
			$wetData{0} {'treeICON'} 	= '/plugins/SuperDateTime/html/images/Pol'. @$treeIDX[$loopcnt] .'.png';
			$wetData{-1}{'ragweedIDX'} 	= @$ragweedIDX[$loopcnt];
			$wetData{0} {'ragweedIDX'} 	= @$ragweedIDX[$loopcnt];
			$wetData{-1}{'ragweedCat'} 	= @$ragweedCat[$loopcnt];
			$wetData{0} {'ragweedCat'} 	= @$ragweedCat[$loopcnt];
			$wetData{-1}{'ragweedICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$ragweedIDX[$loopcnt] .'.png';
			$wetData{0} {'ragweedICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$ragweedIDX[$loopcnt] .'.png';
		}
		elsif ($loopcnt > 0) {
			$wetData{$loopcnt}{'grassIDX'} = @$grassIDX[$loopcnt];
			$wetData{$loopcnt}{'grassCat'} = @$grassCat[$loopcnt];
			$wetData{$loopcnt}{'grassICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$grassIDX[$loopcnt] .'.png';
			$wetData{$loopcnt}{'treeIDX'} = @$treeIDX[$loopcnt];
			$wetData{$loopcnt}{'treeCat'} = @$treeCat[$loopcnt];
			$wetData{$loopcnt}{'treeICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$treeIDX[$loopcnt] .'.png';
			$wetData{$loopcnt}{'ragweedIDX'} = @$ragweedIDX[$loopcnt];
			$wetData{$loopcnt}{'ragweedCat'} = @$ragweedCat[$loopcnt];
			$wetData{$loopcnt}{'ragweedICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$ragweedIDX[$loopcnt] .'.png';
		}
		$log->debug('Day or Night: ' . @$dayNight[$loopcnt]);
		$log->debug('Day part: ' . @$dayParts[$loopcnt]);
		$log->debug("Grass Index & Cat = " . $wetData{$loopcnt}{'grassIDX'}.'  '.$wetData{$loopcnt}{'grassCat'});
		$log->debug("Grass ICON url = " . $wetData{$loopcnt}{'grassICON'});
		$log->debug("Tree Index & Cat = " . $wetData{$loopcnt}{'treeIDX'}.'  '.$wetData{$loopcnt}{'treeCat'});
		$log->debug("Tree ICON url = " . $wetData{$loopcnt}{'treeICON'});
		$log->debug("Ragweed Index & Cat = " . $wetData{$loopcnt}{'ragweedIDX'}.'  '.$wetData{$loopcnt}{'ragweedCat'});
		$log->debug("Ragweed ICON url = " . $wetData{$loopcnt}{'ragweedICON'});
		$log->debug(" ");
		$loopcnt++;
	}
	
########### 15-day loop ###########
	my $dayNum = 0;
	my $dayPointer = '';
	$log->debug('Day Count= '.$dayCount.' '.$dayNightCurr);
	if ($dayNightCurr eq 'N') {
		$dayCount--;
	}
	$log->debug('Day Count= '.$dayCount);

	while ($dayNum < $dayCount) {
		if ($dayNum eq 0){
			if ($dayNightCurr eq 'D') { 
				$dayPointer = 0;
			}
			else {
				$dayPointer = 1;
			}
		}
		else {
			if ($dayNightCurr eq 'D') { 
				$dayPointer = $dayNum*2;
			}
			else {
				$dayPointer = ($dayNum*2)+1;
			}
		}

		$wetData{'d'.$dayNum}{'grassIDX'} = @$grassIDX[$dayPointer];
		$wetData{'d'.$dayNum}{'grassCat'} = @$grassCat[$dayPointer];
		$wetData{'d'.$dayNum}{'grassICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$grassIDX[$dayPointer] .'.png';
		$wetData{'d'.$dayNum}{'treeIDX'} = @$treeIDX[$dayPointer];
		$wetData{'d'.$dayNum}{'treeCat'} = @$treeCat[$dayPointer];
		$wetData{'d'.$dayNum}{'treeICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$treeIDX[$dayPointer] .'.png';
		$wetData{'d'.$dayNum}{'ragweedIDX'} = @$ragweedIDX[$dayPointer];
		$wetData{'d'.$dayNum}{'ragweedCat'} = @$ragweedCat[$dayPointer];
		$wetData{'d'.$dayNum}{'ragweedICON'} = '/plugins/SuperDateTime/html/images/Pol'. @$ragweedIDX[$dayPointer] .'.png';

		$log->debug('Day #: '.$dayNum.' # of days= '.$dayCount);
		$log->debug('Day or Night: '.@$dayNight[$dayPointer]);
		$log->debug('Day part: '.	@$dayParts[$dayPointer]);
		$log->debug('Grass IDX: '.	$wetData{'d'.$dayNum}{'grassIDX'});
		$log->debug('Grass Cat: '.	$wetData{'d'.$dayNum}{'grassCat'});
		$log->debug('Grass ICON url: '.	$wetData{'d'.$dayNum}{'grassICON'});
		$log->debug('tree IDX: '.	$wetData{'d'.$dayNum}{'treeIDX'});
		$log->debug('tree Cat: '.	$wetData{'d'.$dayNum}{'treeCat'});
		$log->debug('tree ICON url: '.	$wetData{'d'.$dayNum}{'treeICON'});
		$log->debug('ragweed IDX: '.	$wetData{'d'.$dayNum}{'ragweedIDX'});
		$log->debug('ragweed Cat: '.	$wetData{'d'.$dayNum}{'ragweedCat'});
		$log->debug('ragweed ICON url: '.	$wetData{'d'.$dayNum}{'ragweedICON'});
		$log->debug(" ");
		$dayNum++;
	}
	refreshData(undef, $client, $refreshItem);
}

sub getAirQuality {  #Set up Async HTTP request for Air Quality data
    my $timerObj = shift; #Should be undef
    my $client = shift;
    my $refreshItem = shift;
	
	my $aqScale = '';
	if ($countryCode eq 'CN') { # China
		$aqScale = 'HJ6332012';
	}
	elsif ($countryCode eq 'FR') { # France
		$aqScale = 'ATMO';
	}
	elsif ($countryCode eq 'DE') { # Germany
		$aqScale = 'UBA';
	}
	elsif ($countryCode eq 'IN') { # India
		$aqScale = 'NAQI';
	}
	elsif ($countryCode eq 'MX') { # Mexico
		$aqScale = 'IMECA';
	}
	elsif ($countryCode eq 'ES') { # Spain
		$aqScale = 'CAQI';
	}
	elsif ($countryCode eq 'GB') { # Great Britain/United Kingdom
		$aqScale = 'DAQI';
	}
	else { # All other countries
		$aqScale = 'EPA';
	}
	$log->debug('Country = '.$country.' ('.$countryCode.') / Air Quality Scale= '.$aqScale);
	
	my $url = 'https://api.weather.com/v3/wx/globalAirQuality?geocode='.$lat.','.$long.'&language='.$prefs->get('lang').'&scale='.$aqScale.'&format=json&apiKey='.$wcKey;
	my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotAirQuality,
                              \&gotErrorViaHTTP,
                              {caller => 'getAirQuality',
                               callerProc => \&getAirQuality,
                               client => $client,
                               refreshItem => $refreshItem});
    $log->debug("async request: $url");
    $http->get($url);
}

sub gotAirQuality {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
	$log->info("got " . $logURL);
	
		my $json = $http->content();

	my $perldata = eval{decode_json($json)}; 
	if ($@) {
		$log->error("Error detected in AirQuality JSON. Error: ".$@);
		$log->error("Skipping AirQuality");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	#Store data
	#Overall Air Quality Data & Messages
	$wetData{'gAQI'} = $perldata->{'globalairquality'}->{'airQualityIndex'};
	$wetData{'gAQC'} = $perldata->{'globalairquality'}->{'airQualityCategory'};
	$wetData{'gAQCI'} = $perldata->{'globalairquality'}->{'airQualityCategoryIndex'};
	$wetData{'gAQicon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'gAQCI'} .'.png';
	$wetData{'gPP'} = $perldata->{'globalairquality'}->{'primaryPollutant'};
	$wetData{'gMG'} = $perldata->{'globalairquality'}->{'messages'}->{'General'}->{'text'};
	$wetData{'gMS'} = $perldata->{'globalairquality'}->{'messages'}->{'Sensitive Group'}->{'text'};
	#Carbon Monoxide
	$wetData{'aqCOn'} = $perldata->{'globalairquality'}->{'pollutants'}->{'CO'}->{'name'};
	$wetData{'aqCOp'} = $perldata->{'globalairquality'}->{'pollutants'}->{'CO'}->{'phrase'};
	$wetData{'aqCOm'} = $perldata->{'globalairquality'}->{'pollutants'}->{'CO'}->{'amount'}." ".$perldata->{'globalairquality'}->{'pollutants'}->{'CO'}->{'unit'};
	$wetData{'aqCOc'} = $perldata->{'globalairquality'}->{'pollutants'}->{'CO'}->{'category'};
	$wetData{'aqCOci'} = $perldata->{'globalairquality'}->{'pollutants'}->{'CO'}->{'categoryIndex'};
	$wetData{'aqCOicon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'aqCOci'} .'.png';
	#Nitrogen Dioxide
	$wetData{'aqNO2n'} = $perldata->{'globalairquality'}->{'pollutants'}->{'NO2'}->{'name'};
	$wetData{'aqNO2p'} = $perldata->{'globalairquality'}->{'pollutants'}->{'NO2'}->{'phrase'};
	$wetData{'aqNO2m'} = $perldata->{'globalairquality'}->{'pollutants'}->{'NO2'}->{'amount'}." ".$perldata->{'globalairquality'}->{'pollutants'}->{'NO2'}->{'unit'};
	$wetData{'aqNO2c'} = $perldata->{'globalairquality'}->{'pollutants'}->{'NO2'}->{'category'};
	$wetData{'aqNO2ci'} = $perldata->{'globalairquality'}->{'pollutants'}->{'NO2'}->{'categoryIndex'};
	$wetData{'aqNO2icon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'aqNO2ci'} .'.png';
	#Ozone
	$wetData{'aqO3n'} = $perldata->{'globalairquality'}->{'pollutants'}->{'O3'}->{'name'};
	$wetData{'aqO3p'} = $perldata->{'globalairquality'}->{'pollutants'}->{'O3'}->{'phrase'};
	$wetData{'aqO3m'} = $perldata->{'globalairquality'}->{'pollutants'}->{'O3'}->{'amount'}." ".$perldata->{'globalairquality'}->{'pollutants'}->{'O3'}->{'unit'};
	$wetData{'aqO3c'} = $perldata->{'globalairquality'}->{'pollutants'}->{'O3'}->{'category'};
	$wetData{'aqO3ci'} = $perldata->{'globalairquality'}->{'pollutants'}->{'O3'}->{'categoryIndex'};
	$wetData{'aqO3icon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'aqO3ci'} .'.png';
	#Particulate matter <10 µm
	$wetData{'aqPM10n'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM10'}->{'name'};
	$wetData{'aqPM10p'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM10'}->{'phrase'};
	$wetData{'aqPM10m'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM10'}->{'amount'}." ".$perldata->{'globalairquality'}->{'pollutants'}->{'PM10'}->{'unit'};
	$wetData{'aqPM10c'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM10'}->{'category'};
	$wetData{'aqPM10ci'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM10'}->{'categoryIndex'};
	$wetData{'aqPM10icon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'aqPM10ci'} .'.png';
	#Particulate matter <2.5 µm
	$wetData{'aqPM2.5n'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM2.5'}->{'name'};
	$wetData{'aqPM2.5p'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM2.5'}->{'phrase'};
	$wetData{'aqPM2.5m'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM2.5'}->{'amount'}." ".$perldata->{'globalairquality'}->{'pollutants'}->{'PM2.5'}->{'unit'};
	$wetData{'aqPM2.5c'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM2.5'}->{'category'};
	$wetData{'aqPM2.5ci'} = $perldata->{'globalairquality'}->{'pollutants'}->{'PM2.5'}->{'categoryIndex'};
	$wetData{'aqPM2.5icon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'aqPM2.5ci'} .'.png';
	#Sulfur Dioxide
	$wetData{'aqSO2n'} = $perldata->{'globalairquality'}->{'pollutants'}->{'SO2'}->{'name'};
	$wetData{'aqSO2p'} = $perldata->{'globalairquality'}->{'pollutants'}->{'SO2'}->{'phrase'};
	$wetData{'aqSO2m'} = $perldata->{'globalairquality'}->{'pollutants'}->{'SO2'}->{'amount'}." ".$perldata->{'globalairquality'}->{'pollutants'}->{'SO2'}->{'unit'};
	$wetData{'aqSO2c'} = $perldata->{'globalairquality'}->{'pollutants'}->{'SO2'}->{'category'};
	$wetData{'aqSO2ci'} = $perldata->{'globalairquality'}->{'pollutants'}->{'SO2'}->{'categoryIndex'};
	$wetData{'aqSO2icon'} = '/plugins/SuperDateTime/html/images/aqCI'. $wetData{'aqSO2ci'} .'.png';
	
	$log->debug(' ');
	$log->debug("AQI: ".$wetData{'gAQI'}." ".$wetData{'gAQC'}."(".$wetData{'gAQCI'}.") Primary: ".$wetData{'gPP'}); #Overall Air Quality
	$log->debug("Overall Air Quality icon URL: ". $wetData{'gAQicon'});
	$log->debug($wetData{'gMG'});
	$log->debug($wetData{'gMS'});
	$log->debug(' ');
	$log->debug($wetData{'aqCOp'}."(".$wetData{'aqCOn'}.") = ".$wetData{'aqCOm'}." - ".$wetData{'aqCOc'}."(".$wetData{'aqCOci'}.")"); #Carbon Monoxide
	$log->debug("CO2 icon URL: ". $wetData{'aqCOicon'});
	$log->debug($wetData{'aqNO2p'}."(".$wetData{'aqNO2n'}.") = ".$wetData{'aqNO2m'}." - ".$wetData{'aqNO2c'}."(".$wetData{'aqNO2ci'}.")"); #Nitrogen Dioxide
	$log->debug("NO2 icon URL: ". $wetData{'aqNO2icon'});
	$log->debug($wetData{'aqO3p'}."(".$wetData{'aqO3n'}.") = ".$wetData{'aqO3m'}." - ".$wetData{'aqO3c'}."(".$wetData{'aqO3ci'}.")"); #Ozone
	$log->debug("O3 icon URL: ". $wetData{'aqO3icon'});
	$log->debug($wetData{'aqPM10p'}."(".$wetData{'aqPM10n'}.") = ".$wetData{'aqPM10m'}." - ".$wetData{'aqPM10c'}."(".$wetData{'aqPM10ci'}.")"); #Particulate matter <10 µm
	$log->debug("PM10 icon URL: ". $wetData{'aqPM10icon'});
	$log->debug($wetData{'aqPM2.5p'}."(".$wetData{'aqPM2.5n'}.") = ".$wetData{'aqPM2.5m'}." - ".$wetData{'aqPM2.5c'}."(".$wetData{'aqPM2.5ci'}.")"); #Particulate matter <2.5 µm
	$log->debug("PM2.5 icon URL: ". $wetData{'aqPM2.5icon'});
	$log->debug($wetData{'aqSO2p'}."(".$wetData{'aqSO2n'}.") = ".$wetData{'aqSO2m'}." - ".$wetData{'aqSO2c'}."(".$wetData{'aqSO2ci'}.")"); #Sulfur Dioxide 
	$log->debug("SO2 icon URL: ". $wetData{'aqSO2icon'});
	$log->debug(' ');
	
	refreshData(undef, $client, $refreshItem);
}


sub getWeatherNow {  #Set up Async HTTP request for Weather
    my $timerObj = shift; #Should be undef
    my $client = shift;
    my $refreshItem = shift;
    
    if ($prefs->get('temperature') eq 0) { # fahrenheit
        $units = 'e'; 
    }
    else {
        $units = 'm';
    }
	my $url = 'https://api.weather.com/v3/wx/observations/current?geocode='.$lat.','.$long.'&units='.$units.'&language='.$prefs->get('lang').'&format=json&apiKey='.$wcKey;
	my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotWeatherNow,
                              \&gotErrorViaHTTP,
                              {caller => 'getWeatherNow',
                               callerProc => \&getWeatherNow,
                               client => $client,
                               refreshItem => $refreshItem});
    $log->debug("async request: $url");
    
    $http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0',
    'Accept-Language' => 'en-us,en;q=0.5',
    'Accept' => 'text/plain',
    'Accept-Charset' => 'UTF-8');
}

sub gotWeatherNow {  #Weather data was received
    my $http = shift;
    
    my $params = $http->params();
    my $client = $params->{'client'};
    my $refreshItem = $params->{'refreshItem'};

    my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
    $log->info("got " . $logURL);

    my $json = $http->content();
    my $perldata = eval{decode_json($json)}; 
	if ($@) {
		$log->error("Error detected in WeatherNow JSON. Error: ".$@);
		$log->error("Skipping WeatherNow");
		refreshData(undef, $client, $refreshItem);
		return;
	}
    
	#Store current weather observations  
    $wetData{-1}{'forecastTOD'} = $client->string('PLUGIN_SCREENSAVER_SUPERDATETIME_CURRENTLY');
    if ($units eq 'e'){
        $wetData{'temperatureF'} = $perldata->{'temperature'};
        $wetData{'temperatureC'} = FtoC($perldata->{'temperature'});
        $wetData{'MaxTempF'} = $perldata->{'temperatureMaxSince7Am'};
        $wetData{'MaxTempC'} = FtoC($perldata->{'temperatureMaxSince7Am'});
        $wetData{'feelslikeF'} = $perldata->{'temperatureFeelsLike'};
        $wetData{'feelslikeC'} = FtoC($perldata->{'temperatureFeelsLike'});
        $wetData{'dewpointF'} = $perldata->{'temperatureDewPoint'};
        $wetData{'dewpointC'} = FtoC($perldata->{'temperatureDewPoint'});
		$wetData{'windspeed_mh'} = $perldata->{'windSpeed'};
		$wetData{'windspeed_kh'} = nearest(1,($perldata->{'windSpeed'})*1.609344);
		$wetData{'windspeed_kth'} = nearest(1,($perldata->{'windSpeed'})/1.1515);
		$wetData{'windspeed_ms'} = nearest(1,$perldata->{'windSpeed'}*16.09344/36);
		$wetData{'gust_mh'} = $perldata->{'windGust'};
		$wetData{'gust_kh'} = nearest(1,($perldata->{'windGust'})*1.609344);
		$wetData{'gust_kth'} = nearest(1,($perldata->{'windGust'})/1.1515);
		$wetData{'gust_ms'} = nearest(1,$perldata->{'windGust'}*16.09344/36);
		$wetData{'pressureIN'} = $perldata->{'pressureAltimeter'};
		$wetData{'pressureMB'} = nearest(1,($perldata->{'pressureAltimeter'})*33.8639);
    }
    elsif ($units eq 'm') {
        $wetData{'temperatureF'} = CtoF($perldata->{'temperature'});
        $wetData{'temperatureC'} = $perldata->{'temperature'};
        $wetData{'MaxTempF'} = CtoF($perldata->{'temperatureMaxSince7Am'});
        $wetData{'MaxTempC'} = $perldata->{'temperatureMaxSince7Am'};
        $wetData{'feelslikeF'} = CtoF($perldata->{'temperatureFeelsLike'});
        $wetData{'feelslikeC'} = $perldata->{'temperatureFeelsLike'};
        $wetData{'dewpointF'} = CtoF($perldata->{'temperatureDewPoint'});
        $wetData{'dewpointC'} = $perldata->{'temperatureDewPoint'};
        $wetData{'windspeed_kh'} = $perldata->{'windSpeed'};
        $wetData{'windspeed_mh'} = nearest(1,($perldata->{'windSpeed'}) * 0.6213711922);
        $wetData{'windspeed_kth'} = nearest(1,($perldata->{'windSpeed'}) * 0.54);
        $wetData{'windspeed_ms'} = nearest(1,$perldata->{'windSpeed'} / 3.6);
        $wetData{'gust_kh'} = $perldata->{'windGust'};
        $wetData{'gust_mh'} = nearest(1,($perldata->{'windGust'}) * 0.6213711922);
        $wetData{'gust_kth'} = nearest(1,($perldata->{'windGust'}) * 0.54);
        $wetData{'gust_ms'} = nearest(1,$perldata->{'windGust'} / 3.6);
		$wetData{'pressureMB'} = nearest(1,$perldata->{'pressureAltimeter'});
		$wetData{'pressureIN'} = nearest(.01,($perldata->{'pressureAltimeter'})/33.8639);
	}
    else {
        $log->error('$units undefined');
    }

    $wetData{-1}{'forecastIcon'} = $perldata->{'iconCode'};
    $wetData{-1}{'forecastIconURLSmall'} = '/plugins/SuperDateTime/html/images/' . $perldata->{'iconCode'} . '.png';
    my $WindDir = $perldata->{'windDirectionCardinal'};
    $wetData{'windspeed_mh-NC'} = $wetData{'windspeed_mh'};
    $wetData{'windspeed_kh-NC'} = $wetData{'windspeed_kh'};
    $wetData{'windspeed_ms-NC'} = $wetData{'windspeed_ms'};
    $wetData{'windspeed_kth-NC'} = $wetData{'windspeed_kth'};
    $wetData{'windspeed_mh'} = $WindDir .' '. $wetData{'windspeed_mh'};
    $wetData{'windspeed_kh'} = $WindDir .' '. $wetData{'windspeed_kh'};
    $wetData{'windspeed_ms'} = $WindDir .' '. $wetData{'windspeed_ms'};
    $wetData{'windspeed_kth'} = $WindDir .' '. $wetData{'windspeed_kth'};
	if ($perldata->{'windGust'} eq '') {
		$wetData{'gust_mh'} = '--';
		$wetData{'gust_kh'} = '--';
		$wetData{'gust_kth'} = '--';
		$wetData{'gust_ms'} = '--';
	}
    $wetData{-1}{'skyCondition'} = $perldata->{'wxPhraseLong'};
    $wetData{'humidity'} = $perldata->{'relativeHumidity'};
	# Baro Trend ### 0=Steady, 1=Rising, 2=Dropping, 3=Rising Rapidly, 4=Falling Rapidly
    my $BaroTrend = $perldata->{'pressureTendencyCode'};
    if ($BaroTrend eq '0') { # Steady
        $wetData{'pressureT'} = '~'; # ~ is not displayed in all player text locations
    }
    elsif ($BaroTrend eq '2') { # Falling
        $wetData{'pressureT'} = '-';
    }
    elsif ($BaroTrend eq '1') { # Rising
        $wetData{'pressureT'} = '+'; # + is not displayed in all player text locations
    }
    elsif ($BaroTrend eq '3') { # Rising rapidly
        $wetData{'pressureT'} = '++'; 
        $log->warn('BaroTrend Code = 3 Baro Trend Description: ' . $perldata->{'pressureTendencyTrend'});
    }
    elsif ($BaroTrend eq '4') { # Falling rapidly
        $wetData{'pressureT'} = '--'; 
        $log->warn('BaroTrend Code = 4 Baro Trend Description: ' . $perldata->{'pressureTendencyTrend'});
    }
    else {
        $log->warn('Unknown Barometer Trend Status!!!  Code = ' . $BaroTrend);
        $log->warn('Barometer Trend Description = '.$perldata->{'pressureTendencyTrend'});
    }
    
	# UV index and 24hr precip/snow accumulations 
    $wetData{'UVindexNum'} = $perldata->{'uvIndex'};
    $wetData{'UVindexTxt'} = $perldata->{'uvDescription'};
    $wetData{'rain'} = $perldata->{'precip24Hour'};
    $wetData{'snow'} = $perldata->{'snow24Hour'};

	# Retrieve and store latest weather radar map images locally each refresh cycle.
	my $response = getstore($LocalURL, $wetMapFiles{'Local'}{'URL'});
	if (is_success($response)) {
	    $log->debug("Weather Map Local successfully stored! Response: " . $response);
	}
	else {
	    $log->warn("Storing Weather Map Local FAILED! Response: " . $response);
	}

	my $response = getstore($MediumURL, $wetMapFiles{'Medium'}{'URL'});
	if (is_success($response)) {
	    $log->debug("Weather Map Medium successfully stored! Response: " . $response);
	}
	else {
	    $log->warn("Storing Weather Map Medium FAILED! Response: " . $response);
	}

	my $response = getstore($WideURL, $wetMapFiles{'Wide'}{'URL'});
	if (is_success($response)) {
	    $log->debug("Weather Map Wide successfully stored! Response: " . $response);
	}
	else {
	    $log->warn("Storing Weather Map Wide FAILED! Response: " . $response);
	}

	# Debug logs
    $log->debug("Time of Day: " . $wetData{-1}{'forecastTOD'});
    $log->debug("Temperature F: " . $wetData{'temperatureF'});
    $log->debug("Temperature C: " . $wetData{'temperatureC'});
    $log->debug("Max Temperature F: " . $wetData{'MaxTempF'});
    $log->debug("Max Temperature C: " . $wetData{'MaxTempC'});
    $log->debug("ICON: " . $wetData{-1}{'forecastIcon'});
    $log->debug("ICON URL: " . $wetData{-1}{'forecastIconURLSmall'});
    $log->debug("Feels Like F: " . $wetData{'feelslikeF'});
    $log->debug("Feels Like C: " . $wetData{'feelslikeC'});
    $log->debug("Wind Speed MPH: " . $wetData{'windspeed_mh'});
    $log->debug("Wind Speed KM/H: " . $wetData{'windspeed_kh'});
    $log->debug("Wind Speed Knots/H: " . $wetData{'windspeed_kth'});
    $log->debug("Wind Speed Meters/S: " . $wetData{'windspeed_ms'});
    $log->debug("Wind Speed MPH: " . $wetData{'windspeed_mh-NC'});
    $log->debug("Wind Speed KM/H: " . $wetData{'windspeed_kh-NC'});
    $log->debug("Wind Speed Knots: " . $wetData{'windspeed_kth-NC'});
    $log->debug("Wind Speed Meters/S: " . $wetData{'windspeed_ms-NC'});
    $log->debug("Wind Gust MPH: " . $wetData{'gust_mh'});
    $log->debug("Wind Gust KM/H: " . $wetData{'gust_kh'});
    $log->debug("Wind Gust Knots: " . $wetData{'gust_kth'});
    $log->debug("Wind Gust Meters/S: " . $wetData{'gust_ms'});
    $log->debug("Sky Condition: " . $wetData{-1}{'skyCondition'});
    $log->debug("Humidity: " . $wetData{'humidity'});
    $log->debug("Dewpoint F: " . $wetData{'dewpointF'});
    $log->debug("Dewpoint C: " . $wetData{'dewpointC'});
    $log->debug("Barometer IN: " . $wetData{'pressureIN'});
    $log->debug("Barometer MB: " . $wetData{'pressureMB'});
    $log->debug("Trend Raw: " . $BaroTrend);
    $log->debug("Trend: " . $wetData{'pressureT'});
    $log->debug("UV Index: " . $wetData{'UVindexNum'});
    $log->debug("UV Text: " . $wetData{'UVindexTxt'});
    $log->debug("24Hr Rain Total: " . $wetData{'rain'});
    $log->debug("Snow Depth: " . $wetData{'snow'});
    
    refreshData(undef, $client, $refreshItem);
}

sub getWunderground {  #Set up Async HTTP request for Weather
    my $timerObj = shift; #Should be undef
    my $client = shift;
    my $refreshItem = shift;
    
    if ($prefs->get('wunder') ne '') { #Make sure wunderground data is needed  
        my $url = 'https://api.weather.com/v2/pws/observations/current?stationId=' .$prefs->get('wunder').'&numericPrecision=decimal&format=json&units='.$units.'&apiKey='.$wuKey;
        my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotWunderground,
                          \&gotErrorViaHTTP,
                          {caller => 'getWunderground',
                            callerProc => \&getWunderground,
                           client => $client,
                           refreshItem => $refreshItem});
    
        $log->debug("async request: $url");
        $http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
    }
    else {
        $log->info("No wunderground.com value set.  Skipping...");
		$wetData{'wu_check'} = 0;
        refreshData(undef, $client, $refreshItem);
    }

}

sub gotWunderground {  #Weather data was received
    my $http = shift;
    
    my $params = $http->params();
    my $client = $params->{'client'};
    my $refreshItem = $params->{'refreshItem'};

    my $apiPOS = index($http->url(), "&apiKey=");
	my $logURL = substr($http->url(),0,$apiPOS)."&apiKey=HIDDEN";
    $log->info("got " . $logURL);

    my $WU_json = $http->content();

	my $windSpeedMH = '';
	my $windSpeedKH = '';
	my $windSpeedMS = '';
	my $windSpeedKTH = '';
	my $windGustMH = '';
	my $windGustKH = '';
	my $windGustMS = '';
	my $windGustKTH = '';

	$wetData{'wu_check'} = 0;
	if ($WU_json ne "") {
		$wetData{'wu_check'} = 1;
		my $perldata = decode_json($WU_json);
		my $WU_array = $perldata->{'observations'}; # store array
		my $WU_detail = @$WU_array[0]; # dereference array
		
		$wetData{'wu_obsTimeLocal'} = $WU_detail->{'obsTimeLocal'};
		$wetData{'wu_station'} = $WU_detail->{'stationID'};
		$wetData{'wu_nhood'} = $WU_detail->{'neighborhood'};
		$wetData{'wu_latitude'} = sprintf("%.2f", $WU_detail->{'lat'});
		$wetData{'wu_longitude'} = sprintf("%.2f", $WU_detail->{'lon'});
		$wetData{'wu_humidity'} =  $WU_detail->{'humidity'};

		if ($units eq 'e') {
			$wetData{'wu_temperatureF'} = $WU_detail->{'imperial'}->{'temp'};
			$wetData{'wu_temperatureFr'} = nearest(1,$wetData{'wu_temperatureF'});
			$wetData{'wu_heatIndexFr'} = nearest(1,$WU_detail->{'imperial'}->{'heatIndex'});
			$wetData{'wu_windChillFr'} = nearest(1,$WU_detail->{'imperial'}->{'windChill'});
			$wetData{'wu_temperatureC'} = FtoC($wetData{'wu_temperatureF'}); 
			$wetData{'wu_temperatureCr'} = nearest(1, $wetData{'wu_temperatureC'});
			$wetData{'wu_heatIndexCr'} = nearest(1, FtoC($WU_detail->{'imperial'}->{'heatIndex'}));
			$wetData{'wu_windChillCr'} = nearest(1, FtoC($WU_detail->{'imperial'}->{'windChill'}));
			$wetData{'wu_dewpointF'} = $WU_detail->{'imperial'}->{'dewpt'};
			$wetData{'wu_dewpointC'} = FtoC($wetData{'wu_dewpointF'});    
			$wetData{'wu_pressureIN'} = $WU_detail->{'imperial'}->{'pressure'};
			$wetData{'wu_pressureMB'} = nearest(1, $wetData{'wu_pressureIN'} * 33.8639);
			$wetData{'wu_precipTotIN'} = $WU_detail->{'imperial'}->{'precipTotal'};
			$wetData{'wu_precipTotMM'} = nearest(.01,($wetData{'wu_precipTotIN'}*25.4));
			$windSpeedMH = $WU_detail->{'imperial'}->{'windSpeed'};
			$windSpeedKH = nearest(.1, $windSpeedMH*1.609344);
			$windSpeedMS = nearest(.1, $windSpeedMH*16.09344/36);
			$windSpeedKTH = nearest(.1, $windSpeedMH/1.1515);
			$windGustMH = $WU_detail->{'imperial'}->{'windGust'};
			if ($windGustMH eq '') {
				$windGustMH = '--';
				$windGustKH = '--';
				$windGustMS = '--';
				$windGustKTH = '--';
			}
			else {
				$windGustKH = nearest(.1, $windGustMH*1.609344);
				$windGustMS = nearest(.1, $windGustMH*16.09344/36);
				$windGustKTH = nearest(.1, $windGustMH/1.1515);
			}
		}
		elsif ($units eq 'm') {
			$wetData{'wu_temperatureC'} = $WU_detail->{'metric'}->{'temp'}; 
			$wetData{'wu_temperatureCr'} = nearest(1, $wetData{'wu_temperatureC'});
			$wetData{'wu_heatIndexCr'} = nearest(1, $WU_detail->{'metric'}->{'heatIndex'});
			$wetData{'wu_windChillCr'} = nearest(1, $WU_detail->{'metric'}->{'windChill'});
			$wetData{'wu_temperatureF'} = CtoF($wetData{'wu_temperatureC'});
			$wetData{'wu_temperatureFr'} = nearest(1, $wetData{'wu_temperatureF'});
			$wetData{'wu_heatIndexFr'} = nearest(1, CtoF($wetData{'wu_heatIndexCr'}));
			$wetData{'wu_windChillFr'} = nearest(1, CtoF($wetData{'wu_windChillCr'}));
			$wetData{'wu_dewpointC'} = $WU_detail->{'metric'}->{'dewpt'};
			$wetData{'wu_dewpointF'} = CtoF($wetData{'wu_dewpointC'});    
			$wetData{'wu_pressureMB'} = $WU_detail->{'metric'}->{'pressure'};
			$wetData{'wu_pressureIN'} = nearest(.01, $wetData{'wu_pressureMB'}/33.8639);
			$wetData{'wu_precipTotMM'} = $WU_detail->{'metric'}->{'precipTotal'};
			$wetData{'wu_precipTotIN'} = nearest(.01,($wetData{'wu_precipTotMM'}/25.4));
			$windSpeedKH = $WU_detail->{'metric'}->{'windSpeed'};
			$windSpeedMH = nearest(.1, $windSpeedKH*0.6213711922);
			$windSpeedMS = nearest(.1, $windSpeedKH/3.6);
			$windSpeedKTH = nearest(.1, $windSpeedKH*0.54);
			$windGustKH = $WU_detail->{'metric'}->{'windGust'};
			if ($windGustKH eq '') {
				$windGustMH = '--';
				$windGustKH = '--';
				$windGustMS = '--';
				$windGustKTH = '--';
			}
			else {
				$windGustMH = nearest(.1, $windGustKH*0.6213711922);
				$windGustMS = nearest(.1, $windGustKH/3.6);
				$windGustKTH = nearest(.1, $windGustKH*0.54);
			}
		}
		else {
			$log->error("Unknown units setting!!!  units = " . $units);
		}

		# Set feels like temperature
		$wetData{'wu_feelsLikeFr'} = $wetData{'wu_heatIndexFr'};
		if ($wetData{'wu_windChillFr'} < $wetData{'wu_temperatureFr'}) {
			$wetData{'wu_feelsLikeFr'} = $wetData{'wu_windChillFr'};
		}
		$wetData{'wu_feelsLikeCr'} = $wetData{'wu_heatIndexCr'};
		if ($wetData{'wu_windChillCr'} < $wetData{'wu_temperatureCr'}) {
			$wetData{'wu_feelsLikeCr'} = $wetData{'wu_windChillCr'};
		}

		# Convert wind direction to compass
		my @compass = split(' ',$client->string('PLUGIN_SDT_WU_COMPASS'));
		my $windDirDegrees = $WU_detail->{'winddir'};
		my $windDirCompass = sprintf("%.0f",($windDirDegrees/22.5));
		$windDirCompass = $compass[$windDirCompass];
		$wetData{'wu_windspeed_mh'} = $windDirCompass.' '.$windSpeedMH;
		$wetData{'wu_windspeed_kh'} = $windDirCompass.' '.$windSpeedKH;
		$wetData{'wu_windspeed_ms'} = $windDirCompass.' '.$windSpeedMS;
		$wetData{'wu_windspeed_kth'} = $windDirCompass.' '.$windSpeedKTH;
		$wetData{'wu_windspeed_mh-NC'} = $windSpeedMH;
		$wetData{'wu_windspeed_kh-NC'} = $windSpeedKH;
		$wetData{'wu_windspeed_ms-NC'} = $windSpeedMS;
		$wetData{'wu_windspeed_kth-NC'} = $windSpeedKTH;
		$wetData{'wu_windGust_mh'} = $windGustMH;
		$wetData{'wu_windGust_kh'} = $windGustKH;
		$wetData{'wu_windGust_ms'} = $windGustMS;
		$wetData{'wu_windGust_kth'} = $windGustKTH;
		
		$log->debug("units setting: ".$units);
		$log->debug("WU Station: ".$wetData{'wu_station'});
		$log->debug("WU Neighborhood: ".$wetData{'wu_nhood'});
		$log->debug("WU Station Lat: ".$wetData{'wu_latitude'});
		$log->debug("WU Station Long: ".$wetData{'wu_longitude'});
		$log->debug("TemperatureF: ".$wetData{'wu_temperatureF'});
		$log->debug("TemperatureFr: ".$wetData{'wu_temperatureFr'});
		$log->debug("Feels-likeFr: ".$wetData{'wu_feelsLikeFr'});
		$log->debug("TemperatureC: ".$wetData{'wu_temperatureC'});
		$log->debug("TemperatureCr: ".$wetData{'wu_temperatureCr'});
		$log->debug("Feels-likeCr: ".$wetData{'wu_feelsLikeCr'});
		$log->debug("DewpointF: ".$wetData{'wu_dewpointF'});
		$log->debug("DewpointC: ".$wetData{'wu_dewpointC'});
		$log->debug("PressureIN: ".$wetData{'wu_pressureIN'});
		$log->debug("PressureMB: ".$wetData{'wu_pressureMB'});
		$log->debug("Humidity: ".$wetData{'wu_humidity'});
		$log->debug("WindDirCompassLang: ".$client->string('PLUGIN_SDT_WU_COMPASS'));
		$log->debug("WindDirDegrees: ".$windDirDegrees);
		$log->debug("WindDirCompass: ".$windDirCompass);
		$log->debug("WindSpeedMH: ".$windSpeedMH);
		$log->debug("WindSpeedKH: ".$windSpeedKH);
		$log->debug("WindSpeedMS: ".$windSpeedMS);
		$log->debug("WindSpeedKTH: ".$windSpeedKTH);
		$log->debug("WindSpeedMH: ".$wetData{'wu_windspeed_mh'});
		$log->debug("WindSpeedKH: ".$wetData{'wu_windspeed_kh'});
		$log->debug("WindSpeedMS: ".$wetData{'wu_windspeed_ms'});
		$log->debug("WindSpeedKTH: ".$wetData{'wu_windspeed_kth'});
		$log->debug("WindGustMH: ".$windGustMH);
		$log->debug("WindGustKH: ".$windGustKH);
		$log->debug("WindGustMS: ".$windGustMS);
		$log->debug("WindGustKTH: ".$windGustKTH);
		$log->debug("PrecipTotIN: ".$wetData{'wu_precipTotIN'});
		$log->debug("PrecipTotMM: ".$wetData{'wu_precipTotMM'});
	}
	else {
		$log->warn("Warning: Weather Underground Station ".$prefs->get('wunder')." is not returning any data.");
		refreshData(undef, $client, $refreshItem);
	}
	refreshData(undef, $client, $refreshItem);
}

sub getStocks {  #Set up Async HTTP request for Stocks
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;

	my $stocks = $prefs->get('stocks');
	$log->debug("Stock prefs = " . $stocks);
	$stocks =~ s/^\s+|\s+$//g; # remove any leading or trailing spaces
	$stocks =~ tr/\^/\./s; # replace ^ with . for stock indices. 
	$stocks =~ tr/ /,/s; # Convert space delimited to comma delimited.
	$stocks =~ tr/,//s;
	$stocks =~ tr/,/|/s; # Convert comma delimited to pipe delimited.
	$log->debug("Stock adjust = " . $stocks);

	if ($stocks) {
		my $url = 'https://quote.cnbc.com/quote-html-webservice/restQuote/symbolType/symbol?symbols='.$stocks.'&requestMethod=itv&noform=1&partnerId=2&fund=1&exthrs=1&output=json&events=1';
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotStocks,
							  \&gotErrorViaHTTP,
							  {caller => 'getStocks',
							   callerProc => \&getStocks,                             
							   client => $client,
							   refreshItem => $refreshItem});
		
		$log->debug("async request: $url");
		$http->get($url, 
			'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
			'Accept-Charset' => 'UTF-8',
			'Cache-Control' => 'max-age=0',
			'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.31'),
    }
    else {
        $log->info("No stocks selected... Skipping");
		delete $miscData{'stocks'};
        refreshData(undef, $client, $refreshItem);
    }
}

sub gotStocks {  #Stock data was received
    my $http = shift;
    
    my $params = $http->params();
    my $client = $params->{'client'};
    my $refreshItem = $params->{'refreshItem'};
    
    $log->info("got " . $http->url());

	delete $miscData{'stocks'}; #Wipe out old stock values on each refresh
    my $Stock_json = $http->content();
    my $perldata = eval{decode_json($Stock_json)};
	if ($@) {
		$log->error("Error detected in Stocks JSON. Error: ".$@);
		$log->error("Skipping Stocks");
		refreshData(undef, $client, $refreshItem);
		return;
	}

    my $ticker_array = $perldata->{'FormattedQuoteResult'}->{'FormattedQuote'}; # store array from JSON file
	my $ticker_count = scalar(@$ticker_array);
	my $ticker_counter = 0;
    $log->debug("Ticker Count = " . $ticker_count);

	my $year = '';
	my $mon = '';
	my $mday = '';
	my $hour = '';
	my $min = '';

	while ($ticker_counter < $ticker_count) {
		my $ticker = @$ticker_array[$ticker_counter]->{'symbol'}; 
		$miscData{'stocks'}{$ticker}{'ticker'} = $ticker;

		my $name = @$ticker_array[$ticker_counter]->{'name'};
		$miscData{'stocks'}{$ticker}{'name'} = $name;
		
		if ($name) {
			my $lasttrade = @$ticker_array[$ticker_counter]->{'last'};
			$miscData{'stocks'}{$ticker}{'lasttrade'} = $lasttrade;

			my $lastdate = @$ticker_array[$ticker_counter]->{'last_timedate'};
			my $lasttime = @$ticker_array[$ticker_counter]->{'last_time'};
			if ($lasttime =~ m/(\d*)-(\d*)-(\d*)T(\d+):(\d+)/) {
				$year	= $1;
				$mon	= $2;
				$mday 	= $3;
				$hour 	= $4;
				$min 	= $5;
				$lastdate = $mon.'/'.$mday.'/'.$year;
				$lasttime = $hour.':'.$min
			}
			elsif (length($lastdate)>10) {
				$log->debug("Time of last trade 1 or more days ago.");
				if ($lasttime =~ m/(\d*)-(\d*)-(\d*)/) { # "last_time": "2024-11-27"
					$year = $1;
					$mon = $2;
					$mday = $3;
					$lastdate = $mon.'/'.$mday.'/'.$year;
					$lasttime = '';
				}
				else {
					$log->error("Unexpected format for \"last_time\" data.");
					$lastdate = substr(@$ticker_array[$ticker_counter]->{'last_timedate'},0,8);
					$lasttime = '';			
				}
			}
			else {
				$log->error("Unexpected format for \"last_time\" data.");
				$lastdate = @$ticker_array[$ticker_counter]->{'last_timedate'};
				$lasttime = @$ticker_array[$ticker_counter]->{'last_time'};			
			}
			$miscData{'stocks'}{$ticker}{'lasttime'} = $lasttime;
			$miscData{'stocks'}{$ticker}{'lastdate'} = $lastdate;

			my $change = @$ticker_array[$ticker_counter]->{'change'};
			$miscData{'stocks'}{$ticker}{'change'} = $change;

			my $open = @$ticker_array[$ticker_counter]->{'open'};
			$miscData{'stocks'}{$ticker}{'open'} = $open;

			my $high = @$ticker_array[$ticker_counter]->{'high'};
			$miscData{'stocks'}{$ticker}{'high'} = $high;

			my $low = @$ticker_array[$ticker_counter]->{'low'};
			$miscData{'stocks'}{$ticker}{'low'} = $low;

			my $prev = @$ticker_array[$ticker_counter]->{'previous_day_closing'};
			$miscData{'stocks'}{$ticker}{'prevclose'} = $prev;

			my $pchange = @$ticker_array[$ticker_counter]->{'change_pct'};
			$miscData{'stocks'}{$ticker}{'pchange'} = $pchange;

			my $volume = @$ticker_array[$ticker_counter]->{'volume'};
			$miscData{'stocks'}{$ticker}{'volume'} = $volume;

			my $RangeDay = $low.' - '.$high;
			$miscData{'stocks'}{$ticker}{'RangeDay'} = $RangeDay;

			my $R52WeekLo	= @$ticker_array[$ticker_counter]->{'yrloprice'};
			my $R52WeekHi	= @$ticker_array[$ticker_counter]->{'yrhiprice'};
			my $R52Week	= $R52WeekLo.' - '.$R52WeekHi;
			$miscData{'stocks'}{$ticker}{'R52Week'} = $R52Week;

			$log->debug("ticker: " . $ticker);
			$log->debug("name: " . $name);
			$log->debug("prev: " . $prev);
			$log->debug("open: " . $open);
			$log->debug("high: " . $high);
			$log->debug("low: " . $low);
			$log->debug("last trade: " . $lasttrade);
			$log->debug("change: " . $change);
			$log->debug("pchange: " . $pchange);
			$log->debug("volume: " . $volume);
			$log->debug("Day Range: " . $RangeDay);
			$log->debug("52 Week Range: " . $miscData{'stocks'}{$ticker}{'R52Week'});
			$log->debug("last date: " . $lastdate);
			$log->debug("last time: " . $lasttime); #### no data????
			$log->debug(" ");
			
			my $line1 = $prefs->get('stock1format');
			my $line2 = $prefs->get('stock2format');

			for ($line1) {
				s/%s/$ticker/;
				s/%l/$lasttrade/;
				s/%d/$lastdate/;
				s/%t/$lasttime/;
				s/%c/$change/;
				s/%o/$open/;
				s/%h/$high/;
				s/%w/$low/;
				s/%v/$volume/;
				s/%n/$name/;
				s/%r/$RangeDay/;
				s/%R/$R52Week/;
				s/%p/$prev/;
				s/%z/$pchange/;
			}
			for ($line2) {
				s/%s/$ticker/;
				s/%l/$lasttrade/;
				s/%d/$lastdate/;
				s/%t/$lasttime/;
				s/%c/$change/;
				s/%o/$open/;
				s/%h/$high/;
				s/%w/$low/;
				s/%v/$volume/;
				s/%n/$name/;
				s/%r/$RangeDay/;
				s/%R/$R52Week/;
				s/%p/$prev/;
				s/%z/$pchange/;             
			}
			addDisplayItem('getStocks', $line1, $line2, $showgame);
		}
		else {
			$log->error("ERROR.  No data returned for stock symbol \"".$ticker."\".  Adjust SDT stock settings as needed.");
			$log->error(" ");
		}
		$ticker_counter ++;
	}
	refreshData(undef, $client, $refreshItem); # done
}

sub refreshSoon {
    my $client = shift;

	duetCheck(); # Add another check for players during setting changes.
	
    # Save top showing preference incase server is shut down
    if (defined $topNowShowing{$client}) {
        $prefs->client($client)->set('topNowShowing', $topNowShowing{$client});
    }
    
    # Clear previous display info
    @WETdisplayItems1 =();
    @WETdisplayItems2 =();
    @WETdisplayItems3 =();
    
    $averages{'last'} = ''; #Make sure averages/10day will get refreshed too
    for(my $i=-1; $i<2; $i++) { #Wipe individual averages just in case new weather identifier does not support them
        $wetData{$i}{'average_F'} = '';
        $wetData{$i}{'average_C'} = '';
                    
        $wetData{$i}{'record_F'} = '';
        $wetData{$i}{'record_C'} = '';
                
        $wetData{$i}{'record_year'} = '';
                    
        $wetData{$i}{'sunrise'} = '';
        $wetData{$i}{'sunset'}  = '';
    }
    
    #Need to reload updated prefs
    @MLBteams = @{ $prefs->get('mlb') || [] };
    $refreshTracker[0] = 1; #Need to refresh MLB again
    @NBAteams = @{ $prefs->get('nba') || [] };
    $refreshTracker[1] = 1; #Need to refresh NBA again
    @NHLteams = @{ $prefs->get('nhl') || [] };
    $refreshTracker[2] = 1; #Need to refresh NHL again
    @WNBAteams = @{ $prefs->get('wnba') || [] };
    @NFLteams = @{ $prefs->get('nfl') || [] };
	$NFL_GameCount = 0;
    $refreshTracker[3] = 1; 
    @soccerTeams = @{ $prefs->get('soccer') || [] };
	$soccer_GameCount = 0;
	$refreshTracker[4] = 1;
    @CBBteams = @{ $prefs->get('cbb') || [] };
	$CBB_GameCount = 0;
	$refreshTracker[5] = 1;
    @CFBteams = @{ $prefs->get('cfb') || [] };
	$CFB_GameCount = 0;
	$refreshTracker[6] = 1;
    $showtime = $prefs->get('time');
    $showgame = $prefs->get('score');
    $showactivetime = $prefs->get('atime');
    $showactivegame = $prefs->get('ascore');
    
    # Update 10day forecasts for C or F based on preference
    my @players = Slim::Player::Client::clients();
    for my $player (@players) {
        my @weatherformat1b = @{ $prefs->client($player)->get('weatherformat1b') || [] };
        my @weatherformat2t = @{ $prefs->client($player)->get('weatherformat2t') || [] };
        if ($prefs->get('temperature') == 1) {  #Cel
            $weatherformat1b[1] =~ s/%_5\/%_7/%_6\/%_8/;
            $prefs->client($player)->set('weatherformat1b', \@weatherformat1b); 
            $weatherformat2t[1] =~ s/%_5\/%_7/%_6\/%_8/;
            $prefs->client($player)->set('weatherformat2t', \@weatherformat2t); 
        }
        else {
            $weatherformat1b[1] =~ s/%_6\/%_8/%_5\/%_7/;
            $prefs->client($player)->set('weatherformat1b', \@weatherformat1b);     
            $weatherformat2t[1] =~ s/%_6\/%_8/%_5\/%_7/;
            $prefs->client($player)->set('weatherformat2t', \@weatherformat2t);     
        }
    }   

    # If refreshing due to a setting change make sure weather.com identifier is still correct.  
    if (length($prefs->get('city')) eq 10 || length($prefs->get('city')) eq 13 and $prefs->get('city') =~ /.+\:\d\:\D\D/) { # Check for proper weather.com citycode format
		$log->debug("Valid weather.com station entry. " . $prefs->get('city'));
	}
	elsif (length($prefs->get('city')) eq 5 and $prefs->get('city') =~ /\d{5,5}/) { # Check for US postal code.
        $log->error("US Postal Code entered without suffix. " . $prefs->get('city'));
		my $zip = $prefs->get('city');
		$zip = $zip.":4:US";
		$prefs->set('city',$zip);
        $log->error("Suffix added.  Weather station set to " . $prefs->get('city'));
	}
	elsif (length($prefs->get('city')) eq 8 and $prefs->get('city') =~ /\D{4}\d{4}/)  { #Check for weather.code weather station 
        $log->error("Weather.code station entered without suffix. " . $prefs->get('city'));
		my $station = $prefs->get('city');
		my $cc = substr($station,0,2);
		$station = $station.":1:".$cc; # Add suffix to weather station ID.
		$prefs->set('city',$station);
        $log->error("Suffix added.  Weather station set to " . $prefs->get('city'));
	}
	else # Entry for weather.com identifier is invalid.  Set to default of Chicago.
	{
        $log->error("Invalid Weather.com Identifier entered. " . $prefs->get('city'));
        $log->error("Check your Weather.com Identifier and try again");
        $prefs->set('city','60614:4:US'); #Default to Chicago... cuz Chicago is where it's at! 
        $log->error("Defaulting identifier to Chicago: " . $prefs->get('city'));
    }
    getLatLong(); # Retrieve Latitude and Longitude for weather.com location
    
    # No need to refresh data unless there are active clients
    if ($activeClients >0) {
        Slim::Utils::Timers::killTimers(undef, \&refreshData);
        #Refresh in 8 seconds.  In case user keeps changing settings so there are less refreshes maybe.....
        Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 8, \&refreshData, $client, -1);
    }
}

sub refreshPlayerSettings {
    my $timerObj = shift; #Should be undef
    my $client = shift;

    my $prefs = preferences('plugin.superdatetime');

    my @show1icon = @{ $prefs->client($client)->get('show1icon') || [] };
    if (scalar(@show1icon) == 0) {
        if(!$client->display->isa('Slim::Display::Boom')) {
            $show1icon[0] = 1;
            $show1icon[1] = 1;
        }
        else {
            $show1icon[0] = 0;
            $show1icon[1] = 1;
        }
        $prefs->client($client)->set('show1icon', \@show1icon);
    }

    my @show13line = @{ $prefs->client($client)->get('show13line') || [] };
    if (scalar(@show13line) == 0) {
        $show13line[0] = 1;
        $show13line[1] = 1;
        $prefs->client($client)->set('show13line', \@show13line);
    }

    my @d3line1t = @{ $prefs->client($client)->get('v3line1t') || [] };
    if (scalar(@d3line1t) == 0) {
        $d3line1t[0] = '';
        $d3line1t[1] = '';
        $prefs->client($client)->set('v3line1t', \@d3line1t);
    }

######### Adjust for Fahrenheit vs Celsius settings ############
		my @d3line1m = @{ $prefs->client($client)->get('v3line1m') || [] };
		if (scalar(@d3line1m) == 0) {
			$d3line1m[0] = '%z';
			$d3line1m[1] = ' %_4';
			$prefs->client($client)->set('v3line1m', \@d3line1m);
		}

		my @d3line1b = @{ $prefs->client($client)->get('v3line1b') || [] };
		if (scalar(@d3line1b) == 0) {
			$d3line1b[0] = 'RAIN %x';
			$d3line1b[1] = 'RAIN %_9';
			$prefs->client($client)->set('v3line1b', \@d3line1b);
		}

		my @weatherformat1b = @{ $prefs->client($client)->get('weatherformat1b') || [] };
		if (scalar(@weatherformat1b) == 0) {
			if(!$client->display->isa('Slim::Display::Boom')) {
				$weatherformat1b[0] = '%t/%h %1';
			}
			else {
				$weatherformat1b[0] = '%t %1';
			}
			$weatherformat1b[1] = '%_5/%_7';
			$prefs->client($client)->set('weatherformat1b', \@weatherformat1b);
		}
		
		my @weatherformat1t = @{ $prefs->client($client)->get('weatherformat1t') || [] };
		if (scalar(@weatherformat1t) == 0) {
			$weatherformat1t[0] = '%y: %v';
			$weatherformat1t[1] = '%_3: %_0';
			$prefs->client($client)->set('weatherformat1t', \@weatherformat1t);
		}

		my @weatherformat2b = @{ $prefs->client($client)->get('weatherformat2b') || [] };
		if (scalar(@weatherformat2b) == 0) {
			$weatherformat2b[0] = '%f  %a(%c %g)';
			$weatherformat2b[1] = '%_0';
			$prefs->client($client)->set('weatherformat2b', \@weatherformat2b);
		}

		my @weatherformat2t = @{ $prefs->client($client)->get('weatherformat2t') || [] };
		if (scalar(@weatherformat2t) == 0) {
			$weatherformat2t[0] = '%s - %S';
			$weatherformat2t[1] = '%_3: %_5/%_7';
			$prefs->client($client)->set('weatherformat2t', \@weatherformat2t);
		}
###########################################################################################

    my @d1period = @{ $prefs->client($client)->get('v1period') || [] };
    if (scalar(@d1period) == 0) {
        $d1period[0] = -1; 
        $d1period[1] = -1;
        $prefs->client($client)->set('v1period', \@d1period);
    }

    if ($prefs->client($client)->get('disableVisualizer') eq '') {
        $prefs->client($client)->set('disableVisualizer', 0);
    }
    
    if ($prefs->client($client)->get('scroll') eq '') {
        if(!$client->display->isa('Slim::Display::Boom')) {
            $scrollType{$client} = 'Slide';
        }
        else {
            $scrollType{$client} = 'Ticker';
        }
        $prefs->client($client)->set('scroll', $scrollType{$client});
    }
    else {
        $scrollType{$client} = $prefs->client($client)->get('scroll');
    }
    
    my $fdays = $prefs->client($client)->get('fdays');
    if ($fdays eq '') {
        $prefs->client($client)->set('fdays', 3);
    }
    
    if ($topNowShowing{$client} <0 || $topNowShowing{$client} > $fdays +3 ) {
        $topNowShowing{$client} = 1;
        $prefs->client($client)->set('topNowShowing', 1);
    }
}

sub refreshData {
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;
	$refreshItem = $refreshItem + 1;
	
	if ($refreshItem == 0) { #New data refresh, weather.com
		$log->info("Data refresh in process...");

		# If a graphical client was stored, use it when refreshing data.  
		# This makes sure the special fonts are used when drawing screens.
		if (defined $Gclient) { 
			$client = $Gclient;
		}

		Slim::Utils::Timers::killTimers(undef, \&stuckMonitor); #Paranoia check
		Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + (($prefs->get('refresh') * 60)*2), \&stuckMonitor, $client); #Set up stuck monitor

		my $data = {
			'state' => 'Refreshing'
		};
		Slim::Control::Request::notifyFromArray(undef,['SuperDateTimeState','dataRefreshState',$data]);
		$wetData{'RefreshTime'} = strftime "%Y-%m-%d %H:%M:%S", localtime;

		$errorCount = 0; #Reset network error counter for new refresh

		refreshPlayerSettings(undef, $client); #Didnt seem to want to refresh elsewhere
		
		%displayInfoBuild = (); #Paranoia, should already be empty
		%macroHash = (); #Wipe out any custom macros that have been set previously

		my ($mday,$mon,$year,$hour, $isdst) = (gmtime(time-(60*60*8)))[3,4,5,2,8];  #Figure out Pacific time based on GMT time to line up with MLB, NBA, & NFL day resets
		if ($mday < 10) {
			$mday = '0' . $mday;
		}

		$mon++; #Starts at 0
		if ($mon < 10) {
			$mon = '0' . $mon;
		}
		$year = $year + 1900;
	
		$log->debug("Pacific Hour/Date:$hour/$mday");
		$log->debug("Last refresh date: ".$lastRefresh);

		if ((($lastRefresh ne ($year . $mon . $mday)) && $hour >4) || $lastRefresh eq '') { #5AM PST start refreshing a new day
			@refreshTracker = ();
			#Should this be moved into their own subs.... would need separate $lastRefreshes then
			$refreshTracker[0] = 1; #Need to refresh MLB again
			$refreshTracker[1] = 1; #Need to refresh NBA again
			$refreshTracker[2] = 1; #Need to refresh NHL again
			$refreshTracker[3] = 1; #Need to refresh NFL again
			$refreshTracker[4] = 1; #Soccer
			$refreshTracker[5] = 1; #CBB
			$refreshTracker[6] = 1; #CFB
			$lastRefresh = $year.$mon.$mday;
		}
		
		#Update status indicator to show that a data refresh is in progress
		$status = '*';

		#Is this okay since old data is still being displayed?
		$newActiveGames = 0; #Reset active game flag for upcoming sports data refresh

		getWeatherNow(undef, $client, $refreshItem);
	}
	elsif (defined $providers{$refreshItem}) { #Dynamic provider
		$providers{$refreshItem}->(undef, $client, $refreshItem);
	}
	else {  #DONE
		if ($newActiveGames == 1) {
			$activeGames = 1;
		}
	
		$log->info("Drawing screens...");
		$log->debug("Start time:" . Time::HiRes::time());
		
		@WETdisplayItems1 = @WETdisplayItems1temp;
		@WETdisplayItems2 = @WETdisplayItems2temp;
		getLongWeather(); # Long weather text retrieved.  Setup displays and make available to Custom Clock
		
		#Clear the long weather temp variables for the next update
		@WETdisplayItems1temp = ();
		@WETdisplayItems2temp = ();

		#Refresh complete so it's safe to draw/cache icons for each up/down mode
		
		my @players = Slim::Player::Client::clients();

		#Determine time to wait between each screen drawing
		$drawEachPendingDelay = $prefs->get('drawEachDelay');
		$log->debug("drawEachPendingDelay = $drawEachPendingDelay");
		
		#Stagger the screen drawing timers so they're not blocking to other nonSDT processing
		my $cumTime = Time::HiRes::time() + .03;

		for my $player (@players) {
			#Draw default modes
			#Current 0
			$drawEachPending++;
			Slim::Utils::Timers::setTimer(undef, $cumTime, \&drawEach, $player, -1, 0);
			$cumTime = $cumTime + $drawEachPendingDelay;
			#Default 1
			$drawEachPending++;
			Slim::Utils::Timers::setTimer(undef, $cumTime, \&drawEach, $player, 0, 0);
			$cumTime = $cumTime + $drawEachPendingDelay;
			#Default 2
			$drawEachPending++;
			Slim::Utils::Timers::setTimer(undef, $cumTime, \&drawEach, $player, 1, 0);
			$cumTime = $cumTime + $drawEachPendingDelay;
			#Default 3
			$drawEachPending++;
			Slim::Utils::Timers::setTimer(undef, $cumTime, \&drawEach, $player, 2, 0);
			$cumTime = $cumTime + $drawEachPendingDelay;
		
			#Draw custom modes
			my @d1period = @{ $prefs->client($player)->get('v1period') || [] };

			for(my $i=2; $i < scalar @d1period; $i++) {
				$drawEachPending++;
				Slim::Utils::Timers::setTimer(undef, $cumTime, \&drawEach, $player, $d1period[$i], $i);
				$cumTime = $cumTime + $drawEachPendingDelay;
			}       
		
			#Draw 10 Day Forecasts for each player
			#Make sure we have a value in case player settings have never been set

			if ($prefs->client($player)->get('fdays') eq '') {
				$prefs->client($player)->set('fdays', 3);
			}

			for (my $i=1; $i <= $prefs->client($player)->get('fdays')+1; $i++) {
				$drawEachPending++;
				Slim::Utils::Timers::setTimer(undef, $cumTime, \&drawEach, $player, 'd'.$i, 1);
				$cumTime = $cumTime + $drawEachPendingDelay;
			}
		}
	}
}

#Called when no more icons need to be drawn
sub doneDrawing {
	my $client = shift;
	
	$log->info("Done drawing screens.");
	
	$log->debug("Finish time:" . Time::HiRes::time());      

	#Icons have been drawn, replace old display data with fresh data
	%displayInfo = %displayInfoBuild;
	%displayInfoBuild = (); #Done building, no longer needed
	
	#Make non sports/stock line data available via external API
	
	my $total = 0;

	if  ($displayInfo{'cycleOrigin'}) { 
		$total = scalar @{$displayInfo{'cycleOrigin'}};
	}
	
	for(my $counter=0; $counter < $total; $counter++) {
		if (!($displayInfo{'cycleOrigin'}[$counter] =~ /getMLB|getNFL|getNBA|getWNBA|getNHL|getCBB|getCFB|getSoccer|getStocks|getLongWeather/)) {
			$miscData{$displayInfo{'cycleOrigin'}[$counter]}{$counter}{'line1'} = $displayInfo{'cycleItems1'}[$counter];
			$miscData{$displayInfo{'cycleOrigin'}[$counter]}{$counter}{'line2'} = $displayInfo{'cycleItems2'}[$counter];
			
			#Differentiate between long and short text
			if ($displayInfo{'cycleInts'}[$counter] eq 'L') {
				$miscData{$displayInfo{'cycleOrigin'}[$counter]}{$counter}{'type'} = 'long';
			}
			else {
				$miscData{$displayInfo{'cycleOrigin'}[$counter]}{$counter}{'type'} = 'short';
			}
		}
	}
		
	if ($status eq '*') {
		$log->info("Data refresh completed.");
		
		my $data = {
			'state' => 'Success'
		};
		Slim::Control::Request::notifyFromArray(undef,['SuperDateTimeState','dataRefreshState',$data]);

		$status = '';
	}
	else {
		$log->warn("Data refresh completed with errors.");
		my $data = {
			'state' => 'Errors'
		};
		Slim::Control::Request::notifyFromArray(undef,['SuperDateTimeState','dataRefreshState',$data]);
	}

	$activeGames = $newActiveGames;
	$log->debug("Active games? ". $activeGames);

	Slim::Utils::Timers::killTimers(undef, \&stuckMonitor); #Kill stuck monitor as plugin made it through the refresh
	Slim::Utils::Timers::killTimers(undef, \&refreshData); #Paranoia check
	if ($activeGames > 0) {
		Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + ($prefs->get('arefresh') * 60), \&refreshData, $client, -1); #Set up next refresh timer
	}
	else {
		Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + ($prefs->get('refresh') * 60), \&refreshData, $client, -1); #Set up next refresh timer
	}
}

sub stuckMonitor {
    my $timerObj = shift; #Should be undef
    my $client = shift;
    
    $log->warn("Plugin appears to be stuck.  Forcing refresh...");
    Slim::Utils::Timers::killTimers(undef, \&refreshData); #Paranoia check
    Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 3, \&refreshData, $client, -1); #Set up next refresh timer   
}

sub getMLB {  #Set up Async HTTP request for MLB
    my $timerObj = shift; #Should be undef
    my $client = shift;
    my $refreshItem = shift;

    my ($mday,$mon,$year,$hour, $isdst) = (gmtime(time-(60*60*8)))[3,4,5,2,8];  # Roll over date embedded in URL at 1AM Pacific instead of 12AM Eastern
    $mday = sprintf("%02d",$mday);
    $mon = sprintf("%02d",$mon+1);
    $year = $year+1900;
	
########## Test other game dates ##########
	# $mday = '28';
	# $mon = '03';
	# $year = '2024';
###########################################

    
    if (scalar(@MLBteams)>0 && $mon <12 && $mon >1) { # Make sure a baseball team is chosen and it is baseball season
        my $url = 'https://statsapi.mlb.com/api/v1/schedule?sportId=1,51&date='.$year.'-'.$mon.'-'.$mday.'&hydrate=team,linescore';
    
        my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotMLB,
                                  \&gotErrorViaHTTP,
                                  {caller => 'getMLB',
                                    callerProc => \&getMLB,                               
                                   client => $client,
                                   refreshItem => $refreshItem});                             
        
        $log->debug("async request: $url");
        $http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
    }
    else {
        $log->info("Skipping MLB...");
        if (scalar(@MLBteams)>0) {
            saveCycles('getMLB');
        }
        else {
            delete $sportsData{'MLB'};
        }
        refreshData(undef, $client, $refreshItem);
    }
}

sub gotMLB {
    my $http = shift;
    
    my $params = $http->params();
    my $client = $params->{'client'};
    my $refreshItem = $params->{'refreshItem'};

    delete $sportsData{'MLB'};
    $sportsData{'MLB'}{'logoURL'} = 'plugins/SuperDateTime/html/images/MLB.png';

    $log->info("got " . $http->url());
    
    my $MLB_json = $http->content();
    my $perldata = eval{decode_json($MLB_json)};
	if ($@) {
		$log->error("Error detected in MLB JSON. Error: ".$@);
		$log->error("Skipping MLB");
		refreshData(undef, $client, $refreshItem);
		return;
	}
    my $isDST = (localtime(time))[8]; # used for conversion from UTC to Eastern time zone.
	my $totalGames = $perldata->{'totalGames'};
    
	if ($totalGames > 0) { # Check to see if there are any games.
        $log->debug("One or more games today");
        my $dates_array = $perldata->{'dates'};
        my $dates = @$dates_array[0];
        my $games_array = $dates->{'games'}; # Store the ARRAY of games or HASH for single game.
        if (ref($games_array) eq 'ARRAY') { # expecting array 
            $refreshTracker[0] = 0;
            my $game_count = scalar(@$games_array); # How many games today?
            my $game_num = 0;
            $log->debug("Game count: " . $game_count);
            while ($game_num < $game_count) {
                my $game = @$games_array[$game_num]; #split array into individual games
                my $game_stat = $game->{'status'}->{'detailedState'}; #Pregame, Preview, In Progress, Game Over, Delayed?, Postponed? 
                my $game_time = $game->{'gameDate'}; # UTC start time 
                my $inning = $game->{'linescore'}->{'currentInning'}; # Inning#
                my $inning_st = $game->{'linescore'}->{'inningState'}; # Top, Middle,Bottom, End
                my $away_team = $game->{'teams'}->{'away'}->{'team'}->{'teamName'};
                my $home_team = $game->{'teams'}->{'home'}->{'team'}->{'teamName'};
                my $away_score = $game->{'teams'}->{'away'}->{'score'};
                my $home_score = $game->{'teams'}->{'home'}->{'score'};
                my $clock_time = $game_time;
				
				# Calculate Eastern Start Time from UTC time
				my $StartHr = '';
				my $StartMin = '';
				my $AmPm = 'AM';
				if ($game_time =~ /.+T(\d+)\:(\d+).+/) { # Extract hours and minutes from UTC time
					$StartHr = $1;
					$StartMin = $2;
					if ($isDST) {
						$StartHr = $StartHr - 4;# convert to Eastern time
					}
					else {
						$StartHr = $StartHr - 5;
					}
					if ($StartHr < 0) {         # check for crossing to previous day
						$StartHr = $StartHr + 24;
					}
					if ($StartHr > 12) {        # convert to 12 Hr format
						$StartHr = $StartHr - 12;
						$AmPm = 'PM';
					}
					elsif ($StartHr == 0) {     # Midnight
						$StartHr = $StartHr + 12
					}
					$clock_time = $StartHr . ":" . $StartMin . ' ' . $AmPm;
				}

				my $Cclock_time = convertTime($clock_time);
			
				if ($game_stat eq 'In Progress') { # active games
					$clock_time = $inning_st." ".$inning; 
				}
				elsif ($game_stat eq 'Game Over' or $game_stat =~ /Final/ or $game_stat =~ /Completed Early/){ # completed games
					if ($inning ne 9) {
						$clock_time = 'Final '. $inning; 
					}
					else {
						$clock_time = 'Final'; 
					}
				}
				elsif ($game_stat =~ /Delayed Start/ or $game_stat =~ /Postponed/) { 
					$clock_time = $game_stat;
					$home_score = '';
					$away_score = '';
				}
				elsif ($game_stat =~ /Delayed/ or $game_stat =~ /Suspended/) { # Delayed or suspended game
					$clock_time = $game_stat.' '.$inning;
				}
				else { # upcoming games  
					$home_score = '';
					$away_score = '';
				}

				$Cclock_time = convertTime($clock_time);

				my $sport = "MLB";
				my $MLBICONmap = '';
				my $home_logo = $MLBICONmap{$home_team};
				my $away_logo = $MLBICONmap{$away_team};
				my $home_logoURL = "http://a.espncdn.com/combiner/i?img=/i/teamlogos/mlb/500/scoreboard/".$home_logo.".png";
				my $away_logoURL = "http://a.espncdn.com/combiner/i?img=/i/teamlogos/mlb/500/scoreboard/".$away_logo.".png";
				my $home_logoF = $imagePath."MLB/".$home_logo.".png";
				my $away_logoF = $imagePath."MLB/".$away_logo.".png";
				$home_logo = "plugins/SuperDateTime/html/images/MLB/".$home_logo.".png";
				$away_logo = "plugins/SuperDateTime/html/images/MLB/".$away_logo.".png";
				&storeLOGO($sport,$home_team,$home_logoURL,$home_logoF,$away_team,$away_logoURL,$away_logoF);
 
				$log->debug("Game# " . $game_num);
				$log->debug("Status: " . $game_stat);
				$log->debug("Teams: " . $away_team . " @ " . $home_team);
				$log->debug("Inning: " . $inning);
				$log->debug("Inning Part: " . $inning_st);
				$log->debug("Raw Clock: " . $clock_time);
				$log->debug("Converted Clock: " . $Cclock_time);
				$log->debug("Score: " . $away_score . " - " . $home_score);
				$log->debug("Away Logo URL: " . $away_logoURL);
				$log->debug("Away Logo File: " . $away_logoF);
				$log->debug("Away Logo: " . $away_logo);
				$log->debug("Home Logo URL: " . $home_logoURL);
				$log->debug("Home Logo File: " . $home_logoF);
				$log->debug("Home Logo: " . $home_logo);
				$log->debug(" ");
			   
				$sportsData{'MLB'}{$home_team.$game_num}{'gameTime'} = convertTime($clock_time);
				$sportsData{'MLB'}{$home_team.$game_num}{'homeTeamCK'} = $home_team;
				$sportsData{'MLB'}{$home_team.$game_num}{'awayTeamCK'} = $away_team;
				$sportsData{'MLB'}{$home_team.$game_num}{'homeTeam'} = shortenMLB($home_team);
				$sportsData{'MLB'}{$home_team.$game_num}{'awayTeam'} = shortenMLB($away_team);
				$sportsData{'MLB'}{$home_team.$game_num}{'homeScore'} = $home_score;
				$sportsData{'MLB'}{$home_team.$game_num}{'awayScore'} = $away_score;
				$sportsData{'MLB'}{$home_team.$game_num}{'homeLogoURL'} = $home_logo;
				$sportsData{'MLB'}{$home_team.$game_num}{'awayLogoURL'} = $away_logo;
				$sportsData{'MLB'}{$home_team.$game_num}{'gameLogoURL'} = $home_logo;

				if ((teamCheck($home_team,\@MLBteams)==1) || (teamCheck($away_team,\@MLBteams)==1)) {
					displayLines($client, $clock_time, $away_team, $home_team, $away_score, $home_score, 'MLB', 'getMLB', \&shortenMLB, \%MLBmap);
				}
				$game_num++;
			}
		}
		else {
			$status = '-';
			$log->warn("Error parsing MLB data.");
		}
	}
	else {
		$log->debug("No games today");
		$refreshTracker[0] = 0;
	}
	refreshData(undef, $client, $refreshItem);  
}

sub registerProvider {
    my $subRef = shift;
    
    my $size = (scalar keys %providers) + 1;
    
    $providers{$size} = $subRef;
}

sub addDisplayItem {
    my ($origin, $item1, $item2, $int, $expires, $time) = @_;
    
    if (!defined $expires) {
        $expires = 0;
    }

    if (!defined $time) {
        $time = Time::HiRes::time();
    }
    
    push(@{$displayInfoBuild{'cycleOrigin'}}, $origin);
    push(@{$displayInfoBuild{'cycleItems1'}}, $item1);
    push(@{$displayInfoBuild{'cycleItems2'}}, $item2);  
    push(@{$displayInfoBuild{'cycleInts'}}, $int);
    push(@{$displayInfoBuild{'cycleTimeAdded'}}, $time);
    push(@{$displayInfoBuild{'cycleTimeExpires'}}, $expires);
}

#Allows plugins to add their own % macro replacement value
sub addMacro {
    my ($macro, $value) = @_;
    $macroHash{$macro} = $value;
}

#Preserves previous display info for a given source.  Optionally a time can be specified which will be compared against the 
#cycleTimeAdded value.either before (b) or after (a) based on $ba argument.
sub saveCycles {
    my ($origin, $time, $ba) = @_;

    $log->debug("Preserving previous $origin info... $ba $time");
    
    if (exists $displayInfo{'cycleOrigin'}) {
        my $total = scalar @{$displayInfo{'cycleOrigin'}};
        for(my $counter=0; $counter < $total; $counter++) {
            if ($displayInfo{'cycleOrigin'}[$counter] eq $origin) {
                if (defined $time) {
                    if ($ba eq 'b' && $displayInfo{'cycleTimeAdded'}[$counter] < $time) {
                        addDisplayItem($origin, $displayInfo{'cycleItems1'}[$counter], $displayInfo{'cycleItems2'}[$counter], $displayInfo{'cycleInts'}[$counter], $displayInfo{'cycleTimeExpires'}[$counter], $displayInfo{'cycleTimeAdded'}[$counter]);
                    }
                    elsif ($ba eq 'a' && $displayInfo{'cycleTimeAdded'}[$counter] > $time) {
                        addDisplayItem($origin, $displayInfo{'cycleItems1'}[$counter], $displayInfo{'cycleItems2'}[$counter], $displayInfo{'cycleInts'}[$counter], $displayInfo{'cycleTimeExpires'}[$counter], $displayInfo{'cycleTimeAdded'}[$counter]);
                    }
                }
                else {
                    addDisplayItem($origin, $displayInfo{'cycleItems1'}[$counter], $displayInfo{'cycleItems2'}[$counter], $displayInfo{'cycleInts'}[$counter], $displayInfo{'cycleTimeExpires'}[$counter], $displayInfo{'cycleTimeAdded'}[$counter]);
                }
            }
        }
    }           
}

#Preserves non-expired display info for a given source
sub processExpired {
    my $origin = shift;
    
    my $time = Time::HiRes::time();

    $log->debug("Preserving non-expired $origin info...");
    
    my $total = scalar @{$displayInfo{'cycleOrigin'}};
    for(my $counter=0; $counter < $total; $counter++) {
        if (($displayInfo{'cycleOrigin'}[$counter] eq $origin) && $displayInfo{'cycleTimeExpires'}[$counter] > $time) {
            addDisplayItem($origin, $displayInfo{'cycleItems1'}[$counter], $displayInfo{'cycleItems2'}[$counter], $displayInfo{'cycleInts'}[$counter], $displayInfo{'cycleTimeExpires'}[$counter], $displayInfo{'cycleTimeAdded'}[$counter]);
        }
    }
}

sub teamCheck {
	my $teamToCheck  = shift;
	my $teamArrayRef = shift;

	#Get rid of any ranking, if present (college).
	if ($teamToCheck =~ /(\(\d+\)) (.+)/) {
		$teamToCheck = $2;
	}

	$log->debug("Made it to teamcheck");
	$log->debug($teamToCheck);

	my $endingValue = scalar(@$teamArrayRef);

	for(my $counter=0; $counter < $endingValue; $counter++)
	{
		$log->debug("Made it to teamcheck - team loop");
		$log->debug(@$teamArrayRef[$counter]);
		if (($teamToCheck eq @$teamArrayRef[$counter]) || (@$teamArrayRef[$counter] eq '1') || (@$teamArrayRef[$counter] eq 'All') || (@$teamArrayRef[$counter] eq 'all')) {
			$log->debug("Match on team - return 1");
			return 1;
		}
	}
	return 0;
}

sub displayLines {
	#Figure out/Format display lines
	my ($client, $gametime, $team1, $team2, $score1, $score2, $topline, $origin, $shortenRef, $iconHashRef) = @_;
	
	$gametime = convertTime($gametime);  #Clean up time display and convert to local time zone

	my $logoteam1 = '';
	my $logoteam2 = '';
	
	if ($origin == 'gotSoccer' || $origin == 'gotWNBA') {
		$logoteam1 = $team1;
		$logoteam2 = $team2;
	}
	else {
		if ($prefs->get('teamlogos') == 0 || !defined $iconHashRef) { #No logos
			$logoteam1 = $shortenRef->($team1);
			$logoteam2 = $shortenRef->($team2) 
		}
		elsif ($prefs->get('teamlogos') == 1) { #Logo no text
			if (defined $iconHashRef->{$team1}) { #Are there logos for team1?
				$logoteam1 = $client->symbols("$origin-".$iconHashRef->{$team1});
			}
			else { #No logo available
				$logoteam1 = $shortenRef->($team1);
			}
				
			if (defined $iconHashRef->{$team2}) { #Are there logos for team2
				$logoteam2 = $client->symbols("$origin-".$iconHashRef->{$team2});
			}
			else { #No logo available
				$logoteam2 = $shortenRef->($team2);
			}       
		}
		else { #Logo and text
			if (defined $iconHashRef->{$team1}) { #Are there logos for team1?
				$logoteam1 = $client->symbols("$origin-".$iconHashRef->{$team1});
			}
				
			if (defined $iconHashRef->{$team2}) { #Are there logos for team2
				$logoteam2 = $client->symbols("$origin-".$iconHashRef->{$team2});
			}   
			
			$logoteam1 = $logoteam1 . $shortenRef->($team1);
			$logoteam2 = $logoteam2 . $shortenRef->($team2);
		}
	}
			
	if (($gametime =~ m/^F/ or $gametime =~ m/^P/ or $gametime =~ m/^S/) && $showgame>0) {  #Finished game
		$log->debug('This game is finished: '.$team1.' @ '.$team2);
		addDisplayItem($origin, $topline, $logoteam1 . ' ' . $score1 . ' @ ' . $logoteam2 . ' ' . $score2 . ' - ' . $gametime, $showgame);      
	}
	elsif ($score1 eq '' && $showgame>0) {  #upcoming game
		if ($origin eq 'getMLB') {
			$refreshTracker[0] = 1;
		}
		elsif ($origin eq 'getNBA') {
			$refreshTracker[1] = 1;
		}
		# elsif ($origin eq 'getWNBA') {
			# $refreshTracker[3] = 1;
		# }
		elsif ($origin eq 'getNHL') {
			$refreshTracker[2] = 1;
		}
		$log->debug('This game is upcoming: '.$team1.' @ '.$team2);
		addDisplayItem($origin, $topline, $logoteam1 . ' @ ' . $logoteam2 . '-' . $gametime, $showgame);
	}
	elsif ($gametime ne 'F' && $showactivegame >0 && $score1 ne '') { #active game
		if ($origin eq 'getMLB') {
			$refreshTracker[0] = 1;
		}
		elsif ($origin eq 'getNBA') {
			$refreshTracker[1] = 1;
		}
		# elsif ($origin eq 'getWNBA') {
			# $refreshTracker[3] = 1;
		# }
		elsif ($origin eq 'getNHL') {
			$refreshTracker[2] = 1;
		}       
		$log->debug('This game is active: '.$team1.' @ '.$team2);
		$newActiveGames = 1;
		addDisplayItem($origin, $topline, $logoteam1 . ' ' . $score1 . ' @ ' . $logoteam2 . ' ' . $score2 . ' - ' . $gametime, $showactivegame);
	}
	else {
		$log->error('UH OH! This game status is unknown: '.$team1.' @ '.$team2);
	}
}

sub getNBA {  #Set up Async HTTP request for NBA
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;

	$log->debug("# NBA Teams Selected = ".scalar(@NBAteams)." Refresh NBA? ".$refreshTracker[1]);

	if (scalar(@NBAteams) > 0) { #Make sure a basketball team is chosen

		my $url = 'https://nba-prod-us-east-1-mediaops-stats.s3.amazonaws.com/NBA/liveData/scoreboard/todaysScoreboard_00.json';
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotNBA,
												\&gotErrorViaHTTP,
												{caller => 'getNBA',
												callerProc => \&getNBA,                                                       
												client => $client,
												refreshItem => $refreshItem});

		$log->debug("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	else {
		$log->info("Skipping NBA...");
		if (scalar(@NBAteams)>0) {
			saveCycles('getNBA');
		}
		else {
			delete $sportsData{'NBA'};
		}
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotNBA {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	delete $sportsData{'NBA'};
	$sportsData{'NBA'}{'logoURL'} = 'plugins/SuperDateTime/html/images/nba.png';

	$refreshTracker[1] = 0;
   
	$log->info("got " . $http->url());

	# Retrieve and decode NBA JSON data file
	my $NBA_json = $http->content();
	my $perldata = eval{decode_json($NBA_json)};
	if ($@) {
		$log->error("Error detected in NBA JSON. Error: ".$@);
		$log->error("Skipping NBA");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	my $games_array = $perldata->{scoreboard}->{'games'};
	my $game_count = scalar(@$games_array);
	my $game_num = 0;
	my $isDST = (localtime(time))[8];
	$log->debug("Number of games today: " . $game_count);
	
	while ($game_num < $game_count) {
		my $gameID = @$games_array[$game_num]->{'gameId'};
		my $GameStatus = @$games_array[$game_num]->{'gameStatus'};
		my $StartTime = @$games_array[$game_num]->{'gameTimeUTC'};
		my $away_team = @$games_array[$game_num]->{'awayTeam'}->{'teamTricode'};
		my $home_team = @$games_array[$game_num]->{'homeTeam'}->{'teamTricode'};
		my $away_score = @$games_array[$game_num]->{'awayTeam'}->{'score'};
		my $home_score = @$games_array[$game_num]->{'homeTeam'}->{'score'};
		my $GameStatusText = rtrim(@$games_array[$game_num]->{'gameStatusText'});
		my $game_clock = @$games_array[$game_num]->{'gameClock'};
		my $period = @$games_array[$game_num]->{'period'};
		my $tv_NatArray = @$games_array[$game_num]->{'broadcasters'}->{'nationalBroadcasters'};
		my $tv_AwayArray = @$games_array[$game_num]->{'broadcasters'}->{'awayTvBroadcasters'};
		my $tv_HomeArray = @$games_array[$game_num]->{'broadcasters'}->{'homeTvBroadcasters'};
		my $tv_network = '';
		if (@$tv_NatArray[0]) {
			$tv_network = @$tv_NatArray[0]->{'broadcastDisplay'};
			$log->debug("National TV Broadcast " . $tv_network);
		}
		elsif (@$tv_AwayArray[0]) {
			$tv_network = @$tv_AwayArray[0]->{'broadcastDisplay'};
			$log->debug("Away Team TV Broadcast " . $tv_network);
		}
		elsif (@$tv_HomeArray[0]) {
			$tv_network = @$tv_HomeArray[0]->{'broadcastDisplay'};
			$log->debug("Home Team TV Broadcast " . $tv_network);
		}
		else {
			$log->debug("NBA Game not broadcast on TV");
		}
		my $NBAteamMap = '';
		my $away_team_name = $NBAteamMap{$away_team};       # Look up long team names
		my $home_team_name = $NBAteamMap{$home_team};

		# Capture team abbreviations for team check routine before alteration.
		my $awayTeamCK = uc($away_team);
		my $homeTeamCK = uc($home_team);

		# prep team abbreviation for use in logo URLs
		if ($away_team eq 'UTA') {
			$away_team = 'utah';
		}
		if ($home_team eq 'UTA') {
			$home_team = 'utah';
		}
		if ($away_team eq 'NOP') {
			$away_team = 'no';
		}
		if ($home_team eq 'NOP') {
			$home_team = 'no';
		}
		$away_team = lc($away_team);	
		$home_team = lc($home_team);

		my $sport = "NBA";
		my $away_logoURL = 'http://a.espncdn.com/combiner/i?img=/i/teamlogos/nba/500/' . $away_team . '.png'; # Use ESPN.com logos.
		my $home_logoURL = 'http://a.espncdn.com/combiner/i?img=/i/teamlogos/nba/500/' . $home_team . '.png';      
		
		my $home_logoF = $imagePath."NBA/".$home_team.".png";
		my $away_logoF = $imagePath."NBA/".$away_team.".png";
		my $home_logo = "plugins/SuperDateTime/html/images/NBA/".$home_team.".png";
		my $away_logo = "plugins/SuperDateTime/html/images/NBA/".$away_team.".png";
		&storeLOGO($sport,$home_team_name,$home_logoURL,$home_logoF,$away_team_name,$away_logoURL,$away_logoF);

		my $period_time = '';
		$period_time = $game_clock;
		
		# Calculate Eastern Start Time 
		my $StartHr = '';
		my $StartMin = '';
		my $AmPm = 'AM';
		if ($StartTime =~ /.+T(\d+)\:(\d+).+/) { # Extract hours and minutes from UTC time
			$StartHr = $1;
			$StartMin = $2;
			if ($isDST) {
				$StartHr = $StartHr - 4;# convert to Eastern time
			}
			else {
				$StartHr = $StartHr - 5;
			}
			if ($StartHr < 0) {         # check for crossing to previous day
				$StartHr = $StartHr + 24;
			}
			if ($StartHr > 12) {        # convert to 12 Hr format
				$StartHr = $StartHr - 12;
				$AmPm = 'PM';
			}
			elsif ($StartHr == 0) {     # Midnight
				$StartHr = $StartHr + 12
			}
			$StartTime = $StartHr . ":" . $StartMin . ' ' . $AmPm;
		}
		
		$log->debug("Game # " . $game_num);
		$log->debug("GameID = " . $gameID);
		$log->debug("Game Status = " . $GameStatus . " " . $GameStatusText);
		$log->debug("Start Time: " . $StartTime);
		$log->debug("Start Hour: " . $StartHr);
		$log->debug("Start Minute: " . $StartMin);
		$log->debug("Away Team: " . $away_team);
		$log->debug("Away Score: " . $away_score);
		$log->debug("Home Team: " . $home_team);
		$log->debug("Home Score: " . $home_score);
		$log->debug("Period: " . $period);
		$log->debug("Game clock: " . $game_clock);
		$log->debug("Period time: " . $period_time);
		$log->debug("TV Network: " . $tv_network);
		$log->debug("Away Logo: " . $away_logo);
		$log->debug("Home Logo: " . $home_logo);
		

		$log->debug("Away team name: " . $away_team_name);
		if ($away_team_name eq "") {
			$away_team_name = $away_team; # Deal with exhibition games with non-NBA team.
		}
		$log->debug("Away team name: " . $away_team_name);

		$log->debug("Home team name: " . $home_team_name);
		if ($home_team_name eq "") {
			$home_team_name = $home_team; # Deal with exhibition games with non-NBA team.
		}
		$log->debug("Home team name: " . $home_team_name);
		
		if ($period eq 0 || $period eq "" || $GameStatus eq 1) { # upcoming game - blank out scores
			$log->debug("Detected Upcoming Game");
			$away_score = "";
			$home_score = "";
			$game_clock = $StartTime;
		}
		elsif ($GameStatus == 3) { # finished game
			$log->debug("Detected Finished Game");
			$game_clock = 'Final';
			if ($period > 4) { # Overtime
				if ($period > 5) { # Multiple overtime
					my $OTPeriod = $period - 4;
					$game_clock = "Final " . $OTPeriod . "OT";
					$log->debug("Period: " . $period);
					$log->debug("Detected Multiple Overtime");
					$log->debug("OT Period: " . $OTPeriod);
					$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
				else {
					$game_clock = "FINAL OT";
					$log->debug("Period: " . $period);
					$log->debug("Detected Overtime");
					$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
			}
		}
		elsif ($GameStatusText =~ m/Half/i) { 
			$log->debug("Detected Game in Halftime");
			$game_clock = "Halftime";
		}
		elsif ($GameStatusText =~ m/End/i) { 
			$log->debug("Detected Game at End of Qtr");
			$game_clock = "End " . $period;
		}
		elsif ($GameStatus == 2) { # active game
			$log->debug("Detected Active Game");
			if ($game_clock =~ m/PT(\d+)M(\d+).\d+S/) {
				$log->debug("regex positive");
				$game_clock = $1.':'.$2.' '.$period;
			}
			else {			
				$log->debug("normal game clock");
				$game_clock = rtrim($period_time).' '.$period;
			}
			if ($period > 4) { # Overtime
				if ($period > 5) { # Multiple overtime
					my $OTPeriod = $period - 4;
					$game_clock = $period_time . ' ' . $OTPeriod . "OT";
					$log->warn("Period: " . $period);
					$log->warn("Game clock: " . $game_clock);
					$log->warn("Detected Multiple Overtime");
					$log->warn($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
				else {
					$game_clock = $period_time . ' ' . "OT";
					$log->debug("Period: " . $period);
					$log->debug("Detected Overtime");
					$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
			}
		}
		else {
			$log->warn("Unknown NBA game status.");
		}
		
		my $clock_time = $game_clock;
		$log->debug("Game time: " . $clock_time);
		$log->debug("Converted Game time: " . convertTime($clock_time));
		$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($clock_time));
	
		$sportsData{'NBA'}{$home_team.$clock_time}{'homeTeamCK'} = $homeTeamCK;
		$sportsData{'NBA'}{$home_team.$clock_time}{'awayTeamCK'} = $awayTeamCK;
		$sportsData{'NBA'}{$home_team.$clock_time}{'homeTeam'} = shortenNBA($home_team_name);
		$sportsData{'NBA'}{$home_team.$clock_time}{'awayTeam'} = shortenNBA($away_team_name);
		$sportsData{'NBA'}{$home_team.$clock_time}{'awayScore'} = $away_score;
		$sportsData{'NBA'}{$home_team.$clock_time}{'homeScore'} = $home_score;
		$sportsData{'NBA'}{$home_team.$clock_time}{'gameTime'} = convertTime($clock_time);
		$sportsData{'NBA'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
		$sportsData{'NBA'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
		$sportsData{'NBA'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;
		
		if ((teamCheck($homeTeamCK,\@NBAteams)==1) || (teamCheck($awayTeamCK,\@NBAteams)==1)) {
			if ($tv_network eq '') {
				displayLines($client, $clock_time, $away_team_name, $home_team_name, $away_score, $home_score, 'NBA', 'getNBA', \&shortenNBA, undef);
			}
			else {
				displayLines($client, $clock_time, $away_team_name, $home_team_name, $away_score, $home_score, 'NBA ('.$tv_network.')', 'getNBA', \&shortenNBA, undef);
			}
		}
		
		$log->debug(" "); 
		$game_num++;
	}
	refreshData(undef, $client, $refreshItem);  
}

sub getWNBA {  #Set up Async HTTP request for WNBA
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;

	# $log->debug("# WNBA Teams Selected = ".scalar(@WNBAteams)." Refresh WNBA? ".$refreshTracker[3]);

	if (scalar(@WNBAteams) > 0) { #Make sure a basketball team is chosen
		my $url = 'https://nba-prod-us-east-1-mediaops-stats.s3.amazonaws.com/WNBA/liveData/scoreboard/todaysScoreboard_10.json';
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotWNBA,
												\&gotErrorViaHTTP,
												{caller => 'getWNBA',
												callerProc => \&getWNBA,
												client => $client,
												refreshItem => $refreshItem});

		$log->debug("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	else {
		$log->info("Skipping WNBA...");
		if (scalar(@WNBAteams)>0) {
			saveCycles('getWNBA');
		}
		else {
			delete $sportsData{'WNBA'};
		}
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotWNBA {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	delete $sportsData{'WNBA'};
	$sportsData{'WNBA'}{'logoURL'} = 'plugins/SuperDateTime/html/images/WNBA.png';

	# $refreshTracker[3] = 0;

	$log->info("got " . $http->url());

   # Retrieve and decode WNBA JSON data file
	my $WNBA_json = $http->content();
	my $perldata = eval{decode_json($WNBA_json)};
	if ($@) {
		$log->error("Error detected in WNBA JSON. Error: ".$@);
		$log->error("Skipping WNBA");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	my $games_array = $perldata->{scoreboard}->{'games'};
	my $game_count = scalar(@$games_array);
	my $game_num = 0;
	my $isDST = (localtime(time))[8];
	$log->debug("Number of games today: " . $game_count);
	
	while ($game_num < $game_count) {
		my $gameID = @$games_array[$game_num]->{'gameId'};
		my $GameStatus = @$games_array[$game_num]->{'gameStatus'};
		my $StartTime = @$games_array[$game_num]->{'gameTimeUTC'};
		my $away_team = @$games_array[$game_num]->{'awayTeam'}->{'teamTricode'};
		my $home_team = @$games_array[$game_num]->{'homeTeam'}->{'teamTricode'};
		my $away_team_name = @$games_array[$game_num]->{'awayTeam'}->{'teamName'};
		my $home_team_name = @$games_array[$game_num]->{'homeTeam'}->{'teamName'};
		my $away_team_city = @$games_array[$game_num]->{'awayTeam'}->{'teamCity'};
		my $home_team_city = @$games_array[$game_num]->{'homeTeam'}->{'teamCity'};
		my $away_score = @$games_array[$game_num]->{'awayTeam'}->{'score'};
		my $home_score = @$games_array[$game_num]->{'homeTeam'}->{'score'};
		my $GameStatusText = rtrim(@$games_array[$game_num]->{'gameStatusText'});
		my $game_clock = @$games_array[$game_num]->{'gameClock'};
		my $period = @$games_array[$game_num]->{'period'};

		$away_team_name = shortenWNBA($away_team_name, $away_team_city);
		$home_team_name = shortenWNBA($home_team_name, $home_team_city);

		# Capture team abbreviations for team check routine before alteration.
		my $awayTeamCK = uc($away_team);
		my $homeTeamCK = uc($home_team);

		# prep team abbreviation for use in logo URLs
		if ($away_team eq 'LVA') {
			$away_team = 'lv';
		}
		if ($home_team eq 'LVA') {
			$home_team = 'lv';
		}
		if ($away_team eq 'CON') {
			$away_team = 'conn';
		}
		if ($home_team eq 'CON') {
			$home_team = 'conn';
		}
		if ($away_team eq 'LAS') {
			$away_team = 'la';
		}
		if ($home_team eq 'LAS') {
			$home_team = 'la';
		}
		if ($away_team eq 'PDX') {
			$away_team = 'por';
		}
		if ($home_team eq 'PDX') {
			$home_team = 'por';
		}
		$away_team = lc($away_team);
		$home_team = lc($home_team);

		my $sport = "WNBA";
		my $away_logoURL = 'https://a1.espncdn.com/combiner/i?img=/i/teamlogos/wnba/500/' . $away_team . '.png'; # Use ESPN.com logos.
		my $home_logoURL = 'https://a1.espncdn.com/combiner/i?img=/i/teamlogos/wnba/500/' . $home_team . '.png';      
		$log->debug("Away Logo URL: " . $away_logoURL);
		$log->debug("Home Logo URL: " . $home_logoURL);
		
		my $home_logoF = $imagePath."WNBA/".$home_team.".png";
		my $away_logoF = $imagePath."WNBA/".$away_team.".png";
		my $home_logo = "plugins/SuperDateTime/html/images/WNBA/".$home_team.".png";
		my $away_logo = "plugins/SuperDateTime/html/images/WNBA/".$away_team.".png";
		&storeLOGO($sport,$home_team_name,$home_logoURL,$home_logoF,$away_team_name,$away_logoURL,$away_logoF);

		my $period_time = '';
		$period_time = $game_clock;
		
	   # Calculate Eastern Start Time 
		my $StartHr = '';
		my $StartMin = '';
		my $AmPm = 'AM';
		if ($StartTime =~ /.+T(\d+)\:(\d+).+/) { # Extract hours and minutes from UTC time
			$StartHr = $1;
			$StartMin = $2;
			if ($isDST) {
				$StartHr = $StartHr - 4;# convert to Eastern time
			}
			else {
				$StartHr = $StartHr - 5;
			}
			if ($StartHr < 0) {         # check for crossing to previous day
				$StartHr = $StartHr + 24;
			}
			if ($StartHr > 12) {        # convert to 12 Hr format
				$StartHr = $StartHr - 12;
				$AmPm = 'PM';
			}
			elsif ($StartHr == 0) {     # Midnight
				$StartHr = $StartHr + 12
			}
			$StartTime = $StartHr . ":" . $StartMin . ' ' . $AmPm;
		}
		
		$log->debug("Game # " . $game_num);
		$log->debug("GameID = " . $gameID);
		$log->debug("Game Status = " . $GameStatus . " " . $GameStatusText);
		$log->debug("Start Time: " . $StartTime);
		$log->debug("Start Hour: " . $StartHr);
		$log->debug("Start Minute: " . $StartMin);
		$log->debug("Away Team: " . $away_team);
		$log->debug("Away Team Name: " . $away_team_name);
		$log->debug("Away Team City: " . $away_team_city);
		$log->debug("Away Score: " . $away_score);
		$log->debug("Home Team: " . $home_team);
		$log->debug("Home Team Name: " . $home_team_name);
		$log->debug("Home Team City: " . $home_team_city);
		$log->debug("Home Score: " . $home_score);
		$log->debug("Period: " . $period);
		$log->debug("Game clock: " . $game_clock);
		$log->debug("Period time: " . $period_time);
		$log->debug("Away Logo: " . $away_logo);
		$log->debug("Home Logo: " . $home_logo);
		

		$log->debug("Away team name: " . $away_team_name);
		if ($away_team_name eq "") {
			$away_team_name = $away_team; # Deal with exhibition games with non-WNBA team.
		}
		$log->debug("Away team name: " . $away_team_name);

		$log->debug("Home team name: " . $home_team_name);
		if ($home_team_name eq "") {
			$home_team_name = $home_team; # Deal with exhibition games with non-WNBA team.
		}
		$log->debug("Home team name: " . $home_team_name);
		
		if ($period eq 0 || $period eq "" || $GameStatus eq 1) { # upcoming game - blank out scores
			$log->debug("Detected Upcoming Game");
			$away_score = "";
			$home_score = "";
			$game_clock = $StartTime;
		}
		elsif ($GameStatus == 3) { # finished game
			$log->debug("Detected Finished Game");
			$game_clock = 'Final';
			if ($period > 4) { # Overtime
				if ($period > 5) { # Multiple overtime
					my $OTPeriod = $period - 4;
					$game_clock = "Final " . $OTPeriod . "OT";
					$log->warn("Period: " . $period);
					$log->warn("Detected Multiple Overtime");
					$log->warn("OT Period: " . $OTPeriod);
					$log->warn($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
				else {
					$game_clock = "FINAL OT";
					$log->debug("Period: " . $period);
					$log->debug("Detected Overtime");
					$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
			}
		}
		elsif ($GameStatusText =~ m/Half/i) { 
			$log->debug("Detected Game in Halftime");
			$game_clock = "Halftime";
		}
		elsif ($GameStatusText =~ m/End/i) { 
			$log->debug("Detected Game at End of Qtr");
			$game_clock = "End " . $period;
		}
		elsif ($GameStatus == 2) { # active game
			$log->debug("Detected Active Game");
			if ($game_clock =~ m/PT(\d+)M(\d+).\d+S/) {
				$log->debug("regex positive");
				$game_clock = $1.':'.$2.' '.$period;
			}
			else {			
				$log->debug("normal game clock");
				$game_clock = rtrim($period_time).' '.$period;
			}
			if ($period > 4) { # Overtime
				if ($period > 5) { # Multiple overtime
					my $OTPeriod = $period - 4;
					$game_clock = $period_time . ' ' . $OTPeriod . "OT";
					$log->warn("Period: " . $period);
					$log->warn("Game clock: " . $game_clock);
					$log->warn("Detected Multiple Overtime");
					$log->warn($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
				else {
					$game_clock = $period_time . ' ' . "OT";
					$log->debug("Period: " . $period);
					$log->debug("Detected Overtime");
					$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($game_clock));
				}
			}
		}
		else {
			$log->warn("Unknown WNBA game status.");
		}
		
		my $clock_time = $game_clock;
		$log->debug("Game time: " . $clock_time);
		$log->debug("Converted Game time: " . convertTime($clock_time));
		$log->debug($away_team_name.' '.$away_score.' @ '.$home_team_name.' '.$home_score.' - '.convertTime($clock_time));
	
		$sportsData{'WNBA'}{$home_team.$clock_time}{'homeTeamCK'} = $homeTeamCK;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'awayTeamCK'} = $awayTeamCK;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'homeTeam'} = $home_team_name;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'awayTeam'} = $away_team_name;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'awayScore'} = $away_score;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'homeScore'} = $home_score;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'gameTime'} = convertTime($clock_time);
		$sportsData{'WNBA'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
		$sportsData{'WNBA'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;
		
		if ((teamCheck($homeTeamCK,\@WNBAteams)==1) || (teamCheck($awayTeamCK,\@WNBAteams)==1)) {
			# if ($tv_network eq '') {
				displayLines($client, $clock_time, $away_team_name, $home_team_name, $away_score, $home_score, 'WNBA', 'getWNBA', \&shortenWNBA, undef);
			# }
			# else {
				# displayLines($client, $clock_time, $away_team_name, $home_team_name, $away_score, $home_score, 'WNBA ('.$tv_network.')', 'getWNBA', \&shortenWNBA, undef);
			# }
		}
		
		$log->debug(" "); 
		$game_num++;
	}
	refreshData(undef, $client, $refreshItem);  
}

sub rtrim($) {
	my $string = shift;
	$string =~ s/\s+$//;
	return $string;
}

sub getCBB {  #Set up Async HTTP request for CBB
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;

	my ($mday,$mon,$year,$hour, $isdst, $yday) = (gmtime(time-(60*60*8)))[3,4,5,2,8,7]; # Roll over date embedded in URL at 1AM Pacific instead of 12AM Eastern
	$year = $year+1900;
	$mon = sprintf("%02d",$mon+1);
	$mday = sprintf("%02d",$mday);

######## Test other dates ########
	# $year   = '2026';   #yyyy
	# $mon    = '02';     #mm
	# $mday   = '06';     #dd
##################################

	$log->debug('Teams selected: '.scalar(@CBBteams));
	$log->debug('Refresh CBB: '.$refreshTracker[5]);
	$log->debug('CBB Game #: '.$CBB_GameNum);
	$log->debug('CBB Game Count: '.$CBB_GameCount);

	if (scalar(@CBBteams) && $refreshTracker[5] == 1) { #Make sure a college basketball team is entered
		my $url = 'https://graphite.sports.yahoo.com/v1/query/shangrila/leagueGameIdsByDate?lang=en-US&region=US&tz=America%2FNew_York&ysp_platform=next-app-sports&leagues=ncaab&dates='.$year.'-'.$mon.'-'.$mday;
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotCBBgameIDs,
													\&gotErrorViaHTTP,
													{caller => 'getCBB',
													callerProc => \&getCBB,
													client => $client,
													refreshItem => $refreshItem});

		$log->info("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	elsif ((scalar(@CBBteams)) && ($CBB_GameNum < $CBB_GameCount)) { #Make sure a college basketball team is entered
		my $gameID = @CBB_Game_IDs[$CBB_GameNum];
		my $url = 'https://graphite.sports.yahoo.com/v1/query/shangrila/scoreboardGame?lang=en-US&region=US&tz=America%2FNew_York&ysp_platform=next-app-sports&gameId='.$gameID.'&statLeaderCount=3&singleStatLeader=false';
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotCBB,
													\&gotErrorViaHTTP,
													{caller => 'getCBB',
													callerProc => \&getCBB,
													client => $client,
													refreshItem => $refreshItem});
	
		$log->debug("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	elsif ((scalar(@CBBteams)) && ($CBB_GameNum == $CBB_GameCount)) { #Reset for next data refresh cycle.
		$log->debug("Made it to max CBB game #");
		@CBB_Game_IDs = ();
		$CBB_GameCount = 0;
		$CBB_GameNum = 0;
		$refreshTracker[5] = 1;
		refreshData(undef, $client, $refreshItem); 
	}
	else {
		$log->info("Skipping CBB...");
		if (scalar(@CBBteams)>0) {
			saveCycles('getCBB');
		}
		else {
			delete $sportsData{'College Basketball'};
			@CBB_Game_IDs = ();
			$CBB_GameCount = 0;
			$CBB_GameNum = 0;
		}
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotCBBgameIDs {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};
   
	delete $sportsData{'College Basketball'};
	@CBB_Game_IDs = ();
	$CBB_GameCount = 0;
	$CBB_GameNum = 0;

	$sportsData{'College Basketball'}{'logoURL'} = 'plugins/SuperDateTime/html/images/NCAAB.png';
	
	$log->debug("got " . $http->url());
	my $CBB_json = $http->content();

	my $perldata = eval{decode_json($CBB_json)};
	if ($@) {
		$log->error("Error detected in College Basketball JSON. Error: ".$@);
		$log->error("Skipping College Basketball");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	my $gamedata = $perldata->{data}->{leagues}[0]->{games};
	my $game_count = scalar(@$gamedata);
	$log->debug("CBB Game count: " . $game_count);
	my $game_num = 0;

	while ($game_num < $game_count) {
		@CBB_Game_IDs[$game_num] = @$gamedata[$game_num]->{gameId};
		$log->debug("Game# ".$game_num." ID = " . @CBB_Game_IDs[$game_num]);
		$game_num++
	}
	$CBB_GameCount = scalar(@CBB_Game_IDs);
	$log->info("# of CBB Game IDs stored: " . $CBB_GameCount);
	
	# Now go back to getCBB to retrieve JSON for each game and proceed to gotCBB for each game.
	$refreshTracker[5] = 0;
	$CBB_GameNum = 0;
	getCBB(undef, $client, $refreshItem);
}

sub gotCBB {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	$log->debug("got " . $http->url());
	my $CBB_json = $http->content();

	my $perldata = eval{decode_json($CBB_json)};
	if ($@) {
		$log->error("Error detected in College Basketball JSON. Error: ".$@);
		$log->error("Skipping College Basketball");
		refreshData(undef, $client, $refreshItem);
		return;
	}

	my $sport = "NCAA"; # Used to store logo images locally
	my $gamedata = $perldata->{data}->{games}[0];

	if ($CBB_GameNum < $CBB_GameCount) {
		my $gameId = $gamedata->{gameId}; 
		my $gamedate = substr($gamedata->{'startDate'},0,10); #extract date of game
		my $game_stat = $gamedata->{'status'};
		my $game_status = $gamedata->{'statusDisplayName'};
		my $game_time = $gamedata->{'startTime'};
		my $clock_time = $gamedata->{'timeLeft'};
		my $start_time = C24to12(substr($game_time,11,5));
		my $period = $gamedata->{'currentPeriod'}->{'shortDisplayName'};
		my $away_team_id = $gamedata->{'awayTeamId'};
		my $home_team_id = $gamedata->{'homeTeamId'};
		my $away_team = $gamedata->{'awayTeam'}->{'abbreviation'};
		my $home_team = $gamedata->{'homeTeam'}->{'abbreviation'};
		$home_team =~ s/ /_/g;
		$away_team =~ s/ /_/g;
		$home_team =~ s/&/_/g;
		$away_team =~ s/&/_/g;
		my $away_team_disp = $gamedata->{'awayTeam'}->{'displayName'};
		my $home_team_disp = $gamedata->{'homeTeam'}->{'displayName'};
		my $away_team_name = $gamedata->{'awayTeam'}->{'fullName'};
		my $home_team_name = $gamedata->{'homeTeam'}->{'fullName'};
		my $away_team_nick = $gamedata->{'awayTeam'}->{'nickname'};
		my $home_team_nick = $gamedata->{'homeTeam'}->{'nickname'};
		my $away_score = $gamedata->{'awayScore'};
		my $home_score = $gamedata->{'homeScore'};
		my $away_logoURL = $gamedata->{'awayTeam'}->{'teamLogo'}->{'url'};
		my $away_logoURL_begin = index($away_logoURL,'https://s.yimg.com/cv/apiv2/');
		my $away_logoURL_end = index($away_logoURL,'.cf.webp');
		my $away_logoURL_len = $away_logoURL_end - $away_logoURL_begin;
		my $away_logoURL = substr($away_logoURL,$away_logoURL_begin,$away_logoURL_len);
		my $home_logoURL = $gamedata->{'homeTeam'}->{'teamLogo'}->{'url'};
		my $home_logoURL_begin = index($home_logoURL,'https://s.yimg.com/cv/apiv2/');
		my $home_logoURL_end = index($home_logoURL,'.cf.webp');
		my $home_logoURL_len = $home_logoURL_end - $home_logoURL_begin;
		my $home_logoURL = substr($home_logoURL,$home_logoURL_begin,$home_logoURL_len);
		my $home_logoF = $imagePath."NCAA/".$home_team.".png";
		my $away_logoF = $imagePath."NCAA/".$away_team.".png";
		my $home_logo = "plugins/SuperDateTime/html/images/NCAA/".$home_team.".png";
		my $away_logo = "plugins/SuperDateTime/html/images/NCAA/".$away_team.".png";
		&storeLOGO($sport,$home_team,$home_logoURL,$home_logoF,$away_team,$away_logoURL,$away_logoF);
		$log->debug("Game#: ", $CBB_GameNum);
		$log->debug("GameID: ", $gameId);
		$log->debug("Gamedate: ", $gamedate);
		$log->debug("Game Stat: ", $game_stat);
		$log->debug("Game Status: ", $game_status);
		$log->debug("Game Time: ", $game_time);
		$log->debug("Clock Time: ", $clock_time);
		$log->debug("Period: ", $period);
		$log->debug("Away Team ID: ", $away_team_id);
		$log->debug("Away Team Abbr: ", $away_team);
		$log->debug("Away Team Display Name: ", $away_team_disp);
		$log->debug("Away Team Name: ", $away_team_name);
		$log->debug("Away Team Nick Name: ", $away_team_nick);
		$log->debug("Home Team ID: ", $home_team_id);
		$log->debug("Home Team Abbr: ", $home_team);
		$log->debug("Home Team Display Name: ", $home_team_disp);
		$log->debug("Home Team Name: ", $home_team_name);
		$log->debug("Home Team Nick Name: ", $home_team_nick);
		$log->debug("Away Team Logo: ", $away_logoURL);
		$log->debug("Home Team Logo: ", $home_logoURL);
		$log->debug("Away Score: ", $away_score);
		$log->debug("Home Score: ", $home_score);

		if ($game_stat eq "IN_PROGRESS") { #Active games
			$log->debug("Active game");
			if ($period =~/OT/i) {
				$log->debug("Overtime");
				$log->debug('Game Status: ' . $game_stat);
				$log->debug('Period: ' . $period);
				$log->debug('Clock Time: ' . $clock_time);
				$clock_time = $clock_time.'/'.$period;
				$log->debug($start_time. "- ". $away_team_name. " ". $away_score. " @ ". $home_team_name. " ". $home_score. " - ". convertTime($clock_time));
			}
			elsif ($game_status eq "Half") { #Halftime - Gametime = Halftime
				$log->debug("Halftime");
				$clock_time = "Halftime";
			}
			elsif ($period =~ m/(\d)/) { 
				$log->debug("Period # Detected: ".$period);
				my $Period = $1;
				$clock_time = $clock_time.'/'.$Period;
				if ($period =~ /end/i) {
					$log->debug("End Detected");
					$clock_time = 'End '.$Period;
				}
			}
		}
		elsif ($game_stat =~ /FINAL/i){ #Finished
			$log->debug("Finished game");
			$clock_time = "Final";
			if ($period =~/OT/i) { # Either OT or number in Final Message = Overtime
				$log->debug('Game Status: ' . $game_status);
				$log->debug('Period: ' . $period);
				$log->debug('Clock Time: ' . $clock_time);
				$log->debug('Final Message: ' . $game_time);
				$clock_time = $game_status;
			}
			$log->debug($start_time. "- ". $away_team_name. " ". $away_score. " @ ". $home_team_name. " ". $home_score. " - ". convertTime($clock_time));
		}
		elsif ($game_stat =~/PREGAME/i) {	# Upcoming games - Blank out scores, Gametime = Startime
			$log->debug("Upcoming game");
			$away_score = '';
			$home_score = '';
			$clock_time = $start_time;
		}
		elsif ($game_stat =~/cancel/i) {  
			$log->debug("Canceled game");
			$away_score = '';
			$home_score = '';
			$clock_time = 'Canceled';
		}
		elsif ($game_stat =~/delay/i) {	
			$log->debug("Game delayed");
			$clock_time = 'Delayed';
		}
		elsif ($game_stat =~/postponed/i) {  
			$log->debug("Game postponed");
			$clock_time = 'Postponed';
		}
		else { # Not sure... Setup as upcoming game - Blank out scores, Gametime = Startime
			$log->warn("Uncertain CBB game status");
			$away_score = '';
			$home_score = '';
			$clock_time = $start_time;
			$log->warn('Start Time: ' . $start_time);
			$log->warn('Game Status: ' . $game_stat);
			$log->warn('Period: ' . $period);
			$log->warn('Clock Time: ' . $clock_time);
			$log->warn($start_time. "- ". $away_team_name. " ". $away_score. " @ ". $home_team_name. " ". $home_score. " - ". convertTime($clock_time));
			$log->warn($away_team_name. " iconURL = ". $away_logo);
			$log->warn($home_team_name. " iconURL = ". $home_logo);
		}

		$log->debug("Clock time: ".$clock_time);
		$log->debug($away_team_name. " ". $away_score. " @ ". $home_team_name. " ". $home_score. " - ". convertTime($clock_time));

		$sportsData{'College Basketball'}{$home_team.$clock_time}{'homeTeamCK'} = $home_team_disp;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'awayTeamCK'} = $away_team_disp;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'homeTeam'} = shortenCBB($home_team_disp);
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'awayTeam'} = shortenCBB($away_team_disp);
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'homeScore'} = $home_score;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'awayScore'} = $away_score;
		$sportsData{'College Basketball'}{$home_team.$clock_time}{'gameTime'}  =convertTime($clock_time);
	
		if ((teamCheck($home_team_disp,\@CBBteams)==1) || (teamCheck($away_team_disp,\@CBBteams)==1)) {
			displayLines($client, $clock_time, $away_team_disp, $home_team_disp, $away_score, $home_score, 'NCAA Basketball', 'getCBB', \&shortenCBB, undef);
		}
		$CBB_GameNum++;
		getCBB(undef, $client, $refreshItem);
	}
	else {
		$log->debug("Made it to max CBB game #");
		$CBB_GameCount = 0;
		$refreshTracker[5] = 1;
		refreshData(undef, $client, $refreshItem);  
	}
}

sub getCFB {  #Set up Async HTTP request for college football
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;
	
	my @dateArray = gmtime(time-(60*60*8)); #Use 1AM Pacific when determining date.  This allows late games to finish before rolling to new date.

	my $mon = $dateArray[4];
	my $year = $dateArray[5];
	my $mday =$dateArray[3];
	$year = $year + 1900;
	$mon = sprintf("%02d",$mon+1);
	$mday = sprintf("%02d",$mday);

	# Calculate Season
	my $season = $year;
	if ($mon < 3) {
		$season--
	}

	# Calculate start of season
	# Starting day of the season. Each week of the CFB season runs from Tuesday through Monday. Starting with the Tuesday preceding the first Monday of September.
	my $AdjustDays; # Used to store the number of days to subtract from the 7th to find the 1st Monday.
	my $StartDate = timelocal(00,00,12,7,8,$season); #Start with the 7th of September in the season year.
	my $dow = (localtime($StartDate))[6]; # Figure out which day of the week it is.
	if ($dow>0) {  
		$AdjustDays = $dow-1;
	}
	else {
		$AdjustDays = 6;
	}
	my $FirstMonday = ($StartDate - ($AdjustDays*86400)); # Find the first Monday by subtracting the correct number of days.  PS - 86400 seconds per day.

	my ($ckDay, $ckMon, $ckYear, $cfbSDay) = (localtime($FirstMonday))[3,4,5,7];
	$ckYear = $ckYear+1900;
	$ckMon = sprintf("%02d",$ckMon+1);
	$ckDay = sprintf("%02d",$ckDay);

	# Calculate week.  CFB weeks run Tuesday to Monday
	$cfbSDay = $cfbSDay - 6; # Start with the 1st Monday of September and subtract 6 to find the prior Tuesday
	my $currYDay = $dateArray[7];
	my $cfbWeek = int((($currYDay-$cfbSDay)/7)+1); # Calculate week. 1 through 15 & P
	# $cfbWeek = sprintf("%02d",$cfbWeek);

	$log->debug("First Monday of September: " . $ckMon."-".$ckDay."-".$ckYear);
	$log->debug("Start day: " . $cfbSDay);	
	$log->debug("Calc season week: " . $cfbWeek);
	
	# if ($cfbWeek > 15 or $cfbWeek < -10) { # Account for post season play.
		# $cfbWeek = 'P';
	# }
	# elsif ($cfbWeek < 1) { #
		# $cfbWeek = '01';
	# }

	$log->debug("Adjusted season week: " . $cfbWeek);

	#################################################	
	# $season = '2025';	# Check other seasons
	# $cfbWeek = '4';	# Check other weeks
	#################################################

	
	if (scalar(@CFBteams)>0) { #Make sure at least one team is entered
		# my $url = 'https://api-secure.sports.yahoo.com/v1/editorial/s/scoreboard?lang=en-US&ysp_redesign=1&leagues=ncaaf&week='.$cfbWeek.'&sched_states=2&v=2&ysp_enable_last_update=1&count=200'; 
################ Need to address URL format for post season games....  Week > 16??? ###############################
		# my $url = 'https://api-secure.sports.yahoo.com/v1/editorial/s/scoreboard?leagues=ncaaf&week='.$cfbWeek.'&sched_states=current&count=200'; 
		# my $url = 'https://api-secure.sports.yahoo.com/v1/editorial/s/scoreboard?leagues=ncaaf&week=current&sched_states=current&count=200'; 
		# my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotCFB,
											# \&gotErrorViaHTTP,
											# {caller => 'getCFB',
											# callerProc => \&getCFB,                                           
											# client => $client,
											# refreshItem => $refreshItem});
														  
		$log->info("Updates needed for 2026 season.");
		$log->info("Skipping CFB...");
		delete $sportsData{'College Football'};
		refreshData(undef, $client, $refreshItem);

		# $log->debug("async request: $url");
		# $http->get($url);
	}
	else {
		$log->info("Skipping CFB...");
		delete $sportsData{'College Football'};
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotCFB {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	delete $sportsData{'College Football'};
	$sportsData{'College Football'}{'logoURL'} = 'plugins/SuperDateTime/html/images/NCAA.png';
  
	$log->info("got " . $http->url());

	my $CFB_json = $http->content();

	my $perldata = eval{decode_json($CFB_json)};
	if ($@) {
		$log->error("Error detected in College Football JSON. Error: ".$@);
		$log->error("Skipping College Football");
		refreshData(undef, $client, $refreshItem);
		return;
	}

	# Preparation for comparison to game date.
	my @dateArray = gmtime(time-(60*60*8)); # Use 1AM Pacific for determining date so late games can finish before rolling over to new date.
	my $mday = $dateArray[3];
	$mday = sprintf("%02d",$mday);
	my $year = $dateArray[5]+1900;
	my $mon = $dateArray[4]+1;
	$mon = sprintf("%02d",$mon);
	# my $currDate = $mon . "-" . $mday . "-" . $year;
	my $currDate = $year.$mon.$mday;

	#################################################	
	# $currDate = '20250912';	 # Check other dates
	#################################################

	my $sport = "NCAA";
	my $gamedata = $perldata->{service}->{scoreboard}->{games};
	my @games = keys %$gamedata; #extract game keys and store in array
	my $game_count = scalar(@games);

	my $teamdata = $perldata->{service}->{scoreboard}->{teams};
	my @teams = keys %$teamdata; #extract team keys and store in array
	my $team_count = scalar(@teams);

	my $logodata = $perldata->{service}->{scoreboard}->{teamLogo};
	my @teamlogos = keys %$logodata; #extract team keys and store in array

	$log->debug("# of games this week: " . $game_count);
	$log->debug("# of teams playing Games this week: " . $team_count);

	my $game_num = 0;

	while ($game_num < $game_count) {
		my $game = $games[$game_num]; #store individual game key
		my $gamedate = substr($game,8,8); #extract date of game
		my $game_stat = $gamedata->{$game}->{'status_description'};
		my $game_time = $gamedata->{$game}->{'status_display_name'};
		my $clock_time = $game_time;
		my $start_time = $game_time;
		my $period = $gamedata->{$game}->{'current_period_id'};
		my $halftime = $gamedata->{$game}->{'is_halftime'};
		my $away_team_id = $gamedata->{$game}->{'away_team_id'};
		my $home_team_id = $gamedata->{$game}->{'home_team_id'};
		my $away_team = $teamdata->{$away_team_id}->{'abbr'};
		my $home_team = $teamdata->{$home_team_id}->{'abbr'};
		my $away_score = $gamedata->{$game}->{'total_away_points'};
		my $home_score = $gamedata->{$game}->{'total_home_points'};
		my $away_team_name = $teamdata->{$away_team_id}->{'display_name'};
		my $home_team_name = $teamdata->{$home_team_id}->{'display_name'};
		my $away_logoURL = $logodata->{$away_team_id};
		my $home_logoURL = $logodata->{$home_team_id};
		$home_team =~ s/ /_/g;
		$away_team =~ s/ /_/g;
		$home_team =~ s/&/_/g;
		$away_team =~ s/&/_/g;
		my $home_logoF = $imagePath."NCAA/".$home_team.".png";
		my $away_logoF = $imagePath."NCAA/".$away_team.".png";
		my $home_logo = "plugins/SuperDateTime/html/images/NCAA/".$home_team.".png";
		my $away_logo = "plugins/SuperDateTime/html/images/NCAA/".$away_team.".png";
		&storeLOGO($sport,$home_team,$home_logoURL,$home_logoF,$away_team,$away_logoURL,$away_logoF);
		$log->debug("Game#: ", $game_num);
		$log->debug("GameID: ", $game);
		$log->debug("Gamedate: ", $gamedate);
		$log->debug("Game Stat: ", $game_stat);
		$log->debug("Game Time: ", $game_time);
		$log->debug("Clock Time: ", $clock_time);
		$log->debug("Period: ", $period);
		$log->debug("Halftime? ", $halftime);
		$log->debug("Away Team ID: ", $away_team_id);
		$log->debug("Home Team ID: ", $home_team_id);
		$log->debug("Away Team Abbr: ", $away_team);
		$log->debug("Home Team Abbr: ", $home_team);
		$log->debug("Away Team Name: ", $away_team_name);
		$log->debug("Home Team Name: ", $home_team_name);
		$log->debug("Away Team Logo: ", $away_logoURL);
		$log->debug("Home Team Logo: ", $home_logoURL);
		$log->debug("Away Score: ", $away_score);
		$log->debug("Home Score: ", $home_score);

		if ($gamedate eq $currDate) { 
			if ($game_stat =~ /Live/i) { #Active games
				$log->debug("Active game");
				if ($period =~/OT/i) {
					$log->debug("Overtime");
					$log->debug('Game Status: ' . $game_stat);
					$log->debug('Period: ' . $period);
					$log->debug('Clock Time: ' . $clock_time);
					$clock_time = "OT";
					$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
					if ($period =~/(\d+)/) {
						$log->debug("Multiple Overtime");
						$clock_time = $1."OT";
						$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
					}
				}
				elsif ($period =~ m/(\d)/) { 
					$log->debug("Period # Detected");
					my $Period = $1;
					$clock_time = $clock_time;
					if ($period =~ /end/i) {
						$log->debug("End Detected");
						$clock_time = 'End '.$Period;
					}
				}
				elsif (($halftime eq "true") or ($game_time eq "Half")) { #Halftime - Gametime = Halftime
					$log->debug("Halftime");
					$clock_time = "Halftime";
				}
			}
			elsif ($game_stat =~ /Final/i){ #Finished
				$log->debug("Finished game");
				$clock_time = "Final";
				if ($game_time =~/\d+/i or $game_time =~/OT/i) { # Either OT or number in Final Message = Overtime
					my $OTPeriod = '';
					$log->debug('Game Status: ' . $game_stat);
					$log->debug('Period: ' . $period);
					$log->debug('Clock Time: ' . $clock_time);
					$log->debug('Final Message: ' . $game_time);
					if ($game_time =~/OT/) {
						if ($game_time =~/(\d+)/) { # OT with number = number of OT periods
							$OTPeriod = $1;
							$log->debug('Final Message Displaying # of OT Periods: '.$1);
						}
						else { # OT without number = single overtime
							$clock_time = "Final OT";
						}
					}
					elsif ($game_time =~/(\d+)/) { # Number without OT = number of total periods
						$OTPeriod = $1 - 4; # Total periods - Regular game periods = Overtime periods
						$log->debug('Final Message Displaying Total Periods: '.$1);
					}
					if ($OTPeriod > 1) {
						$log->debug("Multiple Overtime");
						$clock_time = "Final ".$OTPeriod."OT";
						$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
					}
					else { # OT without number = single overtime
						$clock_time = "Final OT";
						$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
					}
				}
			}
			elsif ($game_stat =~/pre/i) {	# Upcoming games - Blank out scores, Gametime = Startime
				$log->debug("Upcoming game");
				$away_score = '';
				$home_score = '';
				$clock_time = $start_time;
			}
			elsif ($game_stat =~/cancel/i) {  
				$log->debug("Canceled game");
				$away_score = '';
				$home_score = '';
				$clock_time = 'Canceled';
			}
			elsif ($game_stat =~/delayed/i) {	
				$log->debug("Game delayed");
				$clock_time = 'Delayed';
			}
			elsif ($game_stat =~/postponed/i) {  
				$log->debug("Game postponed");
				$clock_time = 'Postponed';
			}
			else { # Not sure... Setup as upcoming game - Blank out scores, Gametime = Startime
				$log->warn("Uncertain CFB game status");
				$away_score = '';
				$home_score = '';
				$clock_time = $start_time;
				$log->warn('Start Time: ' . $start_time);
				$log->warn('Game Status: ' . $game_stat);
				$log->warn('Period: ' . $period);
				$log->warn('Clock Time: ' . $clock_time);
				$log->warn($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
				$log->warn($away_team. " iconURL = ". $away_logo);
				$log->warn($home_team. " iconURL = ". $home_logo);
			}

			$log->debug("Clock time: ".$clock_time);
			$log->debug("Converted Clock time: ".convertTime($clock_time));
			
			$sportsData{'College Football'}{$home_team.$clock_time}{'homeTeamCK'} = $home_team_name;
			$sportsData{'College Football'}{$home_team.$clock_time}{'awayTeamCK'} = $away_team_name;
			$sportsData{'College Football'}{$home_team.$clock_time}{'homeTeam'} = shortenCFB($home_team_name);
			$sportsData{'College Football'}{$home_team.$clock_time}{'awayTeam'} = shortenCFB($away_team_name);
			$sportsData{'College Football'}{$home_team.$clock_time}{'homeScore'} = $home_score;
			$sportsData{'College Football'}{$home_team.$clock_time}{'awayScore'} = $away_score;
			$sportsData{'College Football'}{$home_team.$clock_time}{'gameTime'} = convertTime($clock_time);
			$sportsData{'College Football'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
			$sportsData{'College Football'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
			$sportsData{'College Football'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;

			if ((teamCheck($home_team_name,\@CFBteams)==1) || (teamCheck($away_team_name,\@CFBteams)==1)) {
				displayLines($client, $clock_time, $away_team_name, $home_team_name, $away_score, $home_score, 'NCAA Football', 'getCFB', \&shortenCFB, undef);
			}
			
			$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
			$log->debug($away_team. " iconURL = ". $away_logo);
			$log->debug($home_team. " iconURL = ". $home_logo);
			$log->debug(" ");
		}
		$game_num++ 
	}
	refreshData(undef, $client, $refreshItem);	
}

sub getSoccer {  #Set up Async HTTP requests for soccer scores
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;
	
	my ($mday,$mon,$year,$hour, $isdst, $yday) = (gmtime(time-(60*60*8)))[3,4,5,2,8,7]; # Roll over date embedded in URL at 1AM Pacific instead of 12AM Eastern
	$year = $year+1900;
	$mon = sprintf("%02d",$mon+1);
	$mday = sprintf("%02d",$mday);

######## Test other dates ########
	# $year   = '2026';   #yyyy
	# $mon    = '06';     #mm
	# $mday   = '11';     #dd
##################################

	my $soccerLeague = $prefs->get('soccerLeague');
	$log->debug("League: ".$soccerLeague);
	$log->debug("Team count: ".scalar(@soccerTeams));
	$log->debug("Game count: ".$soccer_GameCount);
	$log->debug("Game #: ".$soccer_GameNum);

	if ($soccerLeague && scalar(@soccerTeams)>0 && $refreshTracker[4] == 1) { #Make sure League is selected AND at least one team is entered.
		my $url = 'https://graphite.sports.yahoo.com/v1/query/shangrila/leagueGameIdsByDate?lang='.$prefs->get('lang').'&region=US&tz=America%2FNew_York&ysp_platform=next-app-sports&leagues='.$soccerLeague.'&dates='.$year.'-'.$mon.'-'.$mday; 
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotSoccerGameIDs,
											\&gotErrorViaHTTP,
											{caller => 'getSoccer',
											callerProc => \&getSoccer,                                           
											client => $client,
											refreshItem => $refreshItem});
														  
		$log->debug("async request: $url");
		$http->get($url);
	}
	elsif ($soccerLeague && scalar(@soccerTeams)>0 && $soccer_GameNum < $soccer_GameCount) { #Make sure League is selected AND at least one team is entered.
		my $gameID = @soccer_Game_IDs[$soccer_GameNum];
		my $url = 'https://graphite.sports.yahoo.com/v1/query/shangrila/scoreboardGame?lang='.$prefs->get('lang').'&region=US&tz=America%2FNew_York&ysp_platform=next-app-sports&gameId='.$gameID.'&statLeaderCount=3&singleStatLeader=false'; 
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotSoccer,
											\&gotErrorViaHTTP,
											{caller => 'getSoccer',
											callerProc => \&getSoccer,                                           
											client => $client,
											refreshItem => $refreshItem});
														  
		$log->debug("async request: $url");
		$http->get($url);
	}
	elsif ($soccerLeague && scalar(@soccerTeams)>0 && $soccer_GameNum == $soccer_GameCount) { #Reset for next data refresh cycle.
		$log->debug("Made it to max Soccer game #");
		@soccer_Game_IDs = ();
		$soccer_GameCount = 0;
		$soccer_GameNum = 0;
		$refreshTracker[4] = 1;
		refreshData(undef, $client, $refreshItem);
	}
	else {
		$log->info("Skipping Soccer...");
		delete $sportsData{'Soccer'};
		@soccer_Game_IDs = ();
		$soccer_GameCount = 0;
		$soccer_GameNum = 0;
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotSoccerGameIDs {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};
   
	delete $sportsData{'Soccer'};
	$sportsData{'Soccer'}{'logoURL'} = 'plugins/SuperDateTime/html/images/soccer.png';
	@soccer_Game_IDs = ();
	$soccer_GameCount = 0;
	$soccer_GameNum = 0;

	$log->info("got " . $http->url());
	my $soccer_json = $http->content();

	my $perldata = eval{decode_json($soccer_json)};
	if ($@) {
		$log->error("Error detected in Professional Soccer JSON. Error: ".$@);
		$log->error("Skipping Professional Soccer");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	my $gamedata = $perldata->{data}->{leagues}[0]->{games};
	my $game_count = scalar(@$gamedata);
	$log->debug("Soccer Game count: " . $game_count);
	if ($game_count > 0) {
		my $game_num = 0;
		while ($game_num < $game_count) {
			@soccer_Game_IDs[$game_num] = @$gamedata[$game_num]->{gameId};
			$log->debug("Game# ".$game_num." ID = " . @soccer_Game_IDs[$game_num]);
			$game_num++
		}
	}
	$soccer_GameCount = scalar(@soccer_Game_IDs);
	$log->debug("# of Soccer Game IDs stored: " . $soccer_GameCount);
	
	# Now go back to getSoccer to retrieve JSON for each game and proceed to gotSoccer for each game.
	$refreshTracker[4] = 0;
	$soccer_GameNum = 0;
	getSoccer(undef, $client, $refreshItem);
}


sub gotSoccer {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};
	
	$log->info("got " . $http->url());
	my $soccer_json = $http->content();

	my $perldata = eval{decode_json($soccer_json)};
	if ($@) {
		$log->error("Error detected in Professional Soccer JSON. Error: ".$@);
		$log->error("Skipping Professional Soccer");
		refreshData(undef, $client, $refreshItem);
		return;
	}


	my $sport = "Soccer"; # Used to store logo images locally
	my $gamedata = $perldata->{data}->{games}[0];

	if ($soccer_GameNum < $soccer_GameCount) {
		my $leagueName = $gamedata->{league}->{name}; 
		my $gameId = $gamedata->{gameId}; 
		my $gamedate = substr($gamedata->{'startDate'},0,10); #extract date of game
		my $game_stat = $gamedata->{'status'};
		my $game_status = $gamedata->{'statusDisplayName'};
		my $game_time = $gamedata->{'startTime'};
		my $clock_time = $gamedata->{'timeElapsedDisplay'};
		my $start_time = C24to12(substr($game_time,11,5));
		my $period = $gamedata->{'currentPeriod'}->{'shortDisplayName'};
		my $away_team_id = $gamedata->{'awayTeamId'};
		my $home_team_id = $gamedata->{'homeTeamId'};
		my $away_team = $gamedata->{'awayTeam'}->{'abbreviation'};
		my $home_team = $gamedata->{'homeTeam'}->{'abbreviation'};
		my $away_team_disp = $gamedata->{'awayTeam'}->{'displayName'};
		my $home_team_disp = $gamedata->{'homeTeam'}->{'displayName'};
		my $away_team_name = $gamedata->{'awayTeam'}->{'fullName'};
		my $home_team_name = $gamedata->{'homeTeam'}->{'fullName'};
		my $away_team_nick = $gamedata->{'awayTeam'}->{'nickname'};
		my $home_team_nick = $gamedata->{'homeTeam'}->{'nickname'};
		my $away_score = $gamedata->{'awayScore'};
		my $home_score = $gamedata->{'homeScore'};
		my $awaySO_score = $gamedata->{'awayShootoutScore'};
		my $homeSO_score = $gamedata->{'homeShootoutScore'};
		my $away_logoURL = $gamedata->{'awayTeam'}->{'teamLogo'}->{'url'};
		my $away_logoURL_begin = index($away_logoURL,'https://s.yimg.com/cv/apiv2/');
		my $away_logoURL_end = index($away_logoURL,'.cf.webp');
		my $away_logoURL_len = $away_logoURL_end - $away_logoURL_begin;
		my $away_logoURL = substr($away_logoURL,$away_logoURL_begin,$away_logoURL_len);
		my $home_logoURL = $gamedata->{'homeTeam'}->{'teamLogo'}->{'url'};
		my $home_logoURL_begin = index($home_logoURL,'https://s.yimg.com/cv/apiv2/');
		my $home_logoURL_end = index($home_logoURL,'.cf.webp');
		my $home_logoURL_len = $home_logoURL_end - $home_logoURL_begin;
		my $home_logoURL = substr($home_logoURL,$home_logoURL_begin,$home_logoURL_len);
		my $home_logoF = $imagePath."/".$sport."/".$home_team.".png";
		my $away_logoF = $imagePath."/".$sport."/".$away_team.".png";
		my $home_logo = "plugins/SuperDateTime/html/images/".$sport."/".$home_team.".png";
		my $away_logo = "plugins/SuperDateTime/html/images/".$sport."/".$away_team.".png";
		&storeLOGO($sport,$home_team,$home_logoURL,$home_logoF,$away_team,$away_logoURL,$away_logoF);
		$log->debug("Game#: ", $soccer_GameNum);
		$log->debug("GameID: ", $gameId);
		$log->debug("Gamedate: ", $gamedate);
		$log->debug("Game Stat: ", $game_stat);
		$log->debug("Game Status: ", $game_status);
		$log->debug("Game Time: ", $game_time);
		$log->debug("Clock Time: ", $clock_time);
		$log->debug("Period: ", $period);
		$log->debug("Away Team ID: ", $away_team_id);
		$log->debug("Away Team Abbr: ", $away_team);
		$log->debug("Away Team Display Name: ", $away_team_disp);
		$log->debug("Away Team Name: ", $away_team_name);
		$log->debug("Away Team Nick Name: ", $away_team_nick);
		$log->debug("Home Team ID: ", $home_team_id);
		$log->debug("Home Team Abbr: ", $home_team);
		$log->debug("Home Team Display Name: ", $home_team_disp);
		$log->debug("Home Team Name: ", $home_team_name);
		$log->debug("Home Team Nick Name: ", $home_team_nick);
		$log->debug("Away Team Logo: ", $away_logoURL);
		$log->debug("Home Team Logo: ", $home_logoURL);
		$log->debug("Away Score: ", $away_score);
		$log->debug("Home Score: ", $home_score);
		if ($awaySO_score || $homeSO_score) {
			$log->debug("Away SO Score: ", $awaySO_score);
			$log->debug("Home SO Score: ", $homeSO_score);
		}

		if ($game_stat =~ /IN_PROGRESS/i) { #Active games
			$log->debug("Active game");
			if ($period =~/OT/i) {
				$log->debug("Overtime");
				$log->debug('Game Status: ' . $game_stat);
				$log->debug('Period: ' . $period);
				$log->debug('Clock Time: ' . $clock_time);
				$clock_time = "OT";
				$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
				if ($period =~/(\d+)/) {
					$log->debug("Multiple Overtime");
					$clock_time = $1."OT";
					$log->debug($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
				}
			}
			elsif ($game_status eq "HT") { #Halftime - Gametime = Halftime
				$log->debug("Halftime");
				# $clock_time = $game_clock." Halftime";
				$clock_time = "HT";
			}
			elsif ($period =~ m/(\d)/) { 
				$log->debug("Period # Detected");
				my $Period = $1;
				# $clock_time = $game_clock;
				if ($period =~ /end/i) {
					$log->debug("End Detected");
					$clock_time = 'End '.$Period;
				}
			}
			elsif ($awaySO_score || $homeSO_score) {
				$log->debug("Shootout detected");
				$clock_time = $period;
				$away_score = $away_score."(".$awaySO_score.")";
				$home_score = $home_score."(".$homeSO_score.")";
			}

		}
		elsif ($game_stat =~ /FINAL/i){ #Finished
			$log->debug("Finished game");
			$clock_time = "Final";
			if ($awaySO_score || $homeSO_score) {
				$log->debug("Shootout detected");
				$away_score = $away_score."(".$awaySO_score.")";
				$home_score = $home_score."(".$homeSO_score.")";
			}
			if ($game_time =~/\d+/i or $game_time =~/OT/i) { # Either OT or number in Final Message = Overtime
				my $OTPeriod = '';
				$log->debug('Game Status: ' . $game_stat);
				$log->debug('Period: ' . $period);
				$log->debug('Clock Time: ' . $clock_time);
				$log->debug('Final Message: ' . $game_time);
				# if ($game_time =~/OT/) {
				if ($period =~/OT/i) { # Either OT or number in Final Message = Overtime
					$log->debug('Game Status: ' . $game_status);
					$log->debug('Period: ' . $period);
					$log->debug('Clock Time: ' . $clock_time);
					$log->debug('Final Message: ' . $game_time);
					$clock_time = $game_status;
				}
				# if ($period =~/OT/i) { # Either OT or number in Final Message = Overtime
					# if ($game_time =~/(\d+)/) { # OT with number = number of OT periods
						# $OTPeriod = $1;
						# $log->info('Final Message Displaying # of OT Periods: '.$1);
					# }
					# else { # OT without number = single overtime
						# $clock_time = "Final OT";
					# }
				# }
				# elsif ($game_time =~/(\d+)/) { # Number without OT = number of total periods
					# $OTPeriod = $1 - 4; # Total periods - Regular game periods = Overtime periods
					# $log->info('Final Message Displaying Total Periods: '.$1);
				# }
				# if ($OTPeriod > 1) {
					# $log->info("Multiple Overtime");
					# $clock_time = "Final ".$OTPeriod."OT";
					# $log->info($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
				# }
				# else { # OT without number = single overtime
					# $clock_time = "Final OT";
					# $log->info($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
				# }
			}
		}
		elsif ($game_stat =~/PREGAME/i) {	# Upcoming games - Blank out scores, Gametime = StartTime
			$log->debug("Upcoming game");
			$away_score = '';
			$home_score = '';
			$clock_time = $start_time;
		}
		elsif ($game_stat =~/CANCELLED/i) {  
			$log->debug("Canceled game");
			$away_score = '';
			$home_score = '';
			$clock_time = 'Canceled';
		}
		elsif ($game_stat =~/delayed/i) {	
			$log->debug("Game delayed");
			$clock_time = 'Delayed';
		}
		elsif ($game_stat =~/postponed/i) {  
			$log->debug("Game postponed");
			$clock_time = 'Postponed';
		}
		else { # Not sure... Setup as upcoming game - Blank out scores, Gametime = Startime
			$log->warn("Uncertain Soccer game status");
			$away_score = '';
			$home_score = '';
			$clock_time = $start_time;
			$log->warn('Start Time: ' . $start_time);
			$log->warn('Game Status: ' . $game_stat);
			$log->warn('Period: ' . $period);
			$log->warn('Clock Time: ' . $clock_time);
			$log->warn($start_time. "- ". $away_team. " ". $away_score. " @ ". $home_team. " ". $home_score. " - ". convertTime($clock_time));
			$log->warn($away_team. " iconURL = ". $away_logo);
			$log->warn($home_team. " iconURL = ". $home_logo);
		}

		$log->debug("Clock time: ".$clock_time);
		$log->debug("Converted Clock time: ".convertTime($clock_time));
		
		my $home_team_nm = shortenSoccer($home_team_disp, $home_team_nick);
		my $away_team_nm = shortenSoccer($away_team_disp, $away_team_nick);
		
		$sportsData{'Soccer'}{$home_team.$clock_time}{'homeTeamCK'} = $home_team_name;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'awayTeamCK'} = $away_team_name;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'homeTeam'} = $home_team_nm;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'awayTeam'} = $away_team_nm;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'homeScore'} = $home_score;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'awayScore'} = $away_score;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'gameTime'} = convertTime($clock_time);
		$sportsData{'Soccer'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
		$sportsData{'Soccer'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;

		if ((teamCheck($home_team_name,\@soccerTeams)==1) || (teamCheck($away_team_name,\@soccerTeams)==1)) {
			# displayLines($client, $clock_time, $away_team_nm, $home_team_nm, $away_score, $home_score, 'Professional Soccer', 'getSoccer', \&shortenSoccer, undef);
			displayLines($client, $clock_time, $away_team_nm, $home_team_nm, $away_score, $home_score, $leagueName, 'getSoccer', \&shortenSoccer, undef);
		}
		
		$log->debug($start_time. "- ". $away_team_name. " ". $away_score. " @ ". $home_team_name. " ". $home_score. " - ". convertTime($clock_time));
		$log->debug($away_team. " iconURL = ". $away_logo);
		$log->debug($home_team. " iconURL = ". $home_logo);
		$log->debug(" ");

		$soccer_GameNum++;
		getSoccer(undef, $client, $refreshItem);
	}
	else {
		$log->debug("Made it to max Soccer game #");
		@soccer_Game_IDs = ();
		$soccer_GameCount = 0; # reset for next refresh cycle.
		$soccer_GameNum = 0;
		$refreshTracker[4] = 1;
		refreshData(undef, $client, $refreshItem);  
	}
}

sub getNHL {  #Set up Async HTTP request for NHL
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;
	
	my ($mday,$mon,$year,$hour, $isdst) = (gmtime(time-(60*60*8)))[3,4,5,2,8];  # Roll over date embedded in URL at 1AM Pacific instead of 12AM Eastern
	$mday = sprintf("%02d",$mday);
	$mon = sprintf("%02d",$mon+1);
	$year = $year+1900;
	
########## Test other game dates ##########
	# $mday = '02';
	# $mon = '01';
	# $year = '2025';
###########################################

	if (scalar(@NHLteams)>0) { #Make sure a hockey team is chosen  
		my $url = 'https://api-web.nhle.com/v1/score/'.$year.'-'.$mon.'-'.$mday;
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotNHL,
														\&gotErrorViaHTTP,
														{caller => 'getNHL',
														callerProc => \&getNHL,                                                       
														client => $client,
														refreshItem => $refreshItem});
		$log->debug("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	else {
		$log->info("Skipping NHL...");
		if (scalar(@NHLteams)>0) {
			saveCycles('getNHL');
		}
		else {
			delete $sportsData{'NHL'};
		}
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotNHL {
	my $http = shift;
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	delete $sportsData{'NHL'};
	$sportsData{'NHL'}{'logoURL'} = 'plugins/SuperDateTime/html/images/NHL.png';

	$refreshTracker[2] = 0;

	$log->info("got " . $http->url());

	my $NHL_json = $http->content();
	my $perldata = eval{decode_json($NHL_json)};
	if ($@) {
		$log->error("Error detected in NHL JSON. Error: ".$@);
		refreshData(undef, $client, $refreshItem);
		return;
	}
	my $isDST = (localtime(time))[8]; # used for conversion from UTC to Eastern time zone.
	$log->debug("DST? " . $isDST);

	my $games_array = $perldata->{'games'}; # Store the ARRAY of games.
	if (ref($games_array) eq 'ARRAY') { # expecting array
		$refreshTracker[2] = 0;
		my $game_count = scalar(@$games_array); # How many games today?
		my $game_num = 0;
		$log->debug("Game count: " . $game_count);
		while ($game_num < $game_count) {
			my $game = @$games_array[$game_num]; #split array into individual games
			my $game_stat = $game->{'gameState'}; #FUT, PRE, LIVE, CRIT, Delayed?, Postponed? 
			my $game_time = $game->{'startTimeUTC'}; # UTC start time 
			my $period = $game->{'period'}; # 
			my $period_txt = $game->{'periodDescriptor'}->{'periodType'}; # REG, OT, SO 
			my $period_time = $game->{'clock'}->{'timeRemaining'}; #
			my $intermission = $game->{'clock'}->{'inIntermission'}; #
			my $game_Outcome = $game->{'gameOutcome'}->{'lastPeriodType'}; # REG, OT, SO
			my $away_team = $game->{'awayTeam'}->{'name'}->{'default'};
			my $home_team = $game->{'homeTeam'}->{'name'}->{'default'};
			my $away_logo = $game->{'awayTeam'}->{'abbrev'};
			my $home_logo = $game->{'homeTeam'}->{'abbrev'};
			my $away_logoURL = $game->{'awayTeam'}->{'logo'};
			my $home_logoURL = $game->{'homeTeam'}->{'logo'};
			my $away_score = $game->{'awayTeam'}->{'score'};
			my $home_score = $game->{'homeTeam'}->{'score'};
			my $clock_time = $game_time;
			
			# Calculate Eastern Start Time from UTC time
			my $StartHr = '';
			my $StartMin = '';
			my $AmPm = 'AM';
			if ($game_time =~ /.+T(\d+)\:(\d+).+/) { # Extract hours and minutes from UTC time
				$StartHr = $1;
				$StartMin = $2;
				if ($isDST) {
					$StartHr = $StartHr - 4;# convert to Eastern time
				}
				else {
					$StartHr = $StartHr - 5;
				}
				if ($StartHr < 0) {         # check for crossing to previous day
					$StartHr = $StartHr + 24;
				}
				if ($StartHr > 12) {        # convert to 12 Hr format
					$StartHr = $StartHr - 12;
					$AmPm = 'PM';
				}
				elsif ($StartHr == 0) {     # Midnight
					$StartHr = $StartHr + 12
				}
				$clock_time = $StartHr . ":" . $StartMin . ' ' . $AmPm;
			}

			my $Cclock_time = convertTime($clock_time);
		
			if ($game_stat =~ /LIVE/i or $game_stat =~ /CRIT/i) { # active games
				$log->debug("Active Game");
				if ($period > '3') {
					$log->debug("Active OT|SO Game");
					$clock_time = $period_time." ".$period.$period_txt;
					$Cclock_time = convertTime($clock_time);
				}
				else {
					$clock_time = $period_time."/".$period;
					$Cclock_time = convertTime($clock_time);
					if ($intermission eq 1) {
						$Cclock_time = $Cclock_time.'i';
					}
				}
			}
			elsif ($game_stat =~ /Postponed/i){ # postponed games
				$log->debug("Postponed Game");
				$clock_time = $game_stat;
				$Cclock_time = convertTime($clock_time);
				$home_score = '';
				$away_score = '';
			}
			elsif ($game_stat =~ /OFF/i or $game_stat =~ /FINAL/i){ # completed games
				$log->debug("Finished Game");
				if ($game_Outcome eq "OT" or $game_Outcome eq "SO") {
					$log->debug("Finished OT|SO Game");
					$clock_time = 'Final '.$period_txt;
					$Cclock_time = convertTime($clock_time);
				}
				else {
					$clock_time = 'Final';
					$Cclock_time = convertTime($clock_time);
				}
			}
			else { # upcoming games  
				$log->debug("Upcoming Game");
				$home_score = '';
				$away_score = '';
			}


			$home_logo = lc($home_logo);
			$away_logo = lc($away_logo);
			if ($home_logo =~ /vgk|lak|sjs|tbl|njd|uta/) {
				$home_logo = $NHLICONmap{$home_logo};
			}
			if ($away_logo =~ /vgk|lak|sjs|tbl|njd|uta/) {
				$away_logo = $NHLICONmap{$away_logo};
			}
			my $sport = "NHL";
			my $home_logoURL = "http://a.espncdn.com/combiner/i?img=/i/teamlogos/nhl/500/scoreboard/".$home_logo.".png";
			my $away_logoURL = "http://a.espncdn.com/combiner/i?img=/i/teamlogos/nhl/500/scoreboard/".$away_logo.".png";
			my $home_logoF = $imagePath."NHL/".$home_logo.".png";
			my $away_logoF = $imagePath."NHL/".$away_logo.".png";
			$home_logo = "plugins/SuperDateTime/html/images/NHL/".$home_logo.".png";
			$away_logo = "plugins/SuperDateTime/html/images/NHL/".$away_logo.".png";
			&storeLOGO($sport,$home_team,$home_logoURL,$home_logoF,$away_team,$away_logoURL,$away_logoF);

			$log->debug("Game# " . $game_num);
			$log->debug("Status: " . $game_stat);
			$log->debug("Teams: " . $away_team . " @ " . $home_team);
			$log->debug("Period: " . $period);
			$log->debug("Period text: " . $period_txt);
			$log->debug("Period time: " . $period_time);
			$log->debug("Intermission: " . $intermission);
			$log->debug("Raw Clock: " . $clock_time);
			$log->debug("Converted Clock: " . $Cclock_time);
			$log->debug("Score: " . $away_score . " - " . $home_score);
			$log->debug("Home Logo URL: " . $home_logo);
			$log->debug("Away Logo URL: " . $away_logo);
			$log->debug("Game Outcome: " . $game_Outcome);

			$sportsData{'NHL'}{$home_team.$clock_time}{'homeTeamCK'} = $home_team;
			$sportsData{'NHL'}{$home_team.$clock_time}{'awayTeamCK'} = $away_team;
			$sportsData{'NHL'}{$home_team.$clock_time}{'homeTeam'} = shortenNHL($home_team);
			$sportsData{'NHL'}{$home_team.$clock_time}{'awayTeam'} = shortenNHL($away_team);
			$sportsData{'NHL'}{$home_team.$clock_time}{'gameTime'} = convertTime($clock_time);
			$sportsData{'NHL'}{$home_team.$clock_time}{'homeScore'} = $home_score;
			$sportsData{'NHL'}{$home_team.$clock_time}{'awayScore'} = $away_score;
			$sportsData{'NHL'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
			$sportsData{'NHL'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
			$sportsData{'NHL'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;

			if ((teamCheck($home_team,\@NHLteams)==1) || (teamCheck($away_team,\@NHLteams)==1)) {
				displayLines($client, $clock_time, $away_team, $home_team, $away_score, $home_score, 'NHL', 'getNHL', \&shortenNHL , undef);	
				$log->debug("This game selected.");
			}
			$log->debug(" ");
			$game_num++;
		}
	}
	else {
		$status = '-';
		$log->warn("Error parsing NHL data.");
	}
	refreshData(undef, $client, $refreshItem);  
}

sub getLongWeather {
	$log->debug("in sub getLongWeather");
    delete $miscData{'LongWeather'}; #Wipe out old data on each refresh
	my $weatherInterval = currentWeatherInterval();
    
    for (my $i = 0; $i < scalar @WETdisplayItems1; $i++) { # Loop for the 
        if ($weatherInterval >0) { # Does user want active display of Long Weather on Boom, Transport, Classic etc.
            if (($weatherInterval <5) and ($i <4)) { # Limit to loops 0 - 3 (-1, 0, 1, 2)
                addDisplayItem('getLongWeather', $WETdisplayItems1[$i], $WETdisplayItems2[$i], 'L');
            }
        }
		# Make available to external API (i.e. - Custom Clock)
		$miscData{'getLongWeather'}{$i}{'line1'} = $WETdisplayItems1[$i];
		$miscData{'LongWeather'}{$i}{'period'} = $WETdisplayItems1[$i];
		$miscData{'getLongWeather'}{$i}{'line2'} = $WETdisplayItems2[$i];
		$miscData{'LongWeather'}{$i}{'forecast'} = $WETdisplayItems2[$i];
		$miscData{'getLongWeather'}{$i}{'type'} = 'long';
#		if ($i > 3) { #### Fix next release ####
#			$miscData{'LongWeather'}{$i}{'dtvalue'} = $WETdisplayItems3[$i];
#		}
#		$log->debug("CC Long weather period: $i ". $miscData{'LongWeather'}{$i}{'period'}." ".$miscData{'LongWeather'}{$i}{'date'});
#		$log->debug("CC Long weather text: ". $miscData{'LongWeather'}{$i}{'forecast'});
    }
}

sub getNFL {  #Set up Async HTTP request for NFL
	my $timerObj = shift; #Should be undef
	my $client = shift;
	my $refreshItem = shift;

	$log->debug('# of Teams selected: '.scalar(@NFLteams));
	$log->debug('Refresh NFL status: '.$refreshTracker[3]);
	$log->debug('NFL Game #: '.$NFL_GameNum);
	$log->debug('# of NFL Games: '.$NFL_GameCount);

	if (scalar(@NFLteams)>0  && $refreshTracker[3] == 1) { #Get game IDs for this week.  Make sure a NFL team is chosen and refresh flag is set.
		my $url2 = 'https://api-secure.sports.yahoo.com/v1/editorial/s/scoreboard?lang=en-US&leagues=nfl'; 
		my $url = 'https://graphite.sports.yahoo.com/v1/query/shangrila/leagueGameIds?lang=en-US&region=US&ysp_platform=next-app-sports&league=nfl&season=current&week=current'; 
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotNFLgameIDs,
												  \&gotErrorViaHTTP,
												  {caller => 'getNFL',
											   callerProc => \&getNFL,
												   client => $client,
												   refreshItem => $refreshItem});
		$log->debug("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	elsif ((scalar(@NFLteams)) && ($NFL_GameNum < $NFL_GameCount)) { #Make sure a NFL team is chosen and there are more games to retrieve
		my $gameID = @NFL_Game_IDs[$NFL_GameNum];
		my $url = 'https://graphite.sports.yahoo.com/v1/query/shangrila/scoreboardGame?lang=en-US&region=US&tz=America%2FNew_York&ysp_platform=next-app-sports&gameId='.$gameID.'&statLeaderCount=3&singleStatLeader=false';
		my $http = Slim::Networking::SimpleAsyncHTTP->new(\&gotNFL,
												  \&gotErrorViaHTTP,
												  {caller => 'getNFL',
											   callerProc => \&getNFL,
												   client => $client,
												   refreshItem => $refreshItem});
		$log->debug("async request: $url");
		$http->get($url, 'User-Agent' => 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0');
	}
	elsif ((scalar(@NFLteams)) && ($NFL_GameNum == $NFL_GameCount)) { #No more games.  Reset for next data refresh cycle.
		$log->debug("Made it to max NFL game #");
		@NFL_Game_IDs = ();
		$NFL_GameCount = 0;
		$NFL_GameNum = 0;
		$refreshTracker[3] = 1;
		refreshData(undef, $client, $refreshItem); 
	}
	else {
		$log->info("Skipping NFL...");
		delete $sportsData{'NFL'};
		refreshData(undef, $client, $refreshItem);
	}
}

sub gotNFLgameIDs { # Retrieve NFL game IDs for the current week/date.
	my $http = shift;
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	delete $sportsData{'NFL'};
	@NFL_Game_IDs = ();
	my $game_count = 0;
	my $game_num = 0;
	$sportsData{'NFL'}{'logoURL'} = 'plugins/SuperDateTime/html/images/nfl.png';    

	$log->info("got " . $http->url());

	my $NFL_json = $http->content();

	# Get NFL JSON data and decode it
	my $perldata = eval{decode_json($NFL_json)};
	if ($@) {
		$log->error("Error detected in NFL_Week JSON. Error: ".$@);
		$log->error("Skipping NFL");
		refreshData(undef, $client, $refreshItem);
		return;
	}
	
	my $gamedata = $perldata->{data}->{leagues}[0]->{games};
	
	if (ref($gamedata) eq 'ARRAY') { # expecting array 
		$log->debug("NFL game data is an ARRAY");
		my $game_count = scalar(@$gamedata);
		while ($game_num < $game_count) {
			@NFL_Game_IDs[$game_num] = @$gamedata[$game_num]->{gameId};
			$log->debug("Game# ".$game_num." ID = " . @NFL_Game_IDs[$game_num]);
			$game_num++
		}
		$NFL_GameCount = scalar(@NFL_Game_IDs);
	}
	else {
		$log->debug("NFL game data is not an ARRAY");
		my $game_count =1;
		@NFL_Game_IDs[0] = @$gamedata[0]->{gameId};
	}

	$log->debug("NFL Game count: " . $game_count);
	my $game_num = 0;

	$log->debug("# of NFL Game IDs stored: " . $NFL_GameCount);
	
	# Now go back to getNFL to retrieve JSON for each game and proceed to gotNFL for each game.
	$refreshTracker[3] = 0;
	$NFL_GameNum = 0;
	getNFL(undef, $client, $refreshItem);
}

sub gotNFL {
	my $http = shift;
	
	my $params = $http->params();
	my $client = $params->{'client'};
	my $refreshItem = $params->{'refreshItem'};

	$log->debug("got " . $http->url());

	# Get NFL JSON data and decode it
	my $NFL_json = $http->content();
	my $perldata = eval{decode_json($NFL_json)};
	if ($@) {
		$log->error("Error detected in NFL JSON. Error: ".$@);
		$log->error("Skipping NFL");
		refreshData(undef, $client, $refreshItem);
		return;
	}

	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)= (gmtime(time-(60*60*8))); #Change date at 1AM Pacific to allow late games to complete before changeover.
	$year = $year+1900;
	$mon = sprintf("%02d",$mon+1); # month starts at 0
	$mday = sprintf("%02d",$mday);

	my $today = $year.$mon.$mday;
	
	############### Test other dates within season week	##############
	# $today = '20250731';	  # Use this line to test other dates#
	##################################################################

	$log->debug("Today's date = ", $today);

	my $gamedata = $perldata->{data}->{games}[0];

	if ($NFL_GameNum < $NFL_GameCount) {
		my $game = $gamedata->{'gameId'}; #store individual game key
		my $gamedate = substr($game,6,8); #extract date of game
		my $game_stat = $gamedata->{'status'};
		my $game_time = $gamedata->{'startTime'};
		my $start_time = C24to12(substr($game_time,11,5));
		my $clock_time = $gamedata->{'timeLeft'}; 
		my $game_clock = $gamedata->{'statusDisplayName'}; 
		my $period = $gamedata->{'currentPeriod'}->{'shortDisplayName'};
		my $halftime = $gamedata->{'is_halftime'};
		my $away_team_id = $gamedata->{'awayTeamId'};
		my $home_team_id = $gamedata->{'homeTeamId'};
		my $away_team = $gamedata->{'awayTeam'}->{'abbreviation'};
		my $home_team = $gamedata->{'homeTeam'}->{'abbreviation'};
		my $away_score = $gamedata->{'awayScore'};
		my $home_score = $gamedata->{'homeScore'};
		my $away_team_name = $gamedata->{'awayTeam'}->{'fullName'};;
		my $home_team_name = $gamedata->{'homeTeam'}->{'fullName'};
		my $tv_network = $gamedata->{'broadcastChannels'}[0]->{'name'};
		$log->debug("GameID: ", $game);
		$log->debug("Gamedate: ", $gamedate);
		$log->debug("Start (US Eastern): ", $start_time);
		$log->debug("Game Stat: ", $game_stat);
		$log->debug("Game Time: ", $game_time);
		$log->debug("Game Clock: ", $game_clock);
		$log->debug("Clock Time: ", $clock_time);
		$log->debug("Period: ", $period);
		$log->debug("Away Team ID: ", $away_team_id);
		$log->debug("Home Team ID: ", $home_team_id);
		$log->debug("Away Team Abbr: ", $away_team);
		$log->debug("Home Team Abbr: ", $home_team);
		$log->debug("Away Score: ", $away_score);
		$log->debug("Home Score: ", $home_score);
		$log->debug("Away Team Name: ", $away_team_name);
		$log->debug("Home Team Name: ", $home_team_name);

		$log->debug($away_team, " @ ", $home_team);
		
		if ($gamedate eq $today) { # Only display games occuring today
			if ($game_stat eq "IN_PROGRESS" || $game_stat eq "Live") { # Active game
				$log->debug("Active game");
				$clock_time = $clock_time.' '.$period;
				if ($game_clock eq "Half") {
					$log->debug("Active game - Halftime");
					$clock_time = $game_clock;
				}
			}
			elsif ($game_clock eq "Half") {
				$log->debug("Active game - Halftime");
				$clock_time = $game_clock;
			}
			elsif ($game_stat eq 'Game Over' or $game_stat =~ /Final/i){ #Finished game
				$log->debug("Finished game");
				$clock_time = 'Final'; 
				if ($period > 4) {
					$log->debug("Overtime");
					$clock_time = 'Final OT';
				}
			}
			else { # upcoming games
				$log->debug("Upcoming or Postponed game");
				$away_score = '';
				$home_score = '';
				$clock_time = $start_time;
				$log->debug($clock_time);
			}

			my $sport = "NFL";
			my $home_logo = lc($home_team);
			my $away_logo = lc($away_team);
			my $home_logoURL = 'http://a.espncdn.com/combiner/i?img=/i/teamlogos/nfl/500/' . $home_logo . '.png';	  
			my $away_logoURL = 'http://a.espncdn.com/combiner/i?img=/i/teamlogos/nfl/500/' . $away_logo . '.png';
			my $home_logoF = $imagePath."NFL/".$home_logo.".png";
			my $away_logoF = $imagePath."NFL/".$away_logo.".png";
			$home_logo = "plugins/SuperDateTime/html/images/NFL/".$home_logo.".png";
			$away_logo = "plugins/SuperDateTime/html/images/NFL/".$away_logo.".png";
			&storeLOGO($sport,$home_team_name,$home_logoURL,$home_logoF,$away_team_name,$away_logoURL,$away_logoF);

			$log->debug("Status: " . $game_stat . " ");
			$log->debug("Game time: " . $game_time . " ");
			$log->debug("TV Network: ", $tv_network);
			$log->debug("Clock: ", $clock_time);
			$log->debug("CClock: ", convertTime($clock_time));
			$log->debug("Away team & score: ", $away_team, " " , $away_score);
			$log->debug("Home team & score: ", $home_team, " ", $home_score);
			$log->debug("Home logo URL = " . $home_logoURL);
			$log->debug("Away logo URL = " . $away_logoURL);
			$log->debug("Home logo file = " . $home_logoF);
			$log->debug("Away logo file = " . $away_logoF);
			$log->debug(" ");
			$sportsData{'NFL'}{$home_team.$clock_time}{'homeTeamCK'} = $home_team;
			$sportsData{'NFL'}{$home_team.$clock_time}{'awayTeamCK'} = $away_team;
			$sportsData{'NFL'}{$home_team.$clock_time}{'homeTeam'} = shortenNFL($home_team_name);
			$sportsData{'NFL'}{$home_team.$clock_time}{'awayTeam'} = shortenNFL($away_team_name);
			$sportsData{'NFL'}{$home_team.$clock_time}{'awayScore'} = $away_score;
			$sportsData{'NFL'}{$home_team.$clock_time}{'homeScore'} = $home_score;
			$sportsData{'NFL'}{$home_team.$clock_time}{'gameTime'} = convertTime($clock_time);
			$sportsData{'NFL'}{$home_team.$clock_time}{'homeLogoURL'} = $home_logo;
			$sportsData{'NFL'}{$home_team.$clock_time}{'awayLogoURL'} = $away_logo;
			$sportsData{'NFL'}{$home_team.$clock_time}{'gameLogoURL'} = $home_logo;
		
			if ((teamCheck($home_team,\@NFLteams)==1) || (teamCheck($away_team,\@NFLteams)==1)) {
				displayLines($client, $clock_time, $away_team_name, $home_team_name, $away_score, $home_score, 'NFL ('.$tv_network.')', 'getNFL', \&shortenNFL, \%NFLmap);
			}
		}
		$NFL_GameNum++;
		getNFL(undef, $client, $refreshItem);
	}
	else {
		$log->debug("Made it to max NFL game #");
		$NFL_GameCount = 0;
		$refreshTracker[3] = 1;
		refreshData(undef, $client, $refreshItem);  
	}
}

sub convertTime {
	my $gametime = shift;
	$log->debug("Incoming time = $gametime");
	my $hour = 0;
	my $minute = 0;
	my $ampm = '';
	my $offset = $prefs->get('offset');
	
	if ($gametime =~ /(\d+:\d+), (\d+).*Period/) { #Active NHL game
		$gametime = $1 . '/' . $2;
	}
	elsif ($gametime =~ /\+/) { # Soccer extra time.  Leave as-is.
	}
	elsif (($gametime =~ /(\d+).*End/)||($gametime =~ /End (\d+)/)) { #NHL/NFL/CFB game, end of qtr/per
		$gametime = 'E'.$1;
	}
	elsif ($gametime =~ /(\d+):(\d+)\s*(\d*ot)/i) { #Time remaining in OT
		$hour = $1;
		$minute = $2;
		my $ot = uc($3);
		$gametime = $hour . ':' . $minute . "/" . $ot;
	}
	elsif ($gametime =~ /Final.(\d+)OT/i) { #CFB Multiple OT Final
	   $gametime = 'F/' . $1.'OT';
	}
	elsif ($gametime =~ /(\d+)OT/i) { #CFB Multiple OT Active
	   $gametime = $1.'OT';
	}
	elsif ($gametime =~ /Final.*(SO|OT)/i) { #OT Final or NHL Shoot Out Final 
		$gametime = 'F/' . $1;
	}
	elsif ($gametime =~ /(\D)\D+(\d+)/) { #Active MLB game, shorten inning info
		$gametime = $1 . $2;
	}
	elsif ($gametime =~ /(\d*\d+:\d\d) (\d)/) { #Active NFL game
		$gametime = $1 . '/' . $2;
	}
	elsif ($gametime =~ /(\d*\d+\.\d) (\d)/) { #Last seconds of NBA period
		$gametime = $1 . '/' . $2;
	}
	elsif ($gametime =~ /(\d+):(\d+)\s*(\d*ot|OT|SO)/i) { #Time remaining in OT or SO
		$hour = $1;
		$minute = $2;
		my $ot = uc($3);
		$gametime = $hour . ':' . $minute . "/" . $ot;
	}
	elsif ($gametime =~ /OT/) { #CFB OT Active
		$gametime = 'OT';
	}
	elsif ($gametime =~ /SO/) { #Soccer Shootout Active
		$gametime = 'SO';
	}
	elsif ($gametime =~ /(\d+):(\d+)\s*(\w\w)/) { #Future game, convert timezone
		$hour = $1;
		$minute = $2;
		$ampm = lc($3);
		while ($offset != 0) {
			if ($offset >0) {
				$offset = $offset -1;
				$hour = $hour +1;
				if ($hour == 13) {
					$hour = 1;
				}
				elsif ($hour == 12) {
					if ($ampm eq 'am') {
						$ampm = 'pm';
					}
					else {
						$ampm = 'am';
					}
				}
			}
			else {
				$offset = $offset +1;
					$hour = $hour -1;
					if ($hour == 0) {
					$hour = 12;
				}
				elsif ($hour == 11) {
					if ($ampm eq 'am') {
						$ampm = 'pm';
					}
					else {
						$ampm = 'am';
					}
				}
			}
		} 
		#$gametime = $hour . ':' . $minute . $ampm;
		if ($ampm eq 'pm' && $hour != 12) {
			$hour = $hour + 12;
		}
		elsif ($ampm eq 'am' && $hour == 12) { #Midnight
			$hour = 0;
		}
		$gametime = Slim::Utils::DateTime::timeF(timelocal(0,$minute,$hour,1,1,2010));
	}
	elsif ($gametime =~ /TBA/i) {
		$gametime = 'TBA';
	}
	elsif ($gametime =~ /HT/i) {
		$gametime = 'HT';
	}
	elsif ($gametime =~ /(\D)\D.*/) { #Final or Delayed MLB game
		$gametime = $1;
	}
	$log->debug("Converted Gametime = $gametime");
	return $gametime;
}

sub shortenMLB {
  my $long = shift;
  
	if ($prefs->get('shortMLB') eq 1) {
		if ($long =~ m/^Diamondbacks/) { $long = 'D-Backs';}
		elsif ($long=~ m/^Cardinals/) { $long = 'Cards';}
	}

  return $long;
}

sub shortenNBA {
  my $long = shift;
  
	if ($prefs->get('shortNBA') eq 1) {
		$log->debug('Short NBA Team names selected');
		$log->debug('Long name: '.$long);
		if( $long eq "Timberwolves" ) {$long = "TWolves";} 
		elsif( $long eq "Trail Blazers" ) {$long = "TBlazers";}
		$log->debug('Short name: '.$long);
	}

  return $long;
}

sub shortenWNBA {
  my $name = shift;
  my $city = shift;
  my $team_name = "";
  
	if ($prefs->get('shortWNBA') eq 1) {
		$log->debug('Short WNBA Team names checked');
		$team_name = $name;
		$log->debug('Short name: '.$team_name);
	}
	else {
		$log->debug('Short WNBA Team names NOT checked');
		$team_name = ($city." ".$name);
		$log->debug('Long name: '.$team_name);
	}

  return $team_name;
}

sub shortenCBB {
    my $long = shift;
  
	$log->debug($prefs->get('short'));
	if ($prefs->get('shortCBB') eq 1) {
		$log->debug('Short CBB Team names selected');
		$log->debug('Long name: '.$long);
		# YOU CAN MODIFY THIS LIKE THE EXAMPLE BELOW TO SHORTEN YOUR TEAM NAMES...
		if ($long =~ m/^Illinois$/) { $long = 'Illini';}
		elsif ($long=~ m/^California/) { $long = 'CAL';}
		elsif ($long=~ m/^Southern California/) { $long = 'USC';}
		elsif ($long=~ m/^Notre Dame/) { $long = 'ND';}
		elsif ($long=~ m/^Southern Methodist/) { $long = 'SMU';}
		elsif ($long=~ m/^Ohio State/) { $long = 'OSU';}
		elsif ($long=~ m/^Washington State/) { $long = 'WSU';}
		elsif ($long=~ m/^Boston College/) { $long = 'BC';}
		elsif ($long=~ m/^Wisconsin$/) { $long = 'Wisc.';}
		elsif ($long=~ m/^Bowling Green$/) { $long = 'BGSU';}
		elsif ($long=~ m/^Brigham Young/) { $long = 'BYU';}
		elsif ($long=~ m/^Northwestern/) { $long = 'NW';}
		elsif ($long=~ m/^San Diego State/) { $long = 'SDSU';}
		elsif ($long=~ m/^San Jose State/) { $long = 'SJSU';}
		elsif ($long=~ m/^Sacramento St./) { $long = 'SAC ST';}
		elsif ($long=~ m/^Kansas City/) { $long = 'UMKC';}
		elsif ($long=~ m/^George Washington/) { $long = 'G Wash';}
		elsif ($long=~ m/^Massachusetts/) { $long = 'UMass';}
		elsif ($long=~ m/^Louisiana Tech/) { $long = 'LA Tech';}
		$log->debug('Short name: '.$long);
	}
    return $long;
}

sub shortenCFB {
	my $long = shift;

	$log->debug($prefs->get('short'));
	if ($prefs->get('shortCFB') eq 1) {
		$log->debug('Short CFB Team names selected');
		$log->debug('Long name: '.$long);
		# YOU CAN MODIFY THIS LIKE THE EXAMPLES BELOW TO SHORTEN YOUR TEAM NAMES...
		if ($long =~ m/^Illinois$/) { $long = 'Illini';}
		elsif ($long=~ m/^Notre Dame/) { $long = 'ND';}
		elsif ($long=~ m/^Southern Methodist/) { $long = 'SMU';}
		elsif ($long=~ m/^Ohio State/) { $long = 'OSU';}
		elsif ($long=~ m/^Washington State/) { $long = 'WSU';}
		elsif ($long=~ m/^Boston College/) { $long = 'BC';}
		elsif ($long=~ m/^Wisconsin$/) { $long = 'Wisc.';}
		elsif ($long=~ m/^Bowling Green$/) { $long = 'BGSU';}
		elsif ($long=~ m/^Brigham Young/) { $long = 'BYU';}
		elsif ($long=~ m/^Northwestern/) { $long = 'NW';}
		elsif ($long=~ m/^San Diego State/) { $long = 'SDSU';}
		elsif ($long=~ m/^San Jose State/) { $long = 'SJSU';}
		$log->debug('Short name: '.$long);
	}
	return $long;
}

sub shortenNHL {
    my $long = shift;
	$log->debug($prefs->get('shortNHL'));
	if ($prefs->get('shortNHL') eq 1) {
		$log->debug('Short NHL Team names selected');
		$log->debug('Long name: '.$long);
		if ($long =~ m/^Rangers/) { $long = 'NYR';}
		elsif ($long =~ m/^Islanders/) { $long = 'Isles';}
		elsif ($long =~ m/^Penguins/) { $long = 'Pens';}
		elsif ($long =~ m/^Canadiens/) { $long = 'Habs';}
		elsif ($long =~ m/^Senators/) { $long = 'Sens';}
		elsif ($long =~ m/^Maple Leafs/) { $long = 'Leafs';}
		elsif ($long =~ m/^Lightning/) { $long = 'Bolts';}
		elsif ($long =~ m/^Capitals/) { $long = 'Caps';}
		elsif ($long =~ m/^Hurricanes/) { $long = 'Canes';}
		elsif ($long =~ m/^Red Wings/) { $long = 'Wings';}
		elsif ($long =~ m/^Predators/) { $long = 'Preds';}
		elsif ($long =~ m/^Blackhawks/) { $long = 'Hawks';}
		elsif ($long =~ m/^Blue Jackets/) { $long = 'CBJ';}
		elsif ($long =~ m/^Avalanche/) { $long = 'Avs';}
		elsif ($long =~ m/^Golden Knights/) { $long = 'Knights';}
		elsif ($long =~ m/^Utah Hockey Club/) { $long = 'Utah';}
		$log->debug('Short name: '.$long);
	}
	return $long;
}

sub shortenNFL {
	my $long = shift;
	
	if ($prefs->get('shortNFL')) {
		if ($long =~ m/^Buccaneers/) { $long = 'Bucs';}
		elsif ($long=~ m/^Patriots/) { $long = 'Pats';}
	}
	return $long;
}

sub shortenSoccer {
	my $long = shift;
	my $short = shift;
	
	if ($prefs->get('shortSoccer')) {
		$log->debug('Short Soccer Team Names selected.');
		$log->debug('Short Soccer Team Name: '.$short);
		return $short;
	}
	else {
		$log->debug('Long Soccer Team Names selected.');
		$log->debug('Long Soccer Team Name: '.$long);
		return $long;
	}
}

sub storeLOGO {
	my $sport = shift;
	my $home_team = shift;
	my $home_logoURL = shift;
	my $home_logoF = shift;
	my $away_team = shift;
	my $away_logoURL = shift;
	my $away_logoF = shift;
	$log->debug("Sport: ".$sport);
	$log->debug("Home Team: ".$home_team);
	$log->debug("Home URL: ".$home_logoURL);
	$log->debug("Home File: ".$home_logoF);
	$log->debug("Away Team: ".$away_team);
	$log->debug("Away URL: ".$away_logoURL);
	$log->debug("Home File: ".$away_logoF);
	
	if (-e $imagePath.$sport."/") {
		$log->debug("Directory ".$sport." for team logos exists.");
	}
	else {
		mkdir $imagePath.$sport."/";
		$log->debug("Created directory ".$sport." for team logos @ ".$imagePath.$sport."/");
	}

	
	if (-e $home_logoF) {
		$log->debug($sport." home_logo ". $home_team . " already stored.");					
	}
	else {	
		my $response = getstore($home_logoURL, $home_logoF);
		if (is_success($response)) { # Error check
			$log->debug($sport." home_logo for ". $home_team ." successfully stored! Response: " . $response);
		}
		else {
			$log->warn("Storing ".$sport." home_logo for ". $home_team ." FAILED! Response: " . $response);
		}
	}
	if (-e $away_logoF) {
		$log->debug($sport." away_logo ". $away_team . " already stored.");					
	}
	else {	
		my $response = getstore($away_logoURL, $away_logoF);
		if (is_success($response)) { # Error check
			$log->debug($sport." away_logo for ". $away_team ." successfully stored! Response: " . $response);
		}
		else {
			$log->warn("Storing ".$sport." away_logo for ". $away_team ." FAILED! Response: " . $response);
		}
	}
}

sub setMode() {
    my $class  = shift;
    my $client = shift;

    $client->lines(\&lines);

    # setting this param will call client->update() frequently
    $client->modeParam('modeUpdateInterval', 1); # seconds

}

sub getFunctions {
    return {
        'up' => sub  {
            my $client = shift;
            my $button = shift;
            $client->bumpUp() if ($button !~ /repeat/);
        },
        'down' => sub  {
            my $client = shift;
            my $button = shift;
            $client->bumpDown() if ($button !~ /repeat/);;
        },
        'left' => sub  {
            my $client = shift;
            Slim::Buttons::Common::popModeRight($client);
        },
        'right' => sub  {
            my $client = shift;
            
            my $saver = Slim::Player::Source::playmode($client) eq 'play' ? 'screensaver' : 'idlesaver';
        
            if ($prefs->client($client)->get($saver) ne 'SCREENSAVER.superdatetime') {
                $prefs->client($client)->set($saver,'SCREENSAVER.superdatetime');
            } else {
                $prefs->client($client)->set($saver, $Slim::Player::Player::defaultPrefs->{$saver});
            }
        },
        'stop' => sub {
            my $client = shift;
            Slim::Buttons::Common::pushMode($client, 'SCREENSAVER.superdatetime');
        },
        'showme' => sub { #Function to force screensaver into screensaver mode
            my $client = shift;
            Slim::Buttons::Common::pushMode($client, 'SCREENSAVER.superdatetime');
        }   
    };
}

sub lines {
    my $client = shift;
    
    my $saver = Slim::Player::Source::playmode($client) eq 'play' ? 'screensaver' : 'idlesaver';
    my $line2 = $client->string('SETUP_SCREENSAVER_USE');
    my $overlay2 = Slim::Buttons::Common::checkBoxOverlay($client, $prefs->client($client)->get($saver) eq 'SCREENSAVER.superdatetime');
    
    return {
        'line'    => [ $client->string('PLUGIN_SCREENSAVER_SUPERDATETIME'), $line2 ],
        'overlay' => [ undef, $overlay2 ]
    };
}

our %screensaverSuperDateTimeFunctions = (
    'done' => sub  {
                    my ($client, $funct, $functarg) = @_;
                    Slim::Buttons::Common::popMode($client);
                    $client->update();
                    #pass along ir code to new mode if requested
                    if (defined $functarg && $functarg eq 'passback') {
                        Slim::Hardware::IR::resendButton($client);
                    }
    },
    'up' => sub  {
        my $client = shift;
        
        $weathershowing{$client} = (); #Reset weather showing in case up was hit while displaying weather
        
        if ($scrollType{$client} eq 'Ticker') { #Set flag to reset out of ticker mode
            $killTicker{$client} = 1;
        }
        
        if ($nowshowing{$client}{'itemNum'} == 0) { #Is the time currently showing?
            if($topNowShowing{$client} == (scalar @{$displayInfo{$client}{'TOPdisplayItems1'}}-1)) {
                $topNowShowing{$client} = 0;
            }
            else {
                $topNowShowing{$client}++;
            }
        }
        else {
            $nowshowing{$client}{'itemNum'} = 0; #Show the time
        }
        
        killClientTimers($client);
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 10, \&nextDisplayItem);
                
        $client->update(); #Refresh the display
    },
    'down' => sub  {
        my $client = shift;
        
        $weathershowing{$client} = (); #Reset weather showing in case down was hit while displaying weather

        if ($scrollType{$client} eq 'Ticker') { #Set flag to reset out of ticker mode
            $killTicker{$client} = 1;
        }
        
        if ($nowshowing{$client}{'itemNum'} == 0) { #Is the time currently showing?
            if($topNowShowing{$client} == 0) {
                $topNowShowing{$client} = scalar @{$displayInfo{$client}{'TOPdisplayItems1'}}-1;
            }
            else {
                $topNowShowing{$client}--;
            }
        }
        else {
            $nowshowing{$client}{'itemNum'} = 0; #Show the time
        }
        
        killClientTimers($client);          
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 10, \&nextDisplayItem);    
        
        $client->update(); #Refresh the display
    },
    'down.hold' => sub  {
        my $client = shift;
        
        $weathershowing{$client} = 1; #Reset weather showing in case up was hit while displaying weather
        
        if ($scrollType{$client} eq 'Ticker') { #Set flag to reset out of ticker mode
            $killTicker{$client} = 1;
        }
        
        if ($nowshowing{$client}{'itemNum'} == 0) { #Is the time currently showing?
            $topNowShowing{$client} = 0;
        }
        else {
            $nowshowing{$client}{'itemNum'} = 0; #Show the time
        }
        
        killClientTimers($client);
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 10, \&nextDisplayItem);
                
        $client->update(); #Refresh the display
    },  
    'refresh' => sub  {
        my $client = shift;

        $client->showBriefly( {
            line => ['Refreshing data...']
        },
        {
            scroll => 1,
            block  => 1,
        } );        

        Slim::Utils::Timers::killTimers(undef, \&refreshData);
        $averages{'last'} = ''; #Make sure averages/10day will get refreshed too
        refreshData(undef, $client, -1);
    },  
    'wnext' => sub  {
        my $client = shift;

        if (scalar @WETdisplayItems2 >0) { #Make sure there are some long forecasts to show
            killClientTimers($client);
            nextWeatherItem($client,1);
        }
        else {
            $client->bumpLeft();
        }
    },
    'wprev' => sub  {
        my $client = shift;
        
        if (scalar @WETdisplayItems2 >0) { #Make sure there are some long forecasts to show
            killClientTimers($client);
            nextWeatherItem($client,-1);
        }
        else {
            $client->bumpRight();
        }
    },  
    'right' => sub  {
        my $client = shift;
        
        if (totalGames() >0) { #Are there display items?
            killClientTimers($client);
            nextDisplayItem($client);
        }
        else {
            $client->bumpLeft();
        }
        
    },  
    'left' => sub  {
        my $client = shift;

        if (totalGames() >0) { #Are there display items?
            killClientTimers($client);
            prevDisplayItem($client);
        }
        else {
            $client->bumpRight();
        }
    },
    'size.hold' => sub  {
        my $client = shift;
        if ($client->power()) { #Client power is on
            Slim::Buttons::Common::popModeRight($client); #Bring client back to where they were b4 screensaver
        }
    },
);

sub currentWeatherInterval {
    if (scalar @WETdisplayItems2 > 0) {
        my $lweather = $prefs->get('lweather');
        if ($lweather == 4) {
            return 1;
        }
        elsif ($lweather == 5) {
            return 5;
        }
        elsif ($activeGames == 1 && $lweather == 2) {
            return 1;
        }
        elsif ($activeGames == 0 && $lweather == 3) {
            return 1;
        }
        else {
            return 0;
        }
    }
    else {
        return 0;
    }
}

sub totalGames {
    my $total = 0;
    
    if (defined $displayInfo{'cycleItems1'}) {
        $total = scalar @{$displayInfo{'cycleItems1'}};
    }

    return $total;  
}

sub getScreensaverSuperDatetime {

    return \%screensaverSuperDateTimeFunctions;
}

sub setScreensaverSuperDateTimeMode() {
    my $client = shift;
    
    my $key;
    my $value;
    $killTicker{$client} = 0;
    
	# optionally disable visualizer
	$client->pluginData('oldVisualizer', $client->modeParam('visu'));
	$client->modeParam('visu', [0]) if ($prefs->client($client)->get('disableVisualizer'));

	
	if( $client && $client->isa( "Slim::Player::Squeezebox2")) {
        while (($key, $value) = each(%NFLmap)){ #Store NFL team icons as a special font.
            Slim::Display::Graphics::setCustomChar( 'getNFL-'.$value, chr(hex $value), 'nfl.2' );
        }
    
        while (($key, $value) = each(%MLBmap)){ #Store MLB team icons as a special font.
            Slim::Display::Graphics::setCustomChar( 'getMLB-'.$value, chr(hex $value), 'mlb.2' );
            $log->debug("Setting the graphic MLB icon: ". $key . " " . $value); 
        }
    
        #Add 'special' character for spacing
        Slim::Display::Graphics::setCustomChar( 'getMLB-41', chr(hex 41), 'mlb.2' );
        
        $Gclient = $client; #capture the graphical client for use in the refreshData routine.
    }
    
    $activeClients++;

    #Set default for top line per client
    if ($prefs->client($client)->get('topNowShowing') ne '') {
        $topNowShowing{$client} = $prefs->client($client)->get('topNowShowing');
    }
    else {
        $topNowShowing{$client} = 1;
        $prefs->client($client)->set('topNowShowing', 1);
    }

    refreshPlayerSettings(undef, $client);

    if ($activeClients == 1) {
        Slim::Utils::Timers::killTimers(undef, \&refreshData); #Just in case there's a rogue timer
        Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 6, \&refreshData, $client, -1);
    }

    $nowshowing{$client}{'itemNum'} = 0; #Start on time display
    Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 10, \&nextDisplayItem);
            
    $client->lines(\&screensaverSuperDateTimelines);
    
    #Slim::Utils::Timers::listTimers();
    # setting this param will call client->update() frequently
    $client->modeParam('modeUpdateInterval', 1); # seconds #7.0

    #Graphical forecasts code...
    # get display size for player if at least Squeezebox2
    if( $client && $client->isa( "Slim::Player::Squeezebox2")) {
        $xmax{$client} = $client->display()->displayWidth();
        $ymax{$client} = $client->display()->bytesPerColumn() * 8;
        
        $log->debug("Found graphic display $xmax{$client} x $ymax{$client} ($client)");
    }
    # only use text on SqueezeboxG and SLIMP3
    else {
        $xmax{$client} = 0;
        $ymax{$client} = 0;
    }
        
    if (scalar $displayInfo{$client}{'forecastG'}==0 && ($client->display->vfdmodel() eq Slim::Display::Squeezebox2->vfdmodel())) {  #Only set the weather channel logo the first time
        clearCanvas($client); #Show weatherchannel logo at startup
        drawIcon($client,29,$ymax{$client}-1,$TWClogo);;
        $displayInfo{$client}{'forecastG'}[0] = getFramebuf($client,75); #75 gfx width
        $displayInfo{$client}{'forecastG'}[1] = $displayInfo{$client}{'forecastG'}[0];
        $displayInfo{$client}{'forecastG'}[2] = $displayInfo{$client}{'forecastG'}[0];
        $displayInfo{$client}{'forecastG'}[3] = $displayInfo{$client}{'forecastG'}[0];
    }
}

sub leaveScreensaverSuperDateTimeMode {
    my $client = shift;
    
	#Restore visualizer and 2nd display on Transporter 
	$client->modeParam('visu', $client->pluginData('oldVisualizer'));
	$client->update({'screen2' => {}});

    #Save top showing preference incase server is shut down
    $prefs->client($client)->set('topNowShowing', $topNowShowing{$client});
    
    $activeClients--;
    
    if ($activeClients == 0) {
        Slim::Utils::Timers::killTimers(undef, \&refreshData);
    }
    
    killClientTimers($client);
    Slim::Utils::Timers::killTimers($client, \&_flashAlarm);
}

sub gotErrorViaHTTP {
    my $http = shift;
    my $params = $http->params();
    my $caller = $params->{'caller'};
    my $callerProc = $params->{'callerProc'};
    my $client = $params->{'client'};
    my $refreshItem = $params->{'refreshItem'};
	my $errorCountMax = $prefs->get('errorCountMax');

    $errorCount++;

    if ($errorCount > $errorCountMax) {
        $log->error("Network error count reached during $caller.");
        $status = '?';
        saveCycles($caller);
        refreshData(undef, $client, $refreshItem);
    }
    elsif ($caller eq "getAverages") {#Special case
		$log->info("error getting " . $http->url());
		$log->info($http->error());
		if ($http->error() eq "404 Not Found") {
			$stopGetAvg = 1; # set flag to stop checking for averages
			$errorCount = 0; # reset error count
			$log->info("Weather.com does not provide averages for location ".$prefs->get('city').".");	
			getAverages($params->{'dayNum'}, $client, $refreshItem);
		}
        else {
			$log->warn("Trying getAverages again.");
			getAverages($params->{'dayNum'}, $client, $refreshItem);
		}
	}
    elsif ($caller eq "getLatLong") {
		$log->error("error getting " . $http->url());
		$log->error($http->error());
		if ($http->error() eq "404 Not Found") {
			$errorCount = 0; # reset error count
			$log->error("Unable to get latitude and longitude for Weather Station Identifier ".$prefs->get('city').".");	
			$log->error("Check your Weather.com Station Identifier and try again");
			$prefs->set('city','60614:4:US'); 
			$log->error("Defaulting identifier to Chicago: " . $prefs->get('city'));
			getLatLong();
		}
        else {
			$log->warn("Trying $caller again.");    
			Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 3, $callerProc, $client, $refreshItem);
		}
	}
    elsif (defined $callerProc) {
		$log->warn("error getting " . $http->url());
		$log->warn($http->error());
		$log->warn("Trying $caller again.");    
        Slim::Utils::Timers::setTimer(undef, Time::HiRes::time() + 3, $callerProc, $client, $refreshItem);
    }
}

sub nextWeatherItem {
    my $client = shift;
    my $caller = shift;
    
    $killTicker{$client} = 3;

    if (defined $weathershowing{$client}) {
        if ($caller == -1) {
            if ($weathershowing{$client} == 1) {
                $weathershowing{$client} = scalar @WETdisplayItems1;
            }
            else {
                $weathershowing{$client}--;
            }
        }
        else {
            if ($weathershowing{$client} == scalar @WETdisplayItems1) {
                $weathershowing{$client} = 1;
            }
            else {
                $weathershowing{$client}++;
            }
        }
    }
    else {
        if ($caller == -1) {
            $weathershowing{$client} = scalar @WETdisplayItems1;
        }
        else {
            $weathershowing{$client} = 1;
        }
    }
    $displayLine1{$client} = $WETdisplayItems1[$weathershowing{$client}-1];
    $displayLine2{$client} = $WETdisplayItems2[$weathershowing{$client}-1];
    $nowshowing{$client}{'itemNum'} = -1; #Don't display the time...

    if ($weathershowing{$client} == scalar @WETdisplayItems1) {
        #Need to give time for display lines to be called (+2)
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 2, \&setWeatherTimer,2);
    }
    else {
        #Need to give time for display lines to be called (+2)
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 2, \&setWeatherTimer,1);
    }

    #Update display
    if ($scrollType{$client} eq 'Basic') {
        $client->update(); #Refresh the display
    }
    else {
        if ($caller == -1) {
            if ($client->display->hasScreen2()) {
                my $prevHash = $client->curDisplay();
                delete $prevHash->{'screen1'};
                    
                my $hash = $client->curLines();
                delete $hash->{'screen1'};
                $client->pushRight($prevHash, $hash);
            }
            else {
                $client->pushRight();
            }
        }
        else {
            if ($client->display->hasScreen2()) {
                my $prevHash = $client->curDisplay();
                delete $prevHash->{'screen1'};
                    
                my $hash = $client->curLines();
                delete $hash->{'screen1'};
                $client->pushLeft($prevHash, $hash);
            }
            else {
                $client->pushLeft();
            }
        }
    }   
}

sub nextDisplayItem {
    my $client = shift;
    my $timerInterval = 0;
    $nowshowing{$client}{'justify'} = 'center'; #Default

    if ($nowshowing{$client}{'itemNum'} < 0) {#Showing weather
        $nowshowing{$client}{'itemNum'} = 0;
        $timerInterval = $showtime;
    }
    elsif (defined($displayInfo{'cycleItems1'}[$nowshowing{$client}{'itemNum'}])) {
        $displayLine1{$client} = $displayInfo{'cycleItems1'}[$nowshowing{$client}{'itemNum'}];
        $displayLine2{$client} = $displayInfo{'cycleItems2'}[$nowshowing{$client}{'itemNum'}];
        $timerInterval = $displayInfo{'cycleInts'}[$nowshowing{$client}{'itemNum'}];
        
        #Special logic to left justify text so that it scrolls
        if ($timerInterval eq 'L') {
            $timerInterval = 5; #Set a min to show in case it's less than a full line of text, make this configurable or L5 (left 5sec minimum)Make sure at least 3seconds???
            $nowshowing{$client}{'justify'} = 'line';
        }

        $nowshowing{$client}{'itemNum'}++;
    }
    else { #TIME
        $nowshowing{$client}{'itemNum'} = 0;
        
        if (($activeGames == 1) && ($showactivetime == 0)) { #Don't show time when active games
            return nextDisplayItem($client);
        }
        #This probably needs to be re-evaluated...
        elsif ((($activeGames == 0) && ($showtime == 0)) && #Don't show time when no active games
                ((totalGames() + scalar @WETdisplayItems2) >0)) #make sure there are some games to show
        { 
            return nextDisplayItem($client);
        }
        else { #Show the time
            if ($activeGames == 0) {
                $timerInterval = $showtime;
            }
            else {
                $timerInterval = $showactivetime;
            }
        }       
    }
        
    if ($scrollType{$client} eq 'Ticker' && $killTicker{$client} == 0) {
        my $tickerScreen;
        if ($client->display->hasScreen2()) {
            $tickerScreen = 2;
        }
        else {
            $tickerScreen = 1;
        }
        
        my ($complete, $queue) = $client->scrollTickerTimeLeft($tickerScreen);
        if ($nowshowing{$client}{'itemNum'} == 0) {  #NEED TO ONLY OCCUR IF TICKER MODE
            #Why do we include timerinterval in this???
            Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $timerInterval + $complete, \&nextDisplayItem);
        }
    }
   else {
        #Make sure there are items besides the time showing
        if (totalGames() >0) {
            #Update display
            if ($scrollType{$client} eq 'Basic') {
                $client->update(); #Refresh the display
            }
            else {              
                if ($client->display->hasScreen2()) {
                    my $prevHash = $client->curDisplay();
                    delete $prevHash->{'screen1'};
                    
                    my $hash = $client->curLines();
                    delete $hash->{'screen1'};
                    $client->pushLeft($prevHash, $hash);
                }
                else {
                    $client->pushLeft();
                }               
            }
        }

        if ($nowshowing{$client}{'itemNum'} < 0) { #Weather forecast
            #Need to give time for display lines to be called (+2)
            Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 2.5, \&setWeatherTimer);
        }
        elsif ($nowshowing{$client}{'justify'} eq 'line'){
            #Want to give enough time to text to scroll, but have to set a timer to wait for it to actually start scrolling
            #Should we add a min check for anything or just pass in what they specify as the minimum???
            Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 2.5, \&setLongTextTimer);
        }
        else {
            Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $timerInterval, \&nextDisplayItem);
        }
    }

    $killTicker{$client} = 0;
}

sub setWeatherTimer {
    #This creates a timer to set the nextDisplayItem timer for a weather forecast.
    #This is necessary because display length is based on how long it takes to scroll...
    my $client = shift;
    my $caller = shift;
    
    my $tickerScreen;
    if ($client->display->hasScreen2()) {
        $tickerScreen = 2;
    }
    else {
        $tickerScreen = 1;
    }   
    my ($complete, $queue) = $client->scrollTickerTimeLeft($tickerScreen);
    
    if ($caller == 1) { #User viewing weather via fast forward/reverse buttons
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $complete + preferences('server')->client($client)->get('scrollPause'), \&nextWeatherItem);
    }
    elsif ($caller == 2) { #User viewing weather via fast forward/reverse buttons and at last item
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $complete + preferences('server')->client($client)->get('scrollPause'), \&nextDisplayItem);
    }
    else { #Viewing weather forecast via left/right buttons or regular display intervals
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $complete + preferences('server')->client($client)->get('scrollPause'), \&nextDisplayItem);
    }
}

sub setLongTextTimer {
    #This creates a timer to set the nextDisplayItem timer for a long text item
    #This is necessary because display length is based on how long it takes to scroll...
    my $client = shift;
    
    my $tickerScreen;
    if ($client->display->hasScreen2()) {
        $tickerScreen = 2;
    }
    else {
        $tickerScreen = 1;
    }   
    
    my ($complete, $queue) = $client->scrollTickerTimeLeft($tickerScreen);
    #Need to add some logic for min length
    Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $complete + preferences('server')->client($client)->get('scrollPause'), \&nextDisplayItem);
}

#Used during ticker display mode to set the top display line to the text at halfway point
sub topLineSet {

    my $client = shift;
    my $topLine = shift;
    
    $tickline1{$client} = $topLine; 
}

sub prevDisplayItem {
    my $client = shift;
    my $timerInterval;

    $nowshowing{$client}{'justify'} = 'center'; #Default

    if ($nowshowing{$client}{'itemNum'} == 0) {
        if (defined($displayInfo{'cycleItems1'})) {
            $nowshowing{$client}{'itemNum'} = scalar @{$displayInfo{'cycleOrigin'}};
            $displayLine1{$client} = $displayInfo{'cycleItems1'}[$nowshowing{$client}{'itemNum'}-1];
            $displayLine2{$client} = $displayInfo{'cycleItems2'}[$nowshowing{$client}{'itemNum'}-1];
            $timerInterval = $displayInfo{'cycleInts'}[$nowshowing{$client}{'itemNum'}-1];

            #Special logic to left justify text so that it scrolls
            if ($timerInterval eq 'L') {
                $timerInterval = 5; #Set a min to show in case it's less than a full line of text, make this configurable or L5 (left 5sec minimum)Make sure at least 3seconds???
                $nowshowing{$client}{'justify'} = 'line';
            }
        }
        else {
            $timerInterval = 10;
        }
    }
    elsif ($nowshowing{$client}{'itemNum'} <= 1) {
        $nowshowing{$client}{'itemNum'} = 0;
        
        if ($activeGames == 0) {
            $timerInterval = $showtime;
        }
        else {
            $timerInterval = $showactivetime;
        }                               
    }
    else {
        $nowshowing{$client}{'itemNum'}--;
        $displayLine1{$client} = $displayInfo{'cycleItems1'}[$nowshowing{$client}{'itemNum'}-1];
        $displayLine2{$client} = $displayInfo{'cycleItems2'}[$nowshowing{$client}{'itemNum'}-1];
        $timerInterval = $displayInfo{'cycleInts'}[$nowshowing{$client}{'itemNum'}-1];  

        #Special logic to left justify text so that it scrolls
        if ($timerInterval eq 'L') {
            $timerInterval = 5; #Set a min to show in case it's less than a full line of text, make this configurable or L5 (left 5sec minimum)Make sure at least 3seconds???
            $nowshowing{$client}{'justify'} = 'line';
        }
    }

    #Update display
    if ($scrollType{$client} eq 'Basic') {
        $client->update(); #Refresh the display
    }
    else {
        if ($client->display->hasScreen2()) {
            my $hash = screensaverSuperDateTimelines($client);
            delete $hash->{'screen1'};
            #my $curHash = $client->curDisplay();
            #delete $curHash->{'screen2'};
            $client->pushRight(undef, $hash);
        }
        else {
            $client->pushRight();
        }
    }

    if ($nowshowing{$client}{'itemNum'} < 0) { #Weather forecast
        #Need to give time for display lines to be called (+2)
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 2, \&setWeatherTimer);
    }
    elsif ($nowshowing{$client}{'justify'} eq 'line'){
        #Want to give enough time to text to scroll, but have to set a timer to wait for it to actually start scrolling
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 2.5, \&setLongTextTimer);
    }   
    else {
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + $timerInterval, \&nextDisplayItem);
    }
}

sub killClientTimers {
    my $client = shift;

    Slim::Utils::Timers::killTimers($client, \&nextWeatherItem);
    Slim::Utils::Timers::killTimers($client, \&setWeatherTimer);
    Slim::Utils::Timers::killTimers($client, \&nextDisplayItem);
    Slim::Utils::Timers::killTimers($client, \&setLongTextTimer);
    Slim::Utils::Timers::killTimers($client, \&topLineSet);
}

sub clearCanvas {
    my $client = shift;

    for( my $xi = 0; $xi < $xmax{$client}; $xi++) {
        for( my $yi = 0; $yi < $ymax{$client}; $yi++) {
            $hashDisp{$client}[$xi][$yi] = 0;
        }
    }
}

sub drawIcon {
    my $client = shift;
    my $xpos = shift;
    my $ypos = shift;
    my $icon = shift;

    if ($xmax{$client} && $ymax{$client}) {
        my $firstline = 1;
        my $xs = $xpos < 0 ? 0 : $xpos;
        my $yi = $ypos > $ymax{$client} ? $ymax{$client} : $ypos;
        for my $line (split('\n',$icon)) {
            # first line must be skipped (empty)
            if ($firstline) {
                $firstline = 0;
                next;
            }
            chomp $line;
            for( my $xi = $xs; $xi < length($line)+$xs && $xi < $xmax{$client} && $yi >= 0; $xi++) {
                if (substr($line,$xi-$xs,1) eq "*") {
                    $hashDisp{$client}[$xi][$yi] = 1;
                }
            }
            $yi--;
        }
    }
}

sub drawText {
    my $client = shift;
    my $xpos = shift;
    my $ypos = shift;
    my $text = shift;

    if ($xmax{$client} && $ymax{$client}) {
        for (my $ci = 0; $ci < length($text); $ci++) {
            my $c = substr($text,$ci,1);
            my $firstline = 1;
            my $xs = $xpos < 0 ? 0 : $xpos + $ci*6;
            my $yi = $ypos > $ymax{$client} ? $ymax{$client} : $ypos;
            for my $line (split('\n',$Charset[$Codepage{$c}])) {
                # first line must be skipped (empty)
                if ($firstline) {
                    $firstline = 0;
                    next;
                }
                chomp $line;
                for( my $xi = $xs; $xi < length($line)+$xs && $xi < $xmax{$client} && $yi >= 0; $xi++) {
                    if (substr($line,$xi-$xs,1) eq "*") {
                        $hashDisp{$client}[$xi][$yi] = 1;
                    }
                }
                $yi--;
            }
        }
    }
}

# convert %hashDisp into line framebuffer format
sub getFramebuf {
    my $client = shift;
    my $width = shift;
    my $line1 = "";
    
    for( my $x = 0; $x < $width && $x < $xmax{$client}; $x++) {
        my $byte;
        for( my $y = $ymax{$client}; $y > 0; $y -= 8) {
            $byte = ($hashDisp{$client}[$x][$y-1] << 7)
                  + ($hashDisp{$client}[$x][$y-2] << 6)
                  + ($hashDisp{$client}[$x][$y-3] << 5)
                  + ($hashDisp{$client}[$x][$y-4] << 4)
                  + ($hashDisp{$client}[$x][$y-5] << 3)
                  + ($hashDisp{$client}[$x][$y-6] << 2)
                  + ($hashDisp{$client}[$x][$y-7] << 1)
                  +  $hashDisp{$client}[$x][$y-8];
            $line1 .= pack("C", $byte);
        }
    }
    return $line1;
}

sub screensaverSuperDateTimelines {
    my $client = shift;
    my $args   = shift;
    
    my $bottomPad = '';
    
    my $flash  = $args->{'flash'}; # set when called from animation callback
    
    my $narrow = $client->display->isa('Slim::Display::Boom');
    my $currentAlarm = Slim::Utils::Alarm->getCurrentAlarm($client);
    my $nextAlarm = Slim::Utils::Alarm->getNextAlarm($client);
    # show alarm symbol if active or set for next 24 hours
    my $alarmOn = defined $currentAlarm || ( defined $nextAlarm && ($nextAlarm->nextDue - time < 86400) );
    $overlay{$client} = undef;
    if ($alarmOn && !$flash) {
        if (defined $currentAlarm && $currentAlarm->snoozeActive) {
            $overlay{$client} = $client->symbols('sleep');
        } else {
            $overlay{$client} = $client->symbols('bell');
            # Include the next alarm time in the overlay if there's room
            if (!$narrow && !defined $currentAlarm) {
                # Remove seconds from alarm time
                my $timeStr = Slim::Utils::DateTime::timeF($nextAlarm->time % 86400, $prefs->client($client)->timeformat, 1);
                $timeStr =~ s/(\d?\d\D\d\d)\D\d\d/$1/;
                $overlay{$client} .=  " $timeStr";
            }
        }
    }

    my $s2line1;
    my $s2line2;

    my $lastTicker = 0; #Flag set to indicate showing last ticker item
    my $hash;

    if ($nowshowing{$client}{'itemNum'} == 0 || ($client->display->hasScreen2())) { #Show time and temperature  
        my $time;
        if (defined($Plugins::FuzzyTime::Plugin::apiVersion)) {
            $time = Plugins::FuzzyTime::Public::timeF($client,undef,preferences('plugin.datetime')->get('timeformat'));
        }
        else {
            $time = $client->timeF();
        }
                    
        if (defined($displayInfo{$client}{'TOPdisplayItems1'}[$topNowShowing{$client}])) { #Show next forecast
            #Figure out how much extra spacing is necessary from the 3line text to the lower line       
            my $max;
            if ($displayInfo{$client}{'CharLen2'}[$topNowShowing{$client}] > $displayInfo{$client}{'CharLen3'}[$topNowShowing{$client}]) {
                $max = $displayInfo{$client}{'CharLen2'}[$topNowShowing{$client}];
            }
            else {
                $max = $displayInfo{$client}{'CharLen3'}[$topNowShowing{$client}];
            }
        
            #If they're using a large font, include top line in maximum for spacing
            if ($client->textSize() == 2) { #Large text
                if ($displayInfo{$client}{'CharLen1'}[$topNowShowing{$client}] > $max) {
                    $max = $displayInfo{$client}{'CharLen1'}[$topNowShowing{$client}];
                }
            }
            
            if ($max >2) {
                $max = $max - 1;
            }
                    
            #Create a text string with the proper number of blank spaces        
            for (my $count=1; $count< $max; $count++)
            {
                $bottomPad = $bottomPad . $client->symbols("getMLB-41");
            }

            if ($displayInfo{$client}{'hasIcon'}[$topNowShowing{$client}] == 1) {
                $bottomPad = ' ' . $bottomPad . $client->symbols("getMLB-41"). $client->symbols("getMLB-41") . $client->symbols("getMLB-41") . $client->symbols("getMLB-41") . $client->symbols("getMLB-41");
            }
    
            $s2line1 = $displayInfo{$client}{'TOPdisplayItems1'}[$topNowShowing{$client}];
            $s2line1 =~ s/%1/$time/;
            $s2line2 = $bottomPad . $displayInfo{$client}{'BOTdisplayItems1'}[$topNowShowing{$client}];
            $s2line2 =~ s/%1/$time/;
            
            if ($nowshowing{$client}{'itemNum'} == 0) {
                $displayLine1{$client} = $s2line1;
                $displayLine2{$client} = $s2line2;
            }
        }
        else { #Show the time/date
            $displayLine1{$client} = $client->longDateF();
            $displayLine2{$client} = $time;
            $s2line1 = $displayLine1{$client};
            $s2line2 = $displayLine2{$client};
        }
    }

    if ($scrollType{$client} eq 'Ticker' && $killTicker{$client} !=3) { #TICKERS
        my $tickerScreen;
        if ($client->display->hasScreen2()) {
            $tickerScreen = 2;
        }
        else {
            $tickerScreen = 1;
        }       
        my ($complete, $queue) = $client->scrollTickerTimeLeft($tickerScreen);

        if ($nowshowing{$client}{'itemNum'} == 0) { #Time
            if ($complete == 0 || $killTicker{$client} == 1) { #Show the time
                $killTicker{$client} = 0; #Reset kill ticker in case it's toggeled
                if ($bottomPad ne '') {
                    $hash = {
                        'overlay' => [$overlay{$client} . $status, undef],
                        'center'  => [$displayLine1{$client}, $displayLine2{$client}],
                        # It's incorrect to center the bottom line, but if I don't and the text is larger than what will fit
                        # on the screen SC will start to scroll it, which totally messes the ticker logic up because it will
                        # think there's an active ticker when it's actually just the time display.
                        #'center'  => [$displayLine1{$client}, undef],
                        #'line'    => [ undef, $displayLine2{$client} ],            
                    };
                }
                else {
                    $hash = { #No icon or 3line so center everything
                        'overlay' => [ $overlay{$client} . $status, undef ],
                        'center'  => [ $displayLine1{$client}, $displayLine2{$client} ],
                    };
                }
            }
            else { #Last ticker item still displaying
                $lastTicker = 1;
                $hash = {
                    'overlay'  => [ $overlay{$client} . $status, undef],
                    'center'   => [ $tickline1{$client}, undef ],
                    'ticker'   => [ undef, undef ],
                };
            }
        }   
        elsif ($queue <1 && $complete >0) { #Queue empty, item is still showing
            nextDisplayItem($client);
            if ($nowshowing{$client}{'itemNum'} != 0) { #Add item to ticker

                Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + ($complete*.5), \&topLineSet, $displayLine1{$client});
                        
                $hash = { 
                    'overlay' => [ $overlay{$client} . $status, undef ],
                    'center'  => [ $tickline1{$client}, undef ],
                    'ticker'  => [ undef, $displayLine2{$client} ],
                };
            }
            else { #Last ticker item about to show time
                $lastTicker = 1;
                $hash = {
                    'overlay' => [ $overlay{$client} . $status, undef ],
                    'center'  => [ $tickline1{$client}, undef ],
                    'ticker'  => [ undef, undef ],
                };      
            }
        }
        elsif ($complete > 0) { #Showing a ticker item
            $hash = {
                'overlay' => [ $overlay{$client} . $status, undef ],
                'center'  => [ $tickline1{$client}, undef ],
                'ticker'  => [ undef, undef ],
            };
        }
        else {  #Add first ticker item
            $tickline1{$client} = $displayLine1{$client};
                $hash = {
                    'overlay' => [ $overlay{$client} . $status, undef ],
                    'center'  => [ $tickline1{$client}, undef ],
                    'ticker'  => [ undef, $displayLine2{$client} ],
                };
        }
    }
    else {  #BASIC OR SLIDE
        if ($client->textSize() != 2) { #Not large text
            if ($nowshowing{$client}{'itemNum'} == 0 &&  $bottomPad ne '') { #Time with special spacing             
                $hash = {
                    'overlay' => [ $overlay{$client} . $status, undef ],
                    'center'  => [ $displayLine1{$client}, undef ],
                    'line'    => [ undef, $displayLine2{$client} ],                         
                };
            }
            elsif ($nowshowing{$client}{'itemNum'} == 0) { #Time without special spacing
                $hash = {
                    'overlay' => [ $overlay{$client} . $status, undef ],
                    'center'  => [ $displayLine1{$client}, $displayLine2{$client} ],                            
                };
            }           
            elsif ($nowshowing{$client}{'itemNum'} < 0) { #Weather with scrolling
                $hash = {
                    'overlay' => [ $overlay{$client} . $status ],
                    'center'  => [ $displayLine1{$client} ],
                    'line'    => [ undef, $displayLine2{$client} ],
                };
            }
            else {
                if ($nowshowing{$client}{'justify'} eq 'line') {
                    $hash = {  #Game left justify text to allow for scrolling
                        'overlay' => [ $overlay{$client} . $status, undef ],
                        'center'  => [ $displayLine1{$client}, undef ],
                        'line'    => [ undef, $displayLine2{$client} ],
                    };              
                }
                else {
                    $hash = {  #Game center text # Changed these lines to make game text scroll correctly on Boom.
                        'overlay' => [ $overlay{$client} . $status, undef ],
#                       'center'  => [ $displayLine1{$client}, $displayLine2{$client} ],
                        'center'  => [ $displayLine1{$client}, undef ],
                        'line'    => [ undef, $displayLine2{$client} ],
                    };
                }
            } 
       } #End of not large text
       else { #Large text
        if ($nowshowing{$client}{'itemNum'} == 0) { #Time
                    $hash = {
                        'overlay' => [ undef, $overlay{$client} . $status ],
                        'center'  => [ undef, $displayLine2{$client}],
                    };
            }
            else { #Sport scores/stocks in large text
                $hash = {
                    'overlay' => [ undef, $overlay{$client} . $status ],
                    $nowshowing{$client}{'justify'} => [ undef, $displayLine2{$client}],
                };
            }
       }
    }
    
    my $dispHash;
    if ($client->display->hasScreen2()) { #Dual screens
        my $time;
        if (defined($Plugins::FuzzyTime::Plugin::apiVersion)) {
            $time = Plugins::FuzzyTime::Public::timeF($client,undef,preferences('plugin.datetime')->get('timeformat'));
        }
        else {
            $time = $client->timeF();
        }
                
        my $timeHash;
        if ($bottomPad ne '') { #Time with special spacing              
            $timeHash = {
                'center' => [ $s2line1, undef ],
                'line'   => [ undef, $s2line2 ],
            };
        }
        else {
            $timeHash = {
                'center'  => [ $s2line1, $s2line2 ],
            };      
        }

        if ($nowshowing{$client}{'itemNum'} != 0 || $lastTicker == 1) { #Not time
            $dispHash->{'screen2'} = $hash;
        }
        else {
            my $line1 = $displayInfo{$client}{'TOPdisplayItems2'}[$topNowShowing{$client}];
            $line1 =~ s/%1/$time/; #Add the time if its included
            
            my $line2 = $displayInfo{$client}{'BOTdisplayItems2'}[$topNowShowing{$client}];
            $line2 =~ s/%1/$time/; #Add the time if its included
            
            my $screen2;
            if ($client->textSize() != 2) { #Not large text
                $screen2 = {
                        'overlay' => [ $overlay{$client} . $status, undef ],
                        'center'  => [ $line1, $line2 ],
                };
            }
            else {
                $screen2 = {
                    'overlay' => [ undef, $overlay{$client} . $status ],
                    'center'  => [ $line1, $line2 ],
                };
            }
            
            $dispHash->{'screen2'} = $screen2;
        }
        
        if ($xmax{$client} && $ymax{$client}) {
            $timeHash->{'bits'} = $displayInfo{$client}{'forecastG'}[$topNowShowing{$client}];
        }
        $dispHash->{'screen1'} = $timeHash;
    }
    else { #Single screen
        $hash->{'fonts'} = { 'graphic-280x16'  => { 'overlay' => [ 'small.1' ]},
                                   'graphic-320x32'  => { 'overlay' => [ 'standard.1' ]},
                                   'text' =>            { 'displayoverlays' => 1 },
                                 };

        if ($xmax{$client} && $ymax{$client} && $nowshowing{$client}{'itemNum'} == 0 && $lastTicker == 0) {
            $hash->{'bits'} = $displayInfo{$client}{'forecastG'}[$topNowShowing{$client}];
        }
        $dispHash->{'screen1'} = $hash;
    }
    
    if ($currentAlarm && !$flash) {
        # schedule another update to remove the alarm symbol during alarm
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time + 0.5, \&_flashAlarm);
    }
    
    return $dispHash;       
}

sub _flashAlarm {
    my $client = shift;
    
    $client->update( screensaverSuperDateTimelines($client, { flash => 1 }) );
}

sub cliQuery {
    my $request = shift;
    my $client = $request->client();

    #Get mode param
    my $mode = $request->getParam('_mode');
    
    $log->debug("Inside CLI request: $mode");
    
    if ($mode eq 'all') {
        $request->addResult( "wetData", \%wetData );
        $request->addResult( "sportsData", \%sportsData );
        $request->addResult( "miscData", \%miscData );
    }
    elsif ($mode eq 'sports') {
        $request->addResult( "sportsData", \%sportsData );  
    }
    elsif ($mode eq 'selsports') {  
        my %selSportsData = ();

        for my $sport ( keys %sportsData ) {
            for my $game ( keys %{ $sportsData{$sport} } ) {
                #Skip the sport logos as they're not actually games
                if($game eq 'logoURL') {
                        $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        next;
                    }
                
                #Use dynamic var names instead?
                if ($sport eq 'MLB') {
                    if (scalar @MLBteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@MLBteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@MLBteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'NBA') {
                    if (scalar @NBAteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@NBAteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@NBAteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'WNBA') {
                    if (scalar @WNBAteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@WNBAteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@WNBAteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'NFL') {
                    if (scalar @NFLteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@NFLteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@NFLteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'NHL') {
                    if (scalar @NHLteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@NHLteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@NHLteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'College Basketball') {
                    if (scalar @CBBteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@CBBteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@CBBteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'College Football') {
                    if (scalar @CFBteams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@CFBteams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@CFBteams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                elsif ($sport eq 'Soccer') {
                    if (scalar @soccerTeams >0) {
                        if ((teamCheck($sportsData{$sport}{$game}{'homeTeamCK'},\@soccerTeams)==1) || (teamCheck($sportsData{$sport}{$game}{'awayTeamCK'},\@soccerTeams)==1)) {
                            $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                        }
                    }
                }
                else { #Custom sport
                    $log->warn('Why am I here? Sport = ' . $sport);
                    $selSportsData{$sport}{$game} = $sportsData{$sport}{$game};
                }
            }
        }

        $request->addResult( "selsports", \%selSportsData );    
    }   
    elsif ($mode eq 'weather') {
        $request->addResult( "wetData", \%wetData );
     }
	elsif ($mode eq 'wetmapURL') {
		# Build absolute HTTP URLs for client consumption; keep local caching unchanged
		 my $sprefs    = preferences('server');
		 my $host      = $sprefs->get('httpaddr');   # may be undef/empty
		 my $httpport;

		 # Treat wildcard bind addresses as unset; use serverstatus for concrete IP/port
		 if ( !$host || $host eq '0.0.0.0' || $host eq '::' ) {
			 my $r = eval {Slim::Control::Request::executeRequest(undef, [ 'serverstatus', 0, 1 ])};
			 if ( $r ) {
				$host     = $r->getResult('ip')			|| $host;
				$httpport = $r->getResult('httpport')	|| $httpport;
			} 
			else {
				$httpport = $sprefs->get('httpport');
			}

			$host     ||= '127.0.0.1';
			$httpport ||= ( $sprefs->get('httpport') || 9000 );

			 # Bracket IPv6 for URLs
			 my $host_for_url = ($host =~ /:/) ? "[$host]" : $host;
			 
			 my $base    = sprintf('http://%s:%s', $host_for_url, $httpport);
			 my $relBase = '/plugins/SuperDateTime/html/images/MAPS';

			 my %wetMapURLs = (
				 Local  => { URL => $base . "$relBase/mapLocal.jpg"  },
				 Medium => { URL => $base . "$relBase/mapMedium.jpg" },
				 Wide   => { URL => $base . "$relBase/mapWide.jpg"   },
			 );

			 $request->addResult('wetmapURL', \%wetMapURLs);
			 $log->debug("Weather Map URLs provided to CC Applet");
			 $log->debug($wetMapURLs{'Local'}{'URL'});
			 $log->debug($wetMapURLs{'Medium'}{'URL'});
			 $log->debug($wetMapURLs{'Wide'}{'URL'});
			 $request->setStatusDone();
			 return;
		 }
	}		
    elsif ($mode eq 'misc') {
        $request->addResult( "miscData", \%miscData );
    }
    else {
        $log->warn("Unknown CLI request: $mode");
    }

    $request->setStatusDone();
}

sub macroString {
    my $request = shift;
    my $client = $request->client();

    $log->debug("Inside CLI request macroString");

    my $format = $request->getParam('format');
    my $period = $request->getParam('period');
    
    #Default period to 0 if not provided
    if (!defined $period) {$period = -1;}
    $log->debug("Incoming string: $format Period: $period");
    my $macroString = replaceMacrosPer($format, $period, $client);
    
    $log->debug("Outgoing string: $macroString");
    $request->addResult( "macroString", $macroString );

    if (defined $funcptr && ref($funcptr) eq 'CODE') {
        $log->debug('Calling next function');
        $request->addParam('format', $macroString);
        eval { &{$funcptr}($request) };

        # arrange for some useful logging if we fail
        if ($@) {
            $log->error('Error while trying to run function coderef: [' . $@ . ']');
            $request->setStatusBadDispatch();
            $request->dump('Request');
        }
    }
    else {
        $log->debug('Done');
        $request->setStatusDone();
    }
}

sub sdtVersion {
    my $request = shift;
    my $client = $request->client();

    $log->debug("Inside CLI request sdtVersion");
        
        $request->addResult( "sdtVersion", $VERSION );

    $request->setStatusDone();
}

#External API to add a custom sport score
#Should only be called during a dataRefresh
sub addCustomSportScore(\%) {
    my $params = shift;
    
    $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'gameTime'} = $params->{'gameTime'};
    $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'homeTeam'} = $params->{'homeTeam'};
    $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'homeScore'} = $params->{'homeScore'};
    $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'awayTeam'} = $params->{'awayTeam'};
    $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'awayScore'} = $params->{'awayScore'};
    
    if (defined $params->{'gameLogoURL'}) {
        $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'gameLogoURL'} = $params->{'gameLogoURL'};
    }

    if (defined $params->{'homeLogoURL'}) {
        $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'homeLogoURL'} = $params->{'homeLogoURL'};
    }
    
    if (defined $params->{'awayLogoURL'}) {
        $sportsData{$params->{'sport'}}{$params->{'gameID'}}{'awayLogoURL'} = $params->{'awayLogoURL'};
    }
}

#External API to add an icon for a custom sport
sub addCustomSportLogo {
    my $sport = shift;
    my $imgURL = shift;

    $sportsData{$sport}{'logoURL'} = $imgURL;
}

#External API to remove all sports scores and icon for a particular custom sport
#Should only be called during a dataRefresh
sub delCustomSport {
    my $sport = shift;
    
    delete $sportsData{$sport};
}

#External API to remove sports scores for a particular custom sport
#Should only be called during a dataRefresh
sub delCustomSportScore {
    my $sport = shift;
    my $gameID = shift;
    
    delete $sportsData{$sport}{$gameID};
}

#External API to add a custom display text by hash ref
#Should only be called during a dataRefresh
sub addCustomDisplayItemHash {
    my $group = shift;
    my $itemID = shift;
    my $itemHash_ref = shift;
    
    #Copy item hash into a new hash
    my %hash = %$itemHash_ref;

    $miscData{$group}{$itemID} = \%hash;
}

#External API to remove all display items for a custom group
#Should only be called during a dataRefresh
sub delCustomDisplayGroup {
    my $group = shift;
    
    delete $miscData{$group};
}

#External API to remove display items for a particular custom group
#Should only be called during a dataRefresh
sub delCustomDisplayGroupItem {
    my $group = shift;
    my $itemID = shift;
    
    delete $miscData{$group}{$itemID};
}



1;

__END__

# Local Variables:
# tab-width:4
# indent-tabs-mode:t
# End:
